"""Simple Telegram editor over existing automation settings and V2 rules."""

from __future__ import annotations

import html
import uuid

from bot_runtime.navigation import edit, reply, require_admin
from bot_runtime.shared import PERMISSION_AUTOMATIONS, SETTINGS, ConversationHandler, InlineKeyboardButton
from core.async_db import async_snapshot, async_with_db
from core.utils import esc
from modules.automation_admin import (
    ACTION_LABELS,
    ALL_ACTION_LABELS,
    BUILTINS,
    FIELDS,
    TRIGGER_LABELS,
    builtin_state,
    remove_rule,
    save_rule_draft,
    set_setting,
)
from modules.automation_v2 import list_automation_rules, update_automation_rule
from modules.management_suite import automation_settings

AUTOMATION_UI_INPUT = "AUTOMATION_UI_INPUT"
END = ConversationHandler.END


def _au_value(value):
    if isinstance(value, bool):
        return "فعال" if value else "غیرفعال"
    if isinstance(value, list):
        return "، ".join(map(str, value))
    if value == "Asia/Tehran":
        return "تهران"
    return str(value)


def _au_back(target="a_automations"):
    return [
        [
            InlineKeyboardButton("⬅️ بازگشت", callback_data=target),
            InlineKeyboardButton("🏠 پنل ادمین", callback_data="admin_home"),
        ]
    ]


async def _automation_center(update, context, page=0):
    db = await async_snapshot()
    settings = automation_settings(db)
    hidden = set(settings.get("admin_hidden_builtins") or [])
    rules = list_automation_rules(db)
    entries = [
        (f"{'🟢' if settings.get(spec[2]) else '⚪'} {spec[0]}", f"au:b:{key}")
        for key, spec in BUILTINS.items()
        if key not in hidden and key != "general"
    ]
    entries += [(f"{'🟢' if row.get('enabled') else '⚪'} {row['name'][:45]}", f"au:r:{row['id']}") for row in rules]
    page = min(max(0, int(page)), max(0, (len(entries) - 1) // 12))
    buttons = [
        InlineKeyboardButton(label, callback_data=callback) for label, callback in entries[page * 12 : (page + 1) * 12]
    ]
    rows = [[InlineKeyboardButton("➕ افزودن اتوماسیون", callback_data="au:add")]]
    rows += [buttons[index : index + 2] for index in range(0, len(buttons), 2)]
    paging = []
    if page:
        paging.append(InlineKeyboardButton("صفحه قبل", callback_data=f"au:list:{page - 1}"))
    if (page + 1) * 12 < len(entries):
        paging.append(InlineKeyboardButton("صفحه بعد", callback_data=f"au:list:{page + 1}"))
    if paging:
        rows.append(paging)
    rows += [
        [
            InlineKeyboardButton("⚙️ تنظیمات عمومی", callback_data="au:b:general"),
            InlineKeyboardButton("📜 گزارش اجراها", callback_data="crm_automation_log"),
        ]
    ]
    rows += _au_back("admin_home")
    text = (
        "🤖 <b>اتوماسیون مدیریتی</b>\n\n"
        f"کل اتوماسیون: <b>{'فعال' if settings.get('enabled') else 'متوقف'}</b>\n"
        "هر مورد را انتخاب کنید؛ روشن/خاموش‌کردن، ویرایش و حذف در صفحهٔ همان مورد است.\n"
        "قانون تازه ابتدا غیرفعال ذخیره می‌شود؛ فعال‌سازی انتخاب جداگانه دارد.\n"
        "🟢 فعال  ·  ⚪ غیرفعال"
    )
    await edit(update.callback_query, text, rows)
    return END


async def _automation_builtin(update, context, key):
    if key not in BUILTINS:
        raise ValueError("مورد پیدا نشد.")
    db = await async_snapshot()
    settings = automation_settings(db)
    spec = BUILTINS[key]
    enabled = bool(settings.get(spec[2]))
    removed = key in set(settings.get("admin_hidden_builtins") or [])
    lines = [
        f"<b>{esc(spec[0])}</b>",
        esc(spec[1]),
        "",
        f"وضعیت: <b>{'حذف‌شده' if removed else 'فعال' if enabled else 'غیرفعال'}</b>",
    ]
    if key not in {"general", "quiet"} and not settings.get("enabled"):
        lines.append("کل اتوماسیون متوقف است؛ این مورد فعلاً اجرا نمی‌شود.")
    if spec[2].startswith("crm_") and key not in {"general", "quiet"} and not settings.get("crm_enabled"):
        lines.append("CRM خودکار خاموش است؛ این مورد فعلاً اجرا نمی‌شود.")
    rows = []
    if removed:
        rows.append([InlineKeyboardButton("➕ افزودن دوباره — غیرفعال", callback_data=f"au:restore:{key}")])
    else:
        rows.append(
            [
                InlineKeyboardButton(
                    "⏸ غیرفعال کن" if enabled else "▶️ فعال کن", callback_data=f"au:state:{key}:{int(not enabled)}"
                )
            ]
        )
        for field in spec[3]:
            label = FIELDS[field][0]
            value = _au_value(settings.get(field))
            lines.append(f"{esc(label)}: <b>{esc(value)}</b>")
            if field.endswith("_enabled"):
                rows.append(
                    [
                        InlineKeyboardButton(
                            f"{label}: {value}",
                            callback_data=f"au:bool:{key}:{field}:{int(not bool(settings.get(field)))}",
                        )
                    ]
                )
            elif field == "crm_timezone":
                rows.append(
                    [
                        InlineKeyboardButton("تهران", callback_data=f"au:tz:{key}:tehran"),
                        InlineKeyboardButton("UTC", callback_data=f"au:tz:{key}:utc"),
                    ]
                )
            else:
                rows.append([InlineKeyboardButton(f"✏️ {label}: {value}", callback_data=f"au:field:{key}:{field}")])
        if key != "general":
            rows.append([InlineKeyboardButton("🗑 حذف از اتوماسیون", callback_data=f"au:remove_b:{key}")])
    await edit(update.callback_query, "\n".join(lines), rows + _au_back())
    return END


async def _automation_rule_view(update, context, rule_id):
    row = (await async_snapshot()).get("automation_rules_v2", {}).get(rule_id)
    if not row or row.get("deleted_at"):
        raise ValueError("قانون پیدا نشد یا حذف شده است.")
    lines = [
        "🤖 <b>" + esc(row["name"]) + "</b>",
        f"وضعیت: <b>{'فعال' if row.get('enabled') else 'غیرفعال / پیش‌نویس'}</b>",
        "وقتی: " + esc(TRIGGER_LABELS.get(row["trigger"], row["trigger"])),
    ]
    for item in row.get("actions", []):
        lines.append("اقدام: " + esc(ALL_ACTION_LABELS.get(item.get("type"), item.get("type"))))
        value = (
            item.get("payload", {}).get("text")
            or item.get("payload", {}).get("tag")
            or item.get("payload", {}).get("title")
            or item.get("payload", {}).get("message")
        )
        if value:
            lines.append(esc(html.unescape(str(value)))[:800])
    if row.get("conditions"):
        lines.append("شرط‌های ثبت‌شدهٔ این قانون حفظ می‌شوند.")
    if row.get("trigger") == "scheduled":
        lines.append("رویداد زمان‌بندی‌شده با زمان‌بند موجود اجرا می‌شود؛ تغییر نام، زمان‌بند جدید نمی‌سازد.")
    lines += [f"اجرای موفق: {row.get('success_count', 0)} · ناموفق: {row.get('failure_count', 0)}"]
    rows = [
        [
            InlineKeyboardButton(
                "⏸ غیرفعال کن" if row.get("enabled") else "▶️ فعال کن",
                callback_data=f"au:rstate:{rule_id}:{int(not bool(row.get('enabled')))}",
            )
        ],
        [
            InlineKeyboardButton("✏️ نام", callback_data=f"au:rename:{rule_id}"),
            InlineKeyboardButton("✏️ زمان وقوع", callback_data=f"au:retrigger:{rule_id}"),
        ],
    ]
    for index, item in enumerate(row.get("actions", [])):
        if item.get("type") in ACTION_LABELS:
            rows.append(
                [InlineKeyboardButton("✏️ " + ACTION_LABELS[item["type"]], callback_data=f"au:rvalue:{rule_id}:{index}")]
            )
    rows += [[InlineKeyboardButton("🗑 حذف قانون", callback_data=f"au:remove_r:{rule_id}")]] + _au_back()
    await edit(update.callback_query, "\n".join(lines)[:3900], rows)
    return END


def _au_trigger_rows(prefix="trigger"):
    buttons = [
        InlineKeyboardButton(label, callback_data=f"au:{prefix}:{trigger}") for trigger, label in TRIGGER_LABELS.items()
    ]
    return [buttons[i : i + 2] for i in range(0, len(buttons), 2)]


def _au_action_payload(kind, value):
    if kind == "send_message":
        return {"recipient_id": "{{user_id}}", "text": html.escape(value), "parse_mode": "HTML"}
    if kind == "notify_admin":
        return {"recipient_id": str(SETTINGS.primary_admin_id), "text": html.escape(value), "parse_mode": "HTML"}
    if kind in {"add_tag", "remove_tag"}:
        return {"user_id": "{{user_id}}", "tag": value}
    if kind == "create_task":
        return {"title": value, "user_id": "{{user_id}}"}
    if kind == "write_log":
        return {"message": value}
    raise ValueError("این اقدام در فرم ساده قابل ساخت نیست.")


def _au_build_draft(wizard):
    values = wizard["values"]
    kind = values["action"]
    return {
        "name": values["name"],
        "trigger": values["trigger"],
        "conditions": [{"field": "user_id", "operator": "exists"}]
        if kind in {"send_message", "add_tag", "remove_tag"}
        else [],
        "actions": [{"type": kind, "payload": _au_action_payload(kind, values["value"])}],
        "guards": {
            "max_runs_per_day": 100,
            "max_runs_per_entity": 1,
            "cooldown_seconds": 3600,
            "disable_after_failures": 3,
            "max_retries": 3,
            "retry_delay_seconds": 30,
        },
    }


async def _au_wizard(update, context, *, message=False):
    wizard = context.user_data.get("automation_ui_wizard")
    if not wizard:
        raise ValueError("فرم منقضی شده است؛ دوباره شروع کنید.")
    step = wizard["step"]
    v = wizard["values"]
    rows = []
    if step == "name":
        text = "نام این اتوماسیون چیست؟"
        state = AUTOMATION_UI_INPUT
    elif step == "trigger":
        text = "این اتوماسیون چه زمانی اجرا شود؟"
        rows = _au_trigger_rows()
        state = AUTOMATION_UI_INPUT
    elif step == "action":
        text = "چه کاری انجام دهد؟"
        buttons = [
            InlineKeyboardButton(label, callback_data=f"au:action:{kind}") for kind, label in ACTION_LABELS.items()
        ]
        rows = [buttons[i : i + 2] for i in range(0, len(buttons), 2)]
        state = AUTOMATION_UI_INPUT
    elif step == "value":
        text = (
            "متن پیام را بفرستید:"
            if v["action"] in {"send_message", "notify_admin"}
            else "برچسب را بنویسید:"
            if v["action"] in {"add_tag", "remove_tag"}
            else "عنوان کار را بنویسید:"
            if v["action"] == "create_task"
            else "متن یادداشت گزارش را بنویسید:"
        )
        state = AUTOMATION_UI_INPUT
    else:
        _au_build_draft(wizard)
        text = (
            "🤖 <b>پیش‌نمایش اتوماسیون</b>\n\nنام: "
            + esc(v["name"])
            + "\nوقتی: "
            + esc(TRIGGER_LABELS[v["trigger"]])
            + "\nاقدام: "
            + esc(ACTION_LABELS[v["action"]])
            + "\nمحتوا:\n"
            + esc(v["value"])
            + "\n\nابتدا غیرفعال ذخیره می‌شود. حداکثر ۱۰۰ اجرا در روز و یک اجرا برای هر مورد؛ فعال‌سازی جداگانه است."
        )
        rows = [
            [
                InlineKeyboardButton("💾 ذخیرهٔ پیش‌نویس", callback_data=f"au:save:{wizard['token']}"),
                InlineKeyboardButton("✏️ ویرایش", callback_data="au:step:name"),
            ]
        ]
        state = AUTOMATION_UI_INPUT
    if step in {"name", "value"} and v.get(step):
        text += "\nپاسخ قبلی: " + esc(v[step])[:500]
        rows.append([InlineKeyboardButton("✅ استفاده از پاسخ قبلی", callback_data="au:keep")])
    rows += [
        [
            InlineKeyboardButton("⬅️ مرحله قبل", callback_data="au:wback"),
            InlineKeyboardButton("❌ لغو", callback_data="au:cancel"),
        ]
    ]
    if message:
        await reply(update, text, rows)
    else:
        await edit(update.callback_query, text, rows)
    return state


async def automation_ui_callback(update, context):
    if not await require_admin(update, PERMISSION_AUTOMATIONS):
        return END
    q = update.callback_query
    await q.answer()
    parts = str(q.data).split(":")
    op = parts[1]
    if op not in {"rtrigger", "field", "rename", "rvalue", "retrigger"}:
        context.user_data.pop("automation_ui_edit", None)
    try:
        if op == "list":
            return await _automation_center(update, context, int(parts[2]))
        if op == "b":
            return await _automation_builtin(update, context, parts[2])
        if op == "r":
            return await _automation_rule_view(update, context, parts[2])
        if op == "add":
            settings = automation_settings(await async_snapshot())
            removed = [k for k in settings.get("admin_hidden_builtins", []) if k in BUILTINS]
            rows = [[InlineKeyboardButton("➕ اتوماسیون اختصاصی", callback_data="au:new")]]
            rows += [
                [InlineKeyboardButton("➕ " + BUILTINS[key][0], callback_data=f"au:restore:{key}")] for key in removed
            ]
            await edit(q, "🤖 مورد جدید بسازید یا مورد حذف‌شده را دوباره اضافه کنید.", rows + _au_back())
            return END
        if op in {"state", "restore"}:
            key = parts[2]
            await async_with_db(
                lambda db: builtin_state(
                    db, q.from_user.id, key, enabled=parts[3] == "1" if op == "state" else None, restore=op == "restore"
                )
            )
            return await _automation_builtin(update, context, key)
        if op in {"bool", "tz"}:
            key = parts[2]
            field = parts[3] if op == "bool" else "crm_timezone"
            if key not in BUILTINS or field not in BUILTINS[key][3]:
                raise ValueError("تنظیم نامعتبر است.")
            value = parts[4] == "1" if op == "bool" else "Asia/Tehran" if parts[3] == "tehran" else "UTC"
            await async_with_db(lambda db: set_setting(db, q.from_user.id, field, value))
            return await _automation_builtin(update, context, key)
        if op == "field":
            key, field = parts[2:4]
            if key not in BUILTINS or field not in BUILTINS[key][3] or field not in FIELDS:
                raise ValueError("تنظیم نامعتبر است.")
            context.user_data["automation_ui_edit"] = {"kind": "builtin", "key": key, "field": field}
            await edit(
                q, f"✏️ {FIELDS[field][0]}\n{FIELDS[field][1]}\nمقدار جدید را وارد کنید:", _au_back(f"au:b:{key}")
            )
            return AUTOMATION_UI_INPUT
        if op in {"remove_b", "remove_r"}:
            key = parts[2]
            callback = f"au:b:{key}" if op == "remove_b" else f"au:r:{key}"
            await edit(
                q,
                "🗑 این مورد حذف و اجرای تازهٔ آن متوقف شود؟\nگزارش‌های قبلی پاک نمی‌شوند. ارسال شروع‌شده ممکن است تمام شود.",
                [
                    [
                        InlineKeyboardButton(
                            "✅ حذف", callback_data=f"au:delete:{'b' if op == 'remove_b' else 'r'}:{key}"
                        ),
                        InlineKeyboardButton("❌ انصراف", callback_data=callback),
                    ]
                ],
            )
            return END
        if op == "delete":
            if parts[2] == "b":
                await async_with_db(lambda db: builtin_state(db, q.from_user.id, parts[3], remove=True))
            elif parts[2] == "r":
                await async_with_db(lambda db: remove_rule(db, q.from_user.id, parts[3]))
            else:
                raise ValueError("مورد نامعتبر است.")
            return await _automation_center(update, context)
        if op == "rstate":
            await async_with_db(
                lambda db: update_automation_rule(db, parts[2], {"enabled": parts[3] == "1"}, actor_id=q.from_user.id)
            )
            return await _automation_rule_view(update, context, parts[2])
        if op in {"rename", "rvalue", "retrigger"}:
            row = (await async_snapshot()).get("automation_rules_v2", {}).get(parts[2])
            if not row or row.get("deleted_at"):
                raise ValueError("قانون پیدا نشد.")
            context.user_data["automation_ui_edit"] = {
                "kind": op,
                "id": parts[2],
                "version": row.get("version"),
                "index": int(parts[3]) if op == "rvalue" else None,
            }
            if op == "retrigger":
                await edit(q, "چه زمانی اجرا شود؟", _au_trigger_rows("rtrigger") + _au_back(f"au:r:{parts[2]}"))
            else:
                await edit(
                    q,
                    "نام تازه را بنویسید:" if op == "rename" else "محتوای جدید را بنویسید:",
                    _au_back(f"au:r:{parts[2]}"),
                )
            return AUTOMATION_UI_INPUT
        if op == "rtrigger":
            target = context.user_data.get("automation_ui_edit", {})
            if target.get("kind") != "retrigger" or parts[2] not in TRIGGER_LABELS:
                raise ValueError("فرم منقضی شده است.")
            await _au_update_rule(context, q.from_user.id, {"trigger": parts[2]})
            context.user_data.pop("automation_ui_edit", None)
            return await _automation_rule_view(update, context, target["id"])
        if op == "new":
            context.user_data.pop("automation_ui_edit", None)
            context.user_data["automation_ui_wizard"] = {"token": uuid.uuid4().hex[:12], "step": "name", "values": {}}
            return await _au_wizard(update, context)
        wizard = context.user_data.get("automation_ui_wizard")
        if not wizard:
            raise ValueError("فرم منقضی شده است؛ دوباره شروع کنید.")
        if op == "cancel":
            if wizard["values"]:
                await edit(
                    q,
                    "فرم ذخیره‌نشده کنار گذاشته شود؟",
                    [
                        [
                            InlineKeyboardButton("✅ لغو فرم", callback_data="au:discard"),
                            InlineKeyboardButton("ادامهٔ فرم", callback_data="au:resume"),
                        ]
                    ],
                )
                return AUTOMATION_UI_INPUT
            op = "discard"
        if op == "discard":
            context.user_data.pop("automation_ui_wizard", None)
            return await _automation_center(update, context)
        if op == "resume":
            return await _au_wizard(update, context)
        if op == "keep":
            field = wizard["step"]
            if field not in {"name", "value"} or not wizard["values"].get(field):
                raise ValueError("پاسخ قبلی موجود نیست.")
            wizard["step"] = "trigger" if field == "name" else "preview"
        elif op == "wback":
            steps = ["name", "trigger", "action", "value", "preview"]
            wizard["step"] = steps[max(0, steps.index(wizard["step"]) - 1)]
        elif op == "step":
            if parts[2] != "name":
                raise ValueError("مرحله نامعتبر است.")
            wizard["step"] = "name"
        elif op == "trigger":
            if wizard["step"] != "trigger" or parts[2] not in TRIGGER_LABELS:
                raise ValueError("دکمه متعلق به این مرحله نیست.")
            wizard["values"]["trigger"] = parts[2]
            wizard["step"] = "action"
        elif op == "action":
            if wizard["step"] != "action" or parts[2] not in ACTION_LABELS:
                raise ValueError("دکمه متعلق به این مرحله نیست.")
            wizard["values"]["action"] = parts[2]
            wizard["step"] = "value"
        elif op == "save":
            if wizard["step"] != "preview" or parts[2] != wizard["token"]:
                raise ValueError("پیش‌نمایش منقضی شده است.")
            row = await async_with_db(
                lambda db: save_rule_draft(db, q.from_user.id, wizard["token"], _au_build_draft(wizard))
            )
            context.user_data.pop("automation_ui_wizard", None)
            return await _automation_rule_view(update, context, row["id"])
        else:
            raise ValueError("دکمه نامعتبر است.")
        return await _au_wizard(update, context)
    except (ValueError, PermissionError, IndexError, KeyError) as exc:
        await edit(q, "❌ " + esc(str(exc)), _au_back())
        return END


async def _au_update_rule(context, actor, changes):
    target = context.user_data.get("automation_ui_edit", {})

    def operation(db):
        row = db.get("automation_rules_v2", {}).get(target.get("id"))
        if not row or row.get("deleted_at") or row.get("version") != target.get("version"):
            raise ValueError("قانون تغییر کرده است؛ صفحه را دوباره باز کنید.")
        return update_automation_rule(db, row["id"], changes, actor_id=actor)

    return await async_with_db(operation)


async def automation_ui_input(update, context):
    if not await require_admin(update, PERMISSION_AUTOMATIONS):
        return END
    text = str(update.effective_message.text or "").strip()
    actor = update.effective_user.id
    try:
        target = context.user_data.get("automation_ui_edit")
        if target:
            if target["kind"] == "builtin":
                key, field = target["key"], target["field"]
                value = (
                    [int(part.strip()) for part in text.replace("،", ",").split(",") if part.strip()]
                    if field == "vip_reminder_days"
                    else int(text.replace(",", "").replace("٬", ""))
                )
                await async_with_db(lambda db: set_setting(db, actor, field, value))
                callback = f"au:b:{key}"
            else:
                if not text:
                    raise ValueError("متن خالی نباشد.")
                if target["kind"] == "rename":
                    changes = {"name": text[:160]}
                elif target["kind"] == "rvalue":
                    row = (await async_snapshot()).get("automation_rules_v2", {}).get(target["id"])
                    if not row:
                        raise ValueError("قانون پیدا نشد.")
                    actions = __import__("copy").deepcopy(row.get("actions", []))
                    item = actions[target["index"]]
                    kind = item["type"]
                    maximum = (
                        64
                        if kind in {"add_tag", "remove_tag"}
                        else 200
                        if kind == "create_task"
                        else 2000
                        if kind == "write_log"
                        else 3500
                    )
                    if len(text) > maximum:
                        raise ValueError(f"حداکثر {maximum} نویسه مجاز است.")
                    field = (
                        "text"
                        if kind in {"send_message", "notify_admin"}
                        else "tag"
                        if kind in {"add_tag", "remove_tag"}
                        else "title"
                        if kind == "create_task"
                        else "message"
                    )
                    if kind not in ACTION_LABELS:
                        raise ValueError("این اقدام فرم ساده ندارد.")
                    item["payload"][field] = html.escape(text) if kind in {"send_message", "notify_admin"} else text
                    changes = {"actions": actions}
                else:
                    raise ValueError("از دکمه‌های انتخاب استفاده کنید.")
                await _au_update_rule(context, actor, changes)
                callback = f"au:r:{target['id']}"
            context.user_data.pop("automation_ui_edit", None)
            await reply(
                update,
                "✅ تغییر ذخیره شد.",
                [[InlineKeyboardButton("مشاهدهٔ تنظیمات", callback_data=callback)]] + _au_back(),
            )
            return END
        wizard = context.user_data.get("automation_ui_wizard")
        if not wizard:
            raise ValueError("فرم منقضی شده است.")
        if wizard["step"] == "name":
            if not 1 <= len(text) <= 160:
                raise ValueError("نام را در ۱ تا ۱۶۰ نویسه بنویسید.")
            wizard["values"]["name"] = text
            wizard["step"] = "trigger"
        elif wizard["step"] == "value":
            kind = wizard["values"]["action"]
            maximum = (
                64
                if kind in {"add_tag", "remove_tag"}
                else 200
                if kind == "create_task"
                else 2000
                if kind == "write_log"
                else 3500
            )
            if not 1 <= len(text) <= maximum:
                raise ValueError(f"محتوا را در ۱ تا {maximum} نویسه بنویسید.")
            wizard["values"]["value"] = text
            wizard["step"] = "preview"
        else:
            raise ValueError("از دکمه‌های همین مرحله انتخاب کنید.")
        return await _au_wizard(update, context, message=True)
    except (ValueError, PermissionError, IndexError, KeyError) as exc:
        await reply(update, "❌ " + esc(str(exc)), [[InlineKeyboardButton("❌ لغو", callback_data="cancel_current")]])
        return AUTOMATION_UI_INPUT


__feature_exports__ = ("AUTOMATION_UI_INPUT", "_automation_center", "automation_ui_callback", "automation_ui_input")
