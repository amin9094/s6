"""Feature-owned Telegram handlers extracted from the v7 runtime: commerce_calculator."""

from bot_runtime import shared as _shared
from modules.payment_pricing import calculate_usdt_amount
globals().update({name: value for name, value in vars(_shared).items() if not name.startswith('__')})

def _normalize_card_number(value: str) -> str:
    digits = "".join(ch for ch in _ascii_digits(value) if ch.isdigit())
    if len(digits) != 16:
        raise ValueError("شماره کارت باید دقیقاً ۱۶ رقم باشد.")
    return "-".join(digits[index : index + 4] for index in range(0, 16, 4))


def _payment_unavailable_text(language: str = "fa") -> str:
    return (
        "⚠️ <b>VIP purchases are temporarily unavailable.</b>\nAn administrator must configure and enable at least one payment method."
        if normalize_language(language) == "en"
        else "⚠️ <b>خرید VIP موقتاً غیرفعال است.</b>\nادمین باید حداقل یکی از روش‌های پرداخت کارت بانکی یا تتر را کامل و فعال کند."
    )


def _payment_method_ready(db: dict[str, Any], method: str) -> bool:
    clean = str(method or "").strip().lower()
    if clean == "card":
        return card_payment_settings_ready(db)
    if clean == "usdt":
        return usdt_payment_settings_ready(db)
    return False


def _available_payment_methods(db: dict[str, Any]) -> list[str]:
    methods: list[str] = []
    if card_payment_settings_ready(db):
        methods.append("card")
    if usdt_payment_settings_ready(db):
        methods.append("usdt")
    return methods


def _payment_method_label(method: str) -> str:
    return "تتر (USDT)" if str(method).lower() == "usdt" else "کارت بانکی"


def _usdt_amount(toman_amount: int, rate_toman: Any) -> Decimal:
    """Use the same six-decimal quote calculation as the Mini App."""
    try:
        return calculate_usdt_amount(toman_amount, rate_toman)
    except ValueError as exc:
        if str(exc) == "USDT_RATE_UNAVAILABLE":
            raise ValueError("نرخ تتر باید بیشتر از صفر باشد") from exc
        raise ValueError("نرخ تتر معتبر نیست") from exc

def _payment_instructions(
    plan: dict[str, Any],
    settings: dict[str, Any],
    method: str,
    *,
    discount_percent: int = 0,
    final_price_override: int | None = None,
    language: str = "fa",
) -> str:
    language = normalize_language(language)
    base_price = int(plan.get("price", 0) or 0)
    final_price = (
        max(0, int(final_price_override))
        if final_price_override is not None
        else max(0, round(base_price * (100 - max(0, min(100, int(discount_percent)))) / 100))
    )
    if method == "usdt":
        amount = _usdt_amount(final_price, settings.get("usdt_rate_toman", 0))
        if language == "en":
            return (
                "₮ <b>USDT payment</b>\n\n"
                f"Network: <b>{esc(settings.get('usdt_network') or 'TRC20')}</b>\n"
                f"Amount: <b>{amount} USDT</b>\n"
                f"Wallet address:\n<code>{esc(settings.get('usdt_wallet_address') or 'Not configured')}</code>\n\n"
                f"Quote validity: <b>{int(settings.get('usdt_quote_valid_minutes', SETTINGS.usdt_quote_valid_minutes) or SETTINGS.usdt_quote_valid_minutes)} minutes</b>\n\n"
                "After payment, send the receipt image. The TXID is optional and the administrator reviews the payment manually."
            )
        return (
            "₮ <b>پرداخت با تتر</b>\n\n"
            f"شبکه: <b>{esc(settings.get('usdt_network') or 'TRC20')}</b>\n"
            f"مقدار قابل پرداخت: <b>{amount} USDT</b>\n"
            f"آدرس کیف پول:\n<code>{esc(settings.get('usdt_wallet_address') or 'تنظیم نشده')}</code>\n\n"
            f"اعتبار نرخ: <b>{int(settings.get('usdt_quote_valid_minutes', SETTINGS.usdt_quote_valid_minutes) or SETTINGS.usdt_quote_valid_minutes)} دقیقه</b>\n\n"
            "پس از واریز، تصویر رسید را ارسال کنید. TXID اختیاری است و پرداخت فقط به‌صورت دستی توسط ادمین بررسی می‌شود."
        )
    if language == "en":
        return (
            "💳 <b>Bank card payment</b>\n\n"
            f"Amount: <b>{final_price:,} IRT</b>\n"
            f"Card number: <code>{esc(settings.get('card_number') or 'Not configured')}</code>\n"
            f"Card holder: <b>{esc(settings.get('owner_name') or 'Not configured')}</b>\n\n"
            "After payment, send the receipt image."
        )
    return (
        "💳 <b>پرداخت با کارت بانکی</b>\n\n"
        f"مبلغ قابل پرداخت: <b>{final_price:,} تومان</b>\n"
        f"شماره کارت: <code>{esc(settings.get('card_number') or 'تنظیم نشده')}</code>\n"
        f"به نام: <b>{esc(settings.get('owner_name') or 'تنظیم نشده')}</b>\n\n"
        "پس از واریز، تصویر فیش را ارسال کنید."
    )


def _order_caption(order: dict[str, Any]) -> str:
    status_labels = {
        "pending": "⏳ در انتظار بررسی",
        "approving": "🔄 در حال تأیید",
        "approved": "✅ تأییدشده",
        "rejected": "❌ ردشده",
    }
    username = str(order.get("username") or "").strip()
    user_label = f"@{esc(username)}" if username else "بدون یوزرنیم"
    method = str(order.get("payment_method") or "card").lower()
    payment_lines = [f"💠 روش پرداخت: <b>{_payment_method_label(method)}</b>"]
    if method == "usdt":
        payment_lines.extend(
            [
                f"₮ مقدار تتر: <b>{esc(order.get('payment_amount_usdt') or '—')} USDT</b>",
                f"🌐 شبکه: <b>{esc(order.get('payment_network') or '—')}</b>",
                f"👛 کیف پول: <code>{esc(order.get('payment_wallet') or '—')}</code>",
                f"🔗 TXID: <code>{esc(order.get('transaction_hash') or '—')}</code>",
                "🛡 شیوه بررسی: <b>دستی توسط ادمین بر اساس تصویر رسید</b>",
            ]
        )
    return (
        "💳 <b>سفارش VIP</b>\n"
        f"👤 {esc(order.get('first_name') or 'کاربر')} — {user_label}\n"
        f"🆔 کاربر: <code>{esc(order.get('user_id'))}</code>\n"
        f"📦 پلن: <b>{esc(order.get('plan_name') or 'VIP استاندارد')}</b> — {int(order.get('duration_days', 30) or 30)} روز\n"
        f"💰 مبلغ پایه: <b>{int(order.get('base_price', order.get('price', 0)) or 0):,} تومان</b>\n"
        f"💵 مبلغ نهایی: <b>{int(order.get('price', 0) or 0):,} تومان</b>\n" + "\n".join(payment_lines) + "\n"
        f"🎟 تخفیف: <b>{int(order.get('discount_percent', 0) or 0)}٪</b> "
        f"({int(order.get('discount_amount', 0) or 0):,} تومان) — "
        f"<code>{esc(order.get('coupon') or '—')}</code>\n"
        + (f"↩️ بازپرداخت ثبت‌شده: <b>{esc(order.get('refund_status'))}</b>\n" if order.get("refund_status") else "")
        + f"📦 سفارش: <code>{esc(order.get('order_id'))}</code>\n"
        f"📌 وضعیت: <b>{status_labels.get(str(order.get('status')), esc(order.get('status') or '—'))}</b>\n"
        f"🕒 ثبت: <b>{display_dt(order.get('created_at'))}</b>"
    )


def _order_receipt_file(order: dict[str, Any]) -> io.BytesIO | None:
    payload = read_receipt_bytes(order)
    if not payload:
        return None
    file_obj = io.BytesIO(payload)
    file_obj.name = "sentinel-receipt.webp"
    return file_obj


def _order_keyboard(order: dict[str, Any], *, page: int | None = None) -> InlineKeyboardMarkup:
    rows: list[list[InlineKeyboardButton]] = []
    if order.get("status") == "pending":
        rows.append(
            [
                InlineKeyboardButton("✅ تأیید امن", callback_data=f"approve:{order['order_id']}"),
                InlineKeyboardButton("❌ رد", callback_data=f"reject:{order['order_id']}"),
            ]
        )
    if order.get("status") == "approved" and order.get("refund_status") != "full":
        rows.append(
            [
                InlineKeyboardButton("↩️ ثبت بازپرداخت کامل", callback_data=f"discount_refund_confirm:{order['order_id']}:full"),
                InlineKeyboardButton("➗ ثبت بازپرداخت جزئی", callback_data=f"discount_refund_confirm:{order['order_id']}:partial"),
            ]
        )
    if page is not None:
        rows.append([InlineKeyboardButton("🔙 فهرست سفارش‌ها", callback_data=f"a_pending:{max(0, page)}")])
    return InlineKeyboardMarkup(rows)


async def _notify_admins_about_order(bot, order: dict[str, Any]) -> bool:
    caption = _order_caption(order)
    keyboard = _order_keyboard(order)
    success = False
    admin_targets: set[int] = set()
    for permission in (
        PERMISSION_PAYMENTS, PERMISSION_PAYMENT_DASHBOARD_VIEW,
        PERMISSION_PAYMENT_RECEIPTS_VIEW, PERMISSION_PAYMENT_RECEIPT_APPROVE,
        PERMISSION_PAYMENT_RECEIPT_REJECT, PERMISSION_PAYMENT_MANUAL_REVIEW,
    ):
        admin_targets.update(_admin_ids_for_permission(permission))
    for admin_id in sorted(admin_targets):
        try:
            receipt_file = _order_receipt_file(order)
            if order.get("receipt_file_id"):
                await _telegram_request_with_button_fallback(
                    bot.send_photo,
                    admin_id,
                    order["receipt_file_id"],
                    caption=caption,
                    parse_mode=ParseMode.HTML,
                    reply_markup=keyboard,
                )
            elif receipt_file:
                await _telegram_request_with_button_fallback(
                    bot.send_photo,
                    admin_id,
                    receipt_file,
                    caption=caption,
                    parse_mode=ParseMode.HTML,
                    reply_markup=keyboard,
                )
            else:
                await _telegram_request_with_button_fallback(
                    bot.send_message, admin_id, caption, parse_mode=ParseMode.HTML, reply_markup=keyboard
                )
            success = True
        except TelegramError:
            logger.exception("Could not notify admin %s about order %s", admin_id, order.get("order_id"))
    return success


def _notification_retry_at(attempts: int) -> str:
    delay_seconds = min(21_600, 60 * (2 ** min(max(1, attempts), 8)))
    return utc_iso(utc_now() + timedelta(seconds=delay_seconds))


def _notification_due(order: dict[str, Any], prefix: str) -> bool:
    retry_at = parse_dt(order.get(f"{prefix}_notification_next_retry_at"))
    return retry_at is None or retry_at <= utc_now()


def _mark_order_admin_notified(db: dict[str, Any], order_id: str) -> None:
    order = find_vip_order(db, order_id)
    if order:
        order["admin_notified_at"] = utc_iso()
        order["admin_notification_last_error"] = None
        order["admin_notification_next_retry_at"] = None


def _mark_order_admin_notify_failed(db: dict[str, Any], order_id: str) -> None:
    order = find_vip_order(db, order_id)
    if order:
        attempts = int(order.get("admin_notification_attempts", 0) or 0) + 1
        order["admin_notification_attempts"] = attempts
        order["admin_notification_last_error"] = "all admin notifications failed"
        order["admin_notification_next_retry_at"] = _notification_retry_at(attempts)


async def _notify_order_user(bot, order: dict[str, Any]) -> bool:
    from modules.economic_refunds import notification_order_snapshot
    order = await async_with_db(lambda db: notification_order_snapshot(db,order))
    if not order:
        return False
    if order.get("refund_status") == "full":
        return True
    if not await async_with_db(lambda db: route_notification(db, order["user_id"], "payment")):
        return True
    status = order.get("status")
    language = _language_for_user(order.get("user_id"))
    if status == "approved" and order.get("gift_id"):
        text = "✅ پرداخت هدیه VIP تأیید شد. از منوی اشتراک ← هدیه VIP کد و لینک هدیه را دریافت کنید."
    elif status == "approved":
        reward_points = int(order.get("purchase_points_amount", 0) or 0)
        text = (
            f"✅ <b>Your payment was approved.</b>\nYour subscription is active until <b>{display_dt(order.get('expires_at'))}</b>."
            if language == "en"
            else f"✅ <b>پرداخت شما تأیید شد.</b>\nاشتراک تا <b>{display_dt(order.get('expires_at'))}</b> فعال است."
        )
        if reward_points > 0:
            text += (
                f"\n🎁 <b>{reward_points} points</b> were added for your private subscription purchase."
                if language == "en"
                else f"\n🎁 بابت خرید اشتراک خصوصی <b>{reward_points} امتیاز</b> به حساب شما اضافه شد."
            )
        if order.get("invite_link"):
            text += (
                f"\n\n🔗 One-time VIP channel invite:\n{esc(order['invite_link'])}"
                if language == "en"
                else f"\n\n🔗 لینک یک‌بارمصرف ورود به کانال VIP:\n{esc(order['invite_link'])}"
            )
    elif status == "rejected":
        text = "❌ Your VIP order was not approved. Contact support for follow-up." if language == "en" else "❌ سفارش VIP شما تأیید نشد. برای پیگیری با پشتیبانی تماس بگیرید."
    else:
        return False
    try:
        await _telegram_request_with_button_fallback(bot.send_message, int(order["user_id"]), text, parse_mode=ParseMode.HTML)
        return True
    except TelegramError:
        logger.exception("Could not notify order user %s for %s", order.get("user_id"), order.get("order_id"))
        return False


def _mark_order_user_notification(db: dict[str, Any], order_id: str, success: bool) -> None:
    order = find_vip_order(db, order_id)
    if not order:
        return
    if success:
        order["user_notified_at"] = utc_iso()
        order["user_notification_last_error"] = None
        order["user_notification_next_retry_at"] = None
    else:
        attempts = int(order.get("user_notification_attempts", 0) or 0) + 1
        order["user_notification_attempts"] = attempts
        order["user_notification_last_error"] = "telegram delivery failed"
        order["user_notification_next_retry_at"] = _notification_retry_at(attempts)


def _vip_plan_label(plan: dict[str, Any], language: str = "fa") -> str:
    language = normalize_language(language)
    price = int(plan.get("price", 0) or 0)
    days = int(plan.get("duration_days", 30) or 30)
    marker = "⭐ " if plan.get("highlight") else ""
    return (
        f"{marker}{str(plan.get('name_en') or plan.get('name') or 'VIP plan')} — {price:,} IRT / {days} days"[:62]
        if language == "en"
        else f"{marker}{str(plan.get('name') or 'پلن VIP')} — {price:,} تومان / {days} روز"[:62]
    )


def _vip_plan_detail_text(plan: dict[str, Any], settings: dict[str, Any], status_line: str = "", language: str = "fa") -> str:
    language = normalize_language(language)
    feature_source = plan.get("features_en") if language == "en" and plan.get("features_en") else plan.get("features", [])
    features = [str(item).strip() for item in feature_source if str(item).strip()]
    feature_text = "\n".join(f"• {esc(item)}" for item in features[:8]) or "• دسترسی به امکانات VIP"
    original = int(plan.get("original_price", 0) or 0)
    original_line = f"\nقیمت قبل: <s>{original:,} تومان</s>" if original > int(plan.get("price", 0) or 0) else ""
    active_methods: list[str] = []
    card_digits = "".join(ch for ch in str(settings.get("card_number") or "") if ch.isdigit())
    if len(card_digits) == 16 and str(settings.get("owner_name") or "").strip():
        active_methods.append("کارت بانکی")
    if (
        bool(settings.get("usdt_enabled", False))
        and str(settings.get("usdt_wallet_address") or "").strip()
        and float(settings.get("usdt_rate_toman", 0) or 0) > 0
    ):
        active_methods.append(f"تتر روی شبکه {str(settings.get('usdt_network') or 'TRC20').upper()}")
    method_line = "، ".join(active_methods) or "در حال حاضر روشی فعال نیست"
    if language == "en":
        english_methods: list[str] = []
        if len(card_digits) == 16 and str(settings.get("owner_name") or "").strip():
            english_methods.append("Bank card")
        if (
            bool(settings.get("usdt_enabled", False))
            and str(settings.get("usdt_wallet_address") or "").strip()
            and float(settings.get("usdt_rate_toman", 0) or 0) > 0
        ):
            english_methods.append(f"USDT on {str(settings.get('usdt_network') or 'TRC20').upper()}")
        original_line_en = f"\nOriginal price: <s>{original:,} IRT</s>" if original > int(plan.get("price", 0) or 0) else ""
        feature_text_en = "\n".join(f"• {esc(item)}" for item in features[:8]) or "• Access to VIP features"
        return (
            f"💎 <b>{esc(plan.get('name_en') or plan.get('name') or 'VIP plan')}</b>\n\n"
            f"{esc(plan.get('description_en') or plan.get('description') or '')}\n\n"
            f"💰 Price: <b>{int(plan.get('price', 0) or 0):,} IRT</b>{original_line_en}\n"
            f"🗓 Duration: <b>{int(plan.get('duration_days', 30) or 30)} days</b>\n"
            f"💠 Active payment methods: <b>{esc(', '.join(english_methods) or 'No method is currently active')}</b>\n\n"
            f"<b>Plan features</b>\n{feature_text_en}{status_line}"
        )
    return (
        f"💎 <b>{esc(plan.get('name') or 'پلن VIP')}</b>\n\n"
        f"{esc(plan.get('description') or '')}\n\n"
        f"💰 مبلغ: <b>{int(plan.get('price', 0) or 0):,} تومان</b>{original_line}\n"
        f"🗓 مدت: <b>{int(plan.get('duration_days', 30) or 30)} روز</b>\n"
        f"💠 روش‌های پرداخت فعال: <b>{esc(method_line)}</b>\n\n"
        f"<b>امکانات پلن</b>\n{feature_text}{status_line}"
    )


def _user_has_vip_purchase(db: dict[str, Any], user_id: int | str) -> bool:
    uid = str(user_id)
    return any(
        isinstance(order, dict) and str(order.get("user_id")) == uid and str(order.get("status")) == "approved"
        for order in db.get("vip_orders", [])
    )


async def u_vip(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    await run_blocking(register_current_user, update)
    db = await async_snapshot()
    language = _language_for_user(query.from_user.id)
    plans = active_vip_plans(
        db, user_is_vip=is_vip(db, query.from_user.id), user_has_purchased=_user_has_vip_purchase(db, query.from_user.id)
    )
    await async_with_db(
        lambda current: record_user_activity(current, query.from_user.id, "vip_page_viewed", source="subscription", detail="vip_plans")
    )
    vip = db.get("vip_users", {}).get(str(query.from_user.id), {})
    status_lines: list[str] = []
    if is_vip(db, query.from_user.id):
        status_lines.append(
            f"✅ VIP active until: <b>{display_dt(vip.get('expires_at'))}</b>"
            if language == "en"
            else f"✅ اشتراک فعال تا: <b>{display_dt(vip.get('expires_at'))}</b>"
        )
    pending = next(
        (
            order
            for order in reversed(db.get("vip_orders", []))
            if str(order.get("user_id")) == str(query.from_user.id) and order.get("status") in {"pending", "approving"}
        ),
        None,
    )
    if pending:
        status_lines.append(
            f"⏳ Order under review: <code>{esc(pending.get('order_id'))}</code>"
            if language == "en"
            else f"⏳ سفارش در حال بررسی: <code>{esc(pending.get('order_id'))}</code>"
        )
    rows = [[InlineKeyboardButton(_vip_plan_label(plan, language), callback_data=f"vip_plan:{int(plan['id'])}")] for plan in plans]
    rows.append([InlineKeyboardButton("🎁 هدیه VIP", callback_data="u_gifts")])
    rows.append([InlineKeyboardButton("💳 سفارش‌های من و پیگیری پرداخت", callback_data="user_orders")])
    rows.extend(back("home", language=language))
    if not plans:
        text_value = "💎 <b>VIP subscription</b>\n\nNo active plan is currently available." if language == "en" else "💎 <b>اشتراک VIP</b>\n\nدر حال حاضر پلن فعالی برای خرید وجود ندارد."
    else:
        text_value = (
            "💎 <b>Choose a VIP plan</b>\n\nSelect a plan to view details, price and payment options.\n\n"
            if language == "en"
            else "💎 <b>انتخاب پلن اشتراک</b>\n\nپلن مناسب را انتخاب کنید تا جزئیات، مبلغ و مسیر پرداخت نمایش داده شود.\n\n"
        ) + (
            "\n".join(status_lines) if status_lines else ""
        )
    await edit(query, text_value, rows)
    return ConversationHandler.END


async def vip_plan_select(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    language = _language_for_user(query.from_user.id)
    try:
        plan_id = int(str(query.data or "").split(":", 1)[1])
    except (TypeError, ValueError):
        await query.answer("Invalid plan." if language == "en" else "پلن نامعتبر است", show_alert=True)
        return
    db = await async_snapshot()
    plan = get_vip_plan(db, plan_id)
    available_ids = {
        int(item.get("id", 0) or 0)
        for item in active_vip_plans(
            db, user_is_vip=is_vip(db, query.from_user.id), user_has_purchased=_user_has_vip_purchase(db, query.from_user.id)
        )
    }
    if not plan or plan_id not in available_ids:
        await query.answer("This plan is not available." if language == "en" else "این پلن در حال حاضر قابل خرید نیست", show_alert=True)
        return
    context.user_data.pop("buy_gift_id", None)
    context.user_data["buy_plan_id"] = plan_id
    context.user_data.pop("buy_payment_method", None)
    context.user_data.pop("buy_coupon", None)
    await async_with_db(
        lambda current: record_user_activity(
            current,
            query.from_user.id,
            "vip_plan_selected",
            source="subscription",
            detail=str(plan_id),
            metadata={"plan_name": plan.get("name"), "price": int(plan.get("price", 0) or 0)},
        )
    )
    settings = db.get("vip_settings", {})
    methods = _available_payment_methods(db)
    rows: list[list[InlineKeyboardButton]] = []
    if "card" in methods:
        rows.append([InlineKeyboardButton("💳 Bank card payment" if language == "en" else "💳 پرداخت با کارت بانکی", callback_data="vip_pay_method:card")])
    if "usdt" in methods:
        network = str(settings.get("usdt_network") or "TRC20").upper()
        rows.append([InlineKeyboardButton(f"₮ Pay with USDT ({network})" if language == "en" else f"₮ پرداخت با تتر ({network})", callback_data="vip_pay_method:usdt")])
    rows.extend(back("home", language=language))
    guidance = (
        ("\n\nChoose a payment method. Submit the required evidence after payment for admin verification." if language == "en" else "\n\nروش پرداخت را انتخاب کنید. پس از پرداخت، تصویر رسید برای بررسی ادمین ارسال می‌شود.")
        if methods
        else f"\n\n{_payment_unavailable_text(language)}"
    )
    await edit(query, _vip_plan_detail_text(plan, settings, language=language) + guidance, rows)


async def vip_payment_method_select(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    language = _language_for_user(query.from_user.id)
    method = str(query.data or "").split(":", 1)[1].strip().lower()
    db = await async_snapshot()
    plan = get_vip_plan(db, context.user_data.get("buy_plan_id"))
    if not plan:
        await edit(query, "Choose a subscription plan first." if language == "en" else "ابتدا پلن اشتراک را انتخاب کنید.", back("home", language=language))
        return ConversationHandler.END
    if not _payment_method_ready(db, method):
        await edit(
            query,
            "❌ This payment method is not active or fully configured." if language == "en" else "❌ این روش پرداخت در حال حاضر فعال یا کامل نیست.",
            back("home", language=language),
        )
        return ConversationHandler.END
    context.user_data["buy_payment_method"] = method
    context.user_data.pop("buy_coupon", None)
    context.user_data.pop("buy_transaction_hash", None)
    context.user_data.pop("buy_quote_expires_at", None)
    if method == "usdt":
        settings = db.get("vip_settings", {})
        valid_minutes = int(
            settings.get("usdt_quote_valid_minutes", SETTINGS.usdt_quote_valid_minutes) or SETTINGS.usdt_quote_valid_minutes
        )
        context.user_data["buy_quote_expires_at"] = utc_iso(utc_now() + timedelta(minutes=max(5, valid_minutes)))
        context.user_data["buy_quote_rate_toman"] = float(settings.get("usdt_rate_toman", 0) or 0)
    await async_with_db(
        lambda current: record_user_activity(
            current,
            query.from_user.id,
            "vip_payment_method_selected",
            source="subscription",
            detail=method,
            metadata={"plan_id": int(plan.get("id", 0) or 0)},
        )
    )
    rows = [
        [
            InlineKeyboardButton("✅ I have a coupon" if language == "en" else "✅ کد تخفیف دارم", callback_data="buy_has_coupon"),
            InlineKeyboardButton("➡️ Continue without coupon" if language == "en" else "➡️ ادامه بدون کد", callback_data="buy_no_coupon"),
        ],
        *back("home", language=language),
    ]
    method_text = _payment_instructions(plan, db.get("vip_settings", {}), method, language=language)
    await edit(query, method_text + ("\n\nYou can enter a coupon in the next step." if language == "en" else "\n\nدر صورت داشتن کد تخفیف، آن را در مرحله بعد وارد کنید."), rows)
    return ConversationHandler.END


async def buy_has_coupon(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    language = _language_for_user(query.from_user.id)
    db = await async_snapshot()
    plan = get_vip_plan(db, context.user_data.get("buy_plan_id"))
    method = str(context.user_data.get("buy_payment_method") or "").lower()
    if not plan:
        await edit(query, "Choose a subscription plan first." if language == "en" else "ابتدا پلن اشتراک را انتخاب کنید.", back("home", language=language))
        return ConversationHandler.END
    if not _payment_method_ready(db, method):
        await edit(
            query,
            "Choose an active payment method first." if language == "en" else "ابتدا یک روش پرداخت فعال را انتخاب کنید.",
            back("home", language=language),
        )
        return ConversationHandler.END
    await async_with_db(
        lambda current: record_user_activity(
            current,
            query.from_user.id,
            "vip_coupon_step",
            source="subscription",
            detail=str(plan["id"]),
            metadata={"payment_method": method},
        )
    )
    await edit(
        query, "🎟 Send your coupon code:" if language == "en" else "🎟 کد تخفیف را ارسال کنید:", back("home", language=language)
    )
    return BUY_COUPON


async def buy_no_coupon(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    language = _language_for_user(query.from_user.id)
    db = await async_snapshot()
    plan = get_vip_plan(db, context.user_data.get("buy_plan_id"))
    method = str(context.user_data.get("buy_payment_method") or "").lower()
    if not plan:
        await edit(query, "Choose a subscription plan first." if language == "en" else "ابتدا پلن اشتراک را انتخاب کنید.", back("home", language=language))
        return ConversationHandler.END
    if not _payment_method_ready(db, method):
        await edit(
            query,
            "Choose an active payment method first." if language == "en" else "ابتدا یک روش پرداخت فعال را انتخاب کنید.",
            back("home", language=language),
        )
        return ConversationHandler.END
    context.user_data["buy_coupon"] = None
    await async_with_db(
        lambda current: record_user_activity(
            current,
            query.from_user.id,
            "vip_checkout_started",
            source="subscription",
            detail=str(plan["id"]),
            metadata={"payment_method": method},
        )
    )
    await async_with_db(
        lambda current: record_user_activity(
            current,
            query.from_user.id,
            "vip_receipt_requested",
            source="subscription",
            detail=str(plan["id"]),
            metadata={"payment_method": method},
        )
    )
    instructions = _payment_instructions(plan, db.get("vip_settings", {}), method, language=language)
    await edit(query, instructions, back("home", language=language))
    return BUY_RECEIPT


async def buy_coupon_text(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    language = _language_for_user(update.effective_user.id)
    code = (update.message.text or "").strip().upper()
    db = await async_snapshot()
    plan = get_vip_plan(db, context.user_data.get("buy_plan_id"))
    method = str(context.user_data.get("buy_payment_method") or "").lower()
    if not plan:
        await reply(
            update,
            "❌ The selected plan was not found. Start again from subscriptions." if language == "en" else "❌ پلن انتخابی پیدا نشد. دوباره از بخش اشتراک شروع کنید.",
            [[InlineKeyboardButton("Choose plan" if language == "en" else "انتخاب پلن", callback_data="u_vip")]],
        )
        return ConversationHandler.END
    if not _payment_method_ready(db, method):
        await reply(
            update,
            "❌ The selected payment method is no longer active." if language == "en" else "❌ روش پرداخت انتخاب‌شده دیگر فعال نیست.",
            [[InlineKeyboardButton("Choose payment method" if language == "en" else "انتخاب روش پرداخت", callback_data=f"vip_plan:{plan['id']}")]],
        )
        return ConversationHandler.END

    valid, message, item = await async_with_db(
        lambda current: validate_discount(
            current,
            code,
            update.effective_user.id,
            plan_id=plan.get("id"),
            product_type="vip",
            order_amount=int(plan.get("price", 0) or 0),
            payment_method=method,
        )
    )
    if not valid or not item:
        await reply(update, f"❌ {esc(message)}\nEnter the code again or use /cancel." if language == "en" else f"❌ {esc(message)}\nدوباره کد را وارد کنید یا /cancel بزنید.")
        return BUY_COUPON
    pricing = calculate_discount_amount(item, int(plan.get("price", 0) or 0))
    context.user_data["buy_coupon"] = code
    context.user_data["buy_discount_percent"] = int(pricing["effective_percent"])
    context.user_data["buy_discount_amount"] = int(pricing["discount_amount"])
    final_price = int(pricing["final_amount"])
    await async_with_db(
        lambda current: record_user_activity(
            current,
            update.effective_user.id,
            "vip_checkout_started",
            source="subscription",
            detail=str(plan["id"]),
            metadata={
                "coupon": code,
                "discount": int(pricing["effective_percent"]),
                "discount_amount": int(pricing["discount_amount"]),
                "payment_method": method,
            },
        )
    )
    if final_price == 0:
        await reply(update, "✅ The coupon is valid and the final amount is zero; the order will be submitted for admin approval." if language == "en" else "✅ کد معتبر است و مبلغ نهایی صفر شد؛ سفارش برای تأیید ادمین ثبت می‌شود.")
        await submit_vip_order(update, context, receipt_file_id=None)
        return ConversationHandler.END
    instructions = _payment_instructions(
        plan,
        db.get("vip_settings", {}),
        method,
        discount_percent=int(pricing["effective_percent"]),
        final_price_override=final_price,
        language=language,
    )
    await reply(
        update,
        (
            f"✅ Coupon accepted.\nDiscount: <b>{int(pricing['discount_amount']):,} IRT</b>\n"
            f"Final amount: <b>{final_price:,} IRT</b>\n\n{instructions}"
            if language == "en"
            else f"✅ کد معتبر است.\nتخفیف: <b>{int(pricing['discount_amount']):,} تومان</b>\n"
            f"مبلغ نهایی: <b>{final_price:,} تومان</b>\n\n{instructions}"
        ),
    )
    return BUY_RECEIPT


async def buy_txid_text(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    language = _language_for_user(update.effective_user.id)
    raw = str(update.message.text or "").strip()
    try:
        txid = normalize_txid(raw)
    except ValueError as exc:
        await reply(update, f"❌ {esc(exc)}\nSend the TXID again or use /cancel." if language == "en" else f"❌ {esc(exc)}\nTXID را دوباره ارسال کنید یا /cancel بزنید.")
        return BUY_TXID
    if txid_used((await async_snapshot()), txid):
        await reply(update, "❌ This TXID is already assigned to another order. Send a different valid transaction." if language == "en" else "❌ این TXID قبلاً برای سفارش دیگری ثبت شده است. تراکنش معتبر دیگری ارسال کنید.")
        return BUY_TXID
    context.user_data["buy_transaction_hash"] = txid
    await reply(update, "✅ TXID saved. Now send the receipt image or transaction screenshot." if language == "en" else "✅ TXID ثبت شد. اکنون تصویر رسید یا اسکرین‌شات تراکنش را ارسال کنید.")
    return BUY_RECEIPT


def _set_order_verification(db: dict[str, Any], order_id: str, result: dict[str, Any]) -> dict[str, Any] | None:
    order = find_vip_order(db, order_id)
    if not order:
        return None
    order.update(
        {
            "verification_status": str(result.get("status") or "manual_review"),
            "verification_verified": bool(result.get("verified", False)),
            "verification_provider": str(result.get("provider") or ""),
            "verification_reason": str(result.get("reason") or ""),
            "verification_checked_at": result.get("checked_at") or utc_iso(),
            "received_amount_usdt": str(result.get("amount") or ""),
            "received_destination": str(result.get("destination") or ""),
            "confirmation_count": max(0, int(result.get("confirmations", 0) or 0)),
        }
    )
    return dict(order)


def _create_pending_order(
    db: dict,
    user: Any,
    coupon_code: str | None,
    receipt_file_id: str | None,
    plan_id: int | str | None,
    payment_method: str = "card",
    transaction_hash: str = "",
    quote_expires_at: str | None = None,
) -> tuple[dict | None, str | None]:
    method = str(payment_method or "card").strip().lower()
    if method not in {"card", "usdt"}:
        return None, "روش پرداخت نامعتبر است."
    if not _payment_method_ready(db, method):
        return None, "روش پرداخت انتخاب‌شده فعال یا کامل نیست."
    existing = next(
        (
            order
            for order in db.setdefault("vip_orders", [])
            if str(order.get("user_id")) == str(user.id) and order.get("status") in {"pending", "approving"}
        ),
        None,
    )
    if existing:
        return None, "یک سفارش در حال بررسی دارید."

    plan = get_vip_plan(db, plan_id)
    if not plan or not bool(plan.get("active", True)):
        return None, "پلن اشتراک انتخاب‌شده معتبر یا فعال نیست."
    price = int(plan.get("price", 0) or 0)
    discount = None
    if coupon_code:
        valid, message, discount = validate_discount(
            db,
            coupon_code,
            user.id,
            plan_id=plan.get("id"),
            product_type="vip",
            order_amount=price,
            payment_method=method,
        )
        if not valid or not discount:
            return None, message

    pricing = calculate_discount_amount(discount, price) if discount else {
        "configured_percent": 0, "effective_percent": 0, "discount_amount": 0, "final_amount": price
    }
    percent = int(pricing["effective_percent"])
    final_price = int(pricing["final_amount"])
    if final_price > 0 and not receipt_file_id:
        return None, "برای این سفارش باید تصویر فیش ارسال شود."
    normalized_txid = ""
    if method == "usdt" and str(transaction_hash or "").strip():
        # TXID is optional metadata in the manual-review flow. When supplied,
        # normalize and deduplicate it, but never auto-verify or require it.
        try:
            normalized_txid = normalize_txid(transaction_hash)
        except ValueError as exc:
            return None, str(exc)
        if txid_used(db, normalized_txid):
            return None, "این TXID قبلاً برای سفارش دیگری استفاده شده است."

    settings = db.get("vip_settings", {})
    payment_snapshot: dict[str, Any] = {"payment_method": method}
    if method == "usdt":
        amount = _usdt_amount(final_price, settings.get("usdt_rate_toman", 0))
        payment_snapshot.update(
            {
                "payment_amount_usdt": format(amount, "f"),
                "payment_network": str(settings.get("usdt_network") or "TRC20").upper(),
                "payment_wallet": str(settings.get("usdt_wallet_address") or ""),
                "payment_rate_toman": float(settings.get("usdt_rate_toman", 0) or 0),
                "transaction_hash": normalized_txid,
                "quote_expires_at": quote_expires_at,
                "verification_status": "manual_review",
                "verification_verified": False,
            }
        )
    else:
        payment_snapshot.update(
            {
                "payment_card_number": str(settings.get("card_number") or ""),
                "payment_card_owner": str(settings.get("owner_name") or ""),
            }
        )

    order_id = uuid.uuid4().hex[:10].upper()
    order = {
        "order_id": order_id,
        "user_id": int(user.id),
        "username": user.username or "",
        "first_name": user.first_name or "",
        "plan_id": int(plan.get("id", 0) or 0),
        "plan_name": str(plan.get("name") or "VIP استاندارد"),
        "duration_days": int(plan.get("duration_days", 30) or 30),
        "base_price": price,
        "discount_percent": percent,
        "discount_configured_percent": int(pricing.get("configured_percent", percent)),
        "discount_amount": int(pricing.get("discount_amount", 0)),
        "price": final_price,
        "coupon": coupon_code or "",
        "receipt_file_id": receipt_file_id,
        "status": "pending",
        "created_at": utc_iso(),
        "admin_notified_at": None,
        "admin_notification_attempts": 0,
        "user_notified_at": None,
        "user_notification_attempts": 0,
        **payment_snapshot,
    }
    if discount:
        reserve_discount(discount, order_id, user.id, db=db)
    db["vip_orders"].append(order)
    record_user_activity(
        db,
        user.id,
        "vip_order_created",
        source="subscription",
        detail=order_id,
        metadata={
            "plan_id": order["plan_id"],
            "plan_name": order["plan_name"],
            "price": final_price,
            "coupon": coupon_code or "",
            "payment_method": method,
        },
    )
    return order, None


async def _create_normalized_manual_order(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
    receipt_file_id: str | None,
) -> dict[str, Any]:
    """Create one normalized order for both Telegram and Mini App checkout paths."""
    from modules.miniapp_product import create_checkout_quote, store_receipt_bytes
    from modules.receipt_storage import delete_receipt_blob
    from repositories.v2.commerce import CommerceRepository
    from services.vip_order_projection import project_normalized_order_to_legacy
    from services.vip_discount_bridge import reserve_normalized_order_discount, release_normalized_order_discount
    from repositories.v2.common import new_id

    user = update.effective_user
    coupon = str(context.user_data.get("buy_coupon") or "")
    plan_id = context.user_data.get("buy_plan_id")
    payment_method = str(context.user_data.get("buy_payment_method") or "card").lower()
    transaction_hash = str(context.user_data.get("buy_transaction_hash") or "").strip()
    snapshot = await async_snapshot()
    quote = create_checkout_quote(
        snapshot,
        user.id,
        plan_id=plan_id,
        payment_method=payment_method,
        coupon=coupon,
    )
    repo = CommerceRepository()
    await run_blocking(repo.create_quote, user.id, quote)

    receipt_id = ""
    stored_blob: dict[str, Any] | None = None
    if int(quote.get("payable_toman") or 0) > 0:
        if not receipt_file_id:
            raise ValueError("RECEIPT_REQUIRED")
        telegram_file = await context.bot.get_file(receipt_file_id)
        payload = bytes(await telegram_file.download_as_bytearray())
        stored_blob = await run_blocking(
            store_receipt_bytes,
            {"receipt_uploads": {}},
            payload=payload,
            content_type="image/jpeg",
            user_id=user.id,
            original_name="telegram-payment-receipt.jpg",
        )
        try:
            receipt = await run_blocking(
                repo.create_receipt,
                user.id,
                {**stored_blob, "id": stored_blob.get("receipt_id"), "mime_type": stored_blob.get("mime") or "image/webp"},
            )
        except Exception:
            await run_blocking(delete_receipt_blob, stored_blob)
            raise
        receipt_id = str(receipt.get("id") or receipt.get("receipt_id") or "")

    planned_order_id = new_id("ord")
    reserved = await run_blocking(reserve_normalized_order_discount, planned_order_id, user.id, quote)
    try:
        order = await run_blocking(
            repo.submit_order_from_quote,
            user.id,
            quote_id=str(quote["quote_id"]),
            receipt_id=receipt_id,
            transaction_hash=transaction_hash,
            profile={"username": user.username or "", "first_name": user.first_name or ""},
            order_id=planned_order_id,
        )
    except Exception:
        if reserved:
            await run_blocking(
                release_normalized_order_discount,
                {**quote, "id": planned_order_id, "user_id": user.id},
            )
        # The normalized receipt remains available for a safe retry. It is not
        # deleted here because a transient DB failure must not destroy evidence.
        raise
    return await run_blocking(project_normalized_order_to_legacy, order["id"]) or order


async def submit_vip_order(update: Update, context: ContextTypes.DEFAULT_TYPE, receipt_file_id: str | None) -> bool:
    language = _language_for_user(update.effective_user.id)
    payment_method = str(context.user_data.get("buy_payment_method") or "card").lower()
    try:
        if context.user_data.get("buy_gift_id"):
            from modules.vip_gifts import gift_for_owner
            def create_gift_order(db):
                gift = gift_for_owner(db, update.effective_user.id, context.user_data["buy_gift_id"])
                if gift.get("order_id"):
                    return find_vip_order(db, gift["order_id"])
                if gift["status"] != "pending_payment": raise ValueError("هدیه قابل پرداخت نیست.")
                order, error = _create_pending_order(db, update.effective_user, context.user_data.get("buy_coupon"), receipt_file_id,
                    gift["plan_id"], payment_method, context.user_data.get("buy_transaction_hash", ""), context.user_data.get("buy_quote_expires_at"))
                if not order: raise ValueError(error or "سفارش ثبت نشد.")
                db["vip_gifts"][gift["gift_id"]].update(duration_days=order["duration_days"], price=order["price"])
                order["gift_id"] = gift["gift_id"]
                db["vip_gifts"][gift["gift_id"]]["order_id"] = order["order_id"]
                return order
            order = await async_with_db(create_gift_order)
        else:
            order = await _create_normalized_manual_order(update, context, receipt_file_id)
    except Exception as exc:
        logger.exception("Normalized manual VIP order creation failed user_id=%s", update.effective_user.id)
        await reply(
            update,
            f"❌ {esc(str(exc) or ('The order could not be submitted.' if language == 'en' else 'ثبت سفارش انجام نشد.'))}",
            main_menu(update.effective_user.id),
        )
        return False

    notified = await _notify_admins_about_order(context.bot, order)
    await async_with_db(
        lambda db: _mark_order_admin_notified(db, order["order_id"]) if notified else _mark_order_admin_notify_failed(db, order["order_id"])
    )
    note = "" if notified else ("\n⚠️ Admin notification failed temporarily; the bot will retry automatically." if language == "en" else "\n⚠️ اعلان ادمین موقتاً ناموفق بود و ربات خودکار دوباره تلاش می‌کند.")
    await reply(
        update,
        (
            f"✅ Order <code>{order['order_id']}</code> was submitted via <b>{'USDT' if payment_method == 'usdt' else 'Bank card'}</b> for manual receipt review.{note}"
            if language == "en"
            else f"✅ سفارش <code>{order['order_id']}</code> با روش <b>{_payment_method_label(payment_method)}</b> ثبت شد و پس از بررسی دستی رسید توسط ادمین تعیین تکلیف می‌شود.{note}"
        ),
        main_menu(update.effective_user.id),
    )
    for key in (
        "buy_gift_id", "buy_coupon", "buy_discount_percent", "buy_plan_id", "buy_payment_method",
        "buy_transaction_hash", "buy_quote_expires_at", "buy_quote_rate_toman",
    ):
        context.user_data.pop(key, None)
    return True


async def buy_receipt(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    language = _language_for_user(update.effective_user.id)
    photo = update.message.photo[-1] if update.message and update.message.photo else None
    if not photo:
        await reply(update, "❌ Send the receipt as an image." if language == "en" else "❌ لطفاً فیش را به‌صورت تصویر ارسال کنید.")
        return BUY_RECEIPT
    await submit_vip_order(update, context, photo.file_id)
    return ConversationHandler.END


async def buy_receipt_invalid(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    await reply(update, "❌ فقط تصویر فیش قابل قبول است. تصویر را ارسال کنید یا /cancel بزنید.")
    return BUY_RECEIPT


async def admin_approve(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin_all(update, (PERMISSION_PAYMENT_RECEIPT_APPROVE, PERMISSION_PAYMENT_VIP_ACTIVATE)):
        return
    query = update.callback_query
    await query.answer("در حال تأیید امن…")
    order_id = query.data.split(":", 1)[1]
    admin_id = int(query.from_user.id)

    legacy_order = find_vip_order(await async_snapshot(), order_id)
    if legacy_order and legacy_order.get("gift_id"):
        from modules.vip_gifts import approve_gift_order, redeem_gift
        try:
            gift = await async_with_db(lambda db: approve_gift_order(db, order_id, admin_id))
            if gift.get("recipient_user_id"):
                await async_with_db(lambda db: redeem_gift(db, gift["recipient_user_id"], gift["gift_token"]))
            await mark_callback_message(query, "\n\n✅ پرداخت هدیه تأیید شد؛ از بخش هدیه VIP قابل دریافت است.")
        except (ValueError, PermissionError) as exc:
            await mark_callback_message(query, f"\n\n❌ {esc(str(exc))}")
        return

    # Normalized orders created from either Telegram or the Mini App use the
    # same approval orchestrator and therefore produce the same entitlement,
    # one-use invite link and user notification.
    from repositories.v2.commerce import CommerceRepository
    from services.vip_payment_orchestrator import approve_manual_vip_order
    normalized = await run_blocking(CommerceRepository().get, order_id)
    if normalized:
        try:
            approved = await approve_manual_vip_order(context.bot, order_id, admin_id)
        except Exception as exc:
            logger.exception("Normalized VIP approval failed order_id=%s", order_id)
            await mark_callback_message(query, f"\n\n❌ <b>تأیید انجام نشد:</b> {esc(str(exc))}")
            return
        await mark_callback_message(
            query,
            f"\n\n✅ <b>رسید دستی تأیید شد؛ اشتراک فعال و لینک ورود برای کاربر ارسال شد.</b>\nاعتبار: {esc(approved.get('expires_at') or '—')}",
        )
        return

    claimed = await async_with_db(lambda db: claim_vip_order_approval(db, order_id, admin_id))
    if not claimed:
        await mark_callback_message(query, "\n\n⚠️ <b>این سفارش قبلاً پردازش شده یا در حال پردازش است.</b>")
        return

    # Legacy pre-v8.13 orders are also reviewed manually. A TXID may be
    # displayed as optional evidence, but no blockchain verifier can block or
    # auto-approve the administrator decision.

    snapshot = await async_snapshot()
    days = int(claimed.get("duration_days") or snapshot.get("vip_settings", {}).get("duration_days", 30) or 30)
    automation = automation_settings(snapshot)
    bonus_days = int(automation.get("early_renewal_bonus_days", 0) or 0) if is_vip(snapshot, claimed["user_id"]) else 0
    days += bonus_days
    expiry = projected_vip_expiry(snapshot, claimed["user_id"], days)
    invite_url: str | None = None
    try:
        invite_url = await restore_vip_channel_access(context.bot, int(claimed["user_id"]), utc_iso(expiry))
        stored = await async_with_db(lambda db: store_vip_order_processing_invite(db, order_id, admin_id, invite_url or ""))
        if not stored:
            if invite_url:
                await context.bot.revoke_chat_invite_link(
                    chat_id=SETTINGS.private_channel_id,
                    invite_link=invite_url,
                )
            await async_with_db(lambda db: release_vip_order_approval(db, order_id, admin_id, "approval claim changed before finalization"))
            await mark_callback_message(query, "\n\n⚠️ <b>سفارش توسط عملیات دیگری تغییر کرده است.</b>")
            return
    except Exception as exc:
        logger.exception("Could not prepare VIP channel access for order %s", order_id)
        error_text = str(exc)
        await async_with_db(lambda db, error=error_text: release_vip_order_approval(db, order_id, admin_id, error))
        await mark_callback_message(
            query,
            "\n\n❌ <b>تأیید انجام نشد؛ ساخت لینک یا دسترسی کانال ناموفق بود. سفارش همچنان معلق است.</b>",
        )
        return

    try:
        approved = await async_with_db(lambda db: finalize_vip_order_approval(db, order_id, admin_id, invite_url or "", expiry))
    except Exception as exc:
        logger.exception("Could not finalize approved order %s", order_id)
        error_text = str(exc)
        await async_with_db(lambda db, error=error_text: release_vip_order_approval(db, order_id, admin_id, error))
        try:
            if invite_url:
                await context.bot.revoke_chat_invite_link(
                    chat_id=SETTINGS.private_channel_id,
                    invite_link=invite_url,
                )
        except TelegramError:
            logger.exception("Could not revoke unused invite link for order %s", order_id)
        await mark_callback_message(query, "\n\n❌ <b>ثبت نهایی تأیید ناموفق بود؛ سفارش معلق باقی ماند.</b>")
        return

    if not approved:
        try:
            if invite_url:
                await context.bot.revoke_chat_invite_link(
                    chat_id=SETTINGS.private_channel_id,
                    invite_link=invite_url,
                )
        except TelegramError:
            logger.exception("Could not revoke unused invite link for order %s", order_id)
        await mark_callback_message(query, "\n\n⚠️ <b>سفارش توسط عملیات دیگری پردازش شده است.</b>")
        return

    notified = await _notify_order_user(context.bot, approved)
    await async_with_db(
        lambda db: (
            _mark_order_user_notification(db, order_id, notified),
            record_retention_conversion(
                db,
                user_id=approved["user_id"],
                order_id=str(order_id),
                value=int(approved.get("price", 0) or 0),
            ),
        )
    )
    suffix = "\n\n✅ <b>تأیید شد و لینک ورود ساخته شد.</b>"
    if not notified:
        suffix += "\n⚠️ ارسال پیام به کاربر ناموفق بود؛ ربات خودکار دوباره تلاش می‌کند."
    await mark_callback_message(query, suffix)


async def discount_refund_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_PAYMENT_REFUND_REQUEST):
        return
    query = update.callback_query
    await query.answer()
    _, order_id, refund_type = str(query.data).split(":", 2)
    if refund_type not in {'full', 'partial'}:
        await query.answer('نوع بازپرداخت نامعتبر است', show_alert=True)
        return
    from modules.economic_refunds import resolve_order
    order, _ = await run_blocking(resolve_order, await async_snapshot(), order_id, timeout=15)
    if not order or order.get("status") != "approved":
        await query.answer("سفارش تأییدشده پیدا نشد", show_alert=True)
        return
    label = "کامل" if refund_type == "full" else "جزئی"
    await edit(
        query,
        f"⚠️ <b>ثبت بازپرداخت {label}</b>\n\n"
        "این دکمه پول را منتقل نمی‌کند؛ فقط بعد از انجام بازپرداخت واقعی، وضعیت سفارش، کوپن و پاداش‌های مرتبط و دارای سند را تسویه می‌کند. موارد قدیمی بدون سند، برای بررسی مدیر ثبت می‌شوند.\n\n"
        f"سفارش: <code>{esc(order_id)}</code>\nکد: <code>{esc(order.get('coupon'))}</code>",
        [
            [InlineKeyboardButton("✅ بازپرداخت انجام شده؛ ثبت کن", callback_data=f"discount_refund_do:{order_id}:{refund_type}")],
            [InlineKeyboardButton("❌ انصراف", callback_data="admin_cat:sales")],
        ],
    )


async def discount_refund_do(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_PAYMENT_REFUND_APPROVE):
        return
    query = update.callback_query
    await query.answer("در حال ثبت…")
    _, order_id, refund_type = str(query.data).split(":", 2)
    if refund_type not in {'full', 'partial'}:
        await query.answer('نوع بازپرداخت نامعتبر است', show_alert=True)
        return

    from modules.economic_refunds import record_order_refund
    try:
        order, restored = await async_with_db(lambda db: record_order_refund(db,order_id,refund_type,query.from_user.id))
    except ValueError as exc:
        await query.answer(str(exc),show_alert=True)
        return
    if not order:
        await query.answer("قبلاً ثبت شده یا سفارش نامعتبر است", show_alert=True)
        return
    if refund_type == "full":
        from services.vip_payment_orchestrator import reconcile_refunded_invites
        try:
            await reconcile_refunded_invites(context.bot,order_id=order_id)
        except Exception:
            logger.exception("Refund follow-up remains pending order=%s",order_id)
    suffix = "کد دوباره قابل استفاده شد." if restored else "کد طبق سیاست کمپین بازگردانی نشد."
    if order.get("refund_review_required"):
        suffix += "\nبازگردانی منابع قابل شناسایی انجام شد؛ پاداش‌های قدیمی یا مصرف‌شده بدون شواهد کافی، در مرکز رخدادها برای بررسی ثبت شدند."
    elif refund_type=="full":
        suffix += "\nامتیاز و VIP مرتبط با خرید، با ثبت سند برگشت تسویه شدند."
    await edit(
        query,
        f"✅ بازپرداخت <b>{'کامل' if refund_type == 'full' else 'جزئی'}</b> ثبت شد.\n{suffix}",
        [[InlineKeyboardButton("↩️ سفارش", callback_data="admin_cat:sales")]],
    )


async def admin_reject(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_PAYMENT_RECEIPT_REJECT):
        return
    query = update.callback_query
    await query.answer()
    order_id = query.data.split(":", 1)[1]

    from repositories.v2.commerce import CommerceRepository
    from services.vip_payment_orchestrator import reject_manual_vip_order
    normalized = await run_blocking(CommerceRepository().get, order_id)
    if normalized:
        try:
            await reject_manual_vip_order(
                context.bot, order_id, int(query.from_user.id), "رسید یا اطلاعات پرداخت توسط ادمین تأیید نشد."
            )
        except Exception as exc:
            logger.exception("Normalized VIP rejection failed order_id=%s", order_id)
            await mark_callback_message(query, f"\n\n⚠️ <b>رد سفارش انجام نشد:</b> {esc(str(exc))}")
            return
        await mark_callback_message(query, "\n\n❌ <b>رسید رد شد و نتیجه برای کاربر ارسال شد.</b>")
        return

    def reject(db: dict) -> tuple[dict | None, str | None]:
        order = find_vip_order(db, order_id)
        if not order or order.get("status") != "pending":
            return None, "سفارش قبلاً پردازش شده، در حال تأیید است یا وجود ندارد."
        release_discount(db, order)
        order.update(
            {
                "status": "rejected",
                "rejected_at": utc_iso(),
                "rejected_by": int(query.from_user.id),
                "user_notified_at": None,
                "user_notification_attempts": 0,
            }
        )
        audit(db, query.from_user.id, "reject_vip", order_id)
        return dict(order), None

    rejected, error = await async_with_db(reject)
    if not rejected:
        await mark_callback_message(query, f"\n\n⚠️ <b>{esc(error or 'رد سفارش انجام نشد.')}</b>")
        return
    notified = await _notify_order_user(context.bot, rejected)
    await async_with_db(lambda db: _mark_order_user_notification(db, order_id, notified))
    suffix = "\n\n❌ <b>رد شد</b>"
    if not notified:
        suffix += "\n⚠️ پیام کاربر در صف تلاش مجدد قرار گرفت."
    await mark_callback_message(query, suffix)


async def _calculator_show(update: Update, text: str, rows: list[list[InlineKeyboardButton]] | None = None) -> None:
    if update.callback_query:
        await edit(update.callback_query, text, rows or [])
    else:
        await reply(update, text, rows)


def _calculator_symbol_rows(market: str, language: str = "fa") -> list[list[InlineKeyboardButton]]:
    symbols = FOREX_SIGNAL_SYMBOLS if market == MARKET_FOREX else CRYPTO_SIGNAL_SYMBOLS
    rows = [[InlineKeyboardButton(symbol, callback_data=f"calc_symbol:{symbol}")] for symbol in symbols]
    rows.append([InlineKeyboardButton("✏️ Custom symbol" if language == "en" else "✏️ نماد دلخواه", callback_data="calc_symbol:manual")])
    rows.append([InlineKeyboardButton("🔙 Market type" if language == "en" else "🔙 نوع بازار", callback_data="u_calc")])
    return rows



def _calculator_profile(db: dict[str, Any], user_id: int | str) -> dict[str, float | None]:
    raw = db.setdefault("calculator_profiles", {}).setdefault(
        str(user_id), {"capital": None, "forex_leverage": None, "crypto_leverage": None}
    )
    return {
        "capital": float(raw["capital"]) if raw.get("capital") not in {None, ""} else None,
        "forex_leverage": float(raw["forex_leverage"]) if raw.get("forex_leverage") not in {None, ""} else None,
        "crypto_leverage": float(raw["crypto_leverage"]) if raw.get("crypto_leverage") not in {None, ""} else None,
    }


def _calculator_profile_set(db: dict[str, Any], user_id: int | str, field: str, value: float) -> dict[str, float | None]:
    if field not in {"capital", "forex_leverage", "crypto_leverage"}:
        raise ValueError("CALCULATOR_PROFILE_FIELD_INVALID")
    profile = db.setdefault("calculator_profiles", {}).setdefault(str(user_id), {})
    profile[field] = float(value)
    profile["updated_at"] = utc_iso()
    return _calculator_profile(db, user_id)


def _calculator_profile_rows(profile: dict[str, float | None], language: str) -> list[list[InlineKeyboardButton]]:
    capital = profile.get("capital")
    forex = profile.get("forex_leverage")
    crypto = profile.get("crypto_leverage")
    return [
        [InlineKeyboardButton(
            (f"💰 Capital: ${capital:,.2f}" if capital else "💰 Set capital")
            if language == "en" else (f"💰 سرمایه: {capital:,.2f}" if capital else "💰 ثبت سرمایه"),
            callback_data="calc_profile:capital",
        )],
        [
            InlineKeyboardButton(
                (f"💱 Forex leverage: {forex:g}×" if forex else "💱 Forex leverage")
                if language == "en" else (f"💱 اهرم فارکس: {forex:g}×" if forex else "💱 اهرم فارکس"),
                callback_data="calc_profile:forex_leverage",
            ),
            InlineKeyboardButton(
                (f"⚡ Crypto leverage: {crypto:g}×" if crypto else "⚡ Crypto leverage")
                if language == "en" else (f"⚡ اهرم کریپتو: {crypto:g}×" if crypto else "⚡ اهرم کریپتو"),
                callback_data="calc_profile:crypto_leverage",
            ),
        ],
    ]


async def calc_profile_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    language = _language_for_user(query.from_user.id)
    field = query.data.split(":", 1)[1]
    if field not in {"capital", "forex_leverage", "crypto_leverage"}:
        await query.answer("گزینه نامعتبر است.", show_alert=True)
        return CALC_MARKET
    context.user_data["calc_profile_field"] = field
    labels = {
        "capital": "مقدار سرمایه ثابت را به دلار/تتر وارد کنید:",
        "forex_leverage": "اهرم ثابت فارکس را وارد کنید؛ مثال 100:",
        "crypto_leverage": "اهرم ثابت کریپتو را وارد کنید؛ مثال 10:",
    }
    labels_en = {
        "capital": "Enter your saved capital in USD/USDT:",
        "forex_leverage": "Enter saved Forex leverage, e.g. 100:",
        "crypto_leverage": "Enter saved crypto leverage, e.g. 10:",
    }
    await edit(query, labels_en[field] if language == "en" else labels[field], [[InlineKeyboardButton("⬅️ Back" if language == "en" else "⬅️ برگشت", callback_data="u_calc")]])
    return CALC_PROFILE_INPUT


async def calc_profile_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    language = _language_for_user(update.effective_user.id)
    field = str(context.user_data.get("calc_profile_field") or "")
    maximum = 1_000_000_000_000 if field == "capital" else (1000 if field == "forex_leverage" else 125)
    try:
        value = parse_finite_float(update.effective_message.text, positive=True, maximum=maximum)
        profile = await async_with_db(lambda db: _calculator_profile_set(db, update.effective_user.id, field, value))
    except (ValueError, KeyError) as exc:
        await reply(update, f"❌ {esc(exc)}")
        return CALC_PROFILE_INPUT
    context.user_data.pop("calc_profile_field", None)
    label = "سرمایه" if field == "capital" else ("اهرم فارکس" if field == "forex_leverage" else "اهرم کریپتو")
    await reply(
        update,
        (f"✅ {label} ذخیره شد. از این مقدار در محاسبه‌های بعدی استفاده می‌شود." if language != "en" else "✅ Calculator preference saved."),
        [[InlineKeyboardButton("🧮 ماشین‌حساب" if language != "en" else "🧮 Calculator", callback_data="u_calc")]],
    )
    return ConversationHandler.END


async def _calculator_ask_balance_source(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    language = _language_for_user(update.effective_user.id)
    profile = await async_with_db(lambda db: _calculator_profile(db, update.effective_user.id))
    capital = profile.get("capital")
    if capital:
        rows = [[
            InlineKeyboardButton(
                (f"💰 My capital (${capital:,.2f})" if language == "en" else f"💰 سرمایه خودم ({capital:,.2f})"),
                callback_data="calc_balance_choice:stored",
            ),
            InlineKeyboardButton("✏️ New capital" if language == "en" else "✏️ سرمایه جدید", callback_data="calc_balance_choice:new"),
        ], [[InlineKeyboardButton("⬅️ Back" if language == "en" else "⬅️ برگشت", callback_data="u_calc")]][0]]
        await _calculator_show(
            update,
            "Choose the capital source:" if language == "en" else "سرمایه مورد استفاده را انتخاب کنید:",
            rows,
        )
        return CALC_BALANCE_CHOICE
    await _calculator_show(
        update,
        "💰 Enter account balance in USD/USDT, for example <code>1000</code>."
        if language == "en" else "💰 موجودی حساب به دلار/تتر را وارد کنید؛ مثال: <code>1000</code>",
        [[InlineKeyboardButton("⬅️ Back" if language == "en" else "⬅️ برگشت", callback_data="u_calc")]],
    )
    return CALC_BALANCE


async def _calculator_ask_risk(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    language = _language_for_user(update.effective_user.id)
    rows = [
        [InlineKeyboardButton("۰.۵٪", callback_data="risk:0.5"), InlineKeyboardButton("۱٪", callback_data="risk:1"), InlineKeyboardButton("۲٪", callback_data="risk:2")],
        [InlineKeyboardButton("۳٪", callback_data="risk:3"), InlineKeyboardButton("✏️ Custom" if language == "en" else "✏️ ورود دستی", callback_data="risk:manual")],
    ]
    await _calculator_show(update, "📉 Choose risk percentage:" if language == "en" else "📉 درصد ریسک از کل موجودی را انتخاب کنید:", rows)
    return CALC_RISK


async def calc_balance_choice(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    choice = query.data.split(":", 1)[1]
    language = _language_for_user(query.from_user.id)
    if choice == "new":
        await edit(query, "Enter new capital:" if language == "en" else "مقدار سرمایه جدید را وارد کنید:", [[InlineKeyboardButton("⬅️ Back" if language == "en" else "⬅️ برگشت", callback_data="u_calc")]])
        return CALC_BALANCE
    profile = await async_with_db(lambda db: _calculator_profile(db, query.from_user.id))
    capital = profile.get("capital")
    if not capital:
        await edit(query, "No saved capital. Enter capital:" if language == "en" else "سرمایه ذخیره‌شده ندارید؛ مقدار سرمایه را وارد کنید:", [[InlineKeyboardButton("⬅️ Back" if language == "en" else "⬅️ برگشت", callback_data="u_calc")]])
        return CALC_BALANCE
    context.user_data.setdefault("calc", {})["balance"] = float(capital)
    return await _calculator_ask_risk(update, context)

async def u_calc(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    language = _language_for_user(query.from_user.id)
    context.user_data.pop("calc", None)
    profile = await async_with_db(lambda db: _calculator_profile(db, query.from_user.id))
    rows = [
        [InlineKeyboardButton("💱 Forex, metals & CFD" if language == "en" else "💱 فارکس، طلا و CFD", callback_data="calc_market:forex")],
        [InlineKeyboardButton("🪙 Crypto spot" if language == "en" else "🪙 کریپتو اسپات", callback_data="calc_market:crypto_spot")],
        [InlineKeyboardButton("⚡ Crypto futures" if language == "en" else "⚡ کریپتو فیوچرز", callback_data="calc_market:crypto_futures")],
        *_calculator_profile_rows(profile, language),
        [InlineKeyboardButton("↩️ Main menu" if language == "en" else "↩️ منوی اصلی", callback_data="home", style="primary")],
    ]
    text = (
        "🧮 <b>Professional risk calculator</b>\n\nChoose a market and trade type. Position size is calculated from balance, risk, stop distance, leverage and fees."
        if language == "en"
        else "🧮 <b>ماشین‌حساب حرفه‌ای مدیریت ریسک</b>\n\nبازار و نوع معامله را انتخاب کنید. حجم بر اساس موجودی، درصد ریسک، فاصله استاپ، اهرم و کارمزد محاسبه می‌شود:"
    )
    await edit(
        query,
        text,
        rows,
    )
    return CALC_MARKET


async def signal_calc_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Open the risk calculator with market and symbol prefilled from a visible signal."""
    query = update.callback_query
    language = _language_for_user(query.from_user.id)
    try:
        signal_id = int(query.data.split(":", 1)[1])
    except (TypeError, ValueError, IndexError):
        await query.answer("Invalid signal." if language == "en" else "سیگنال نامعتبر است.", show_alert=True)
        return ConversationHandler.END
    db = await async_snapshot()
    row = _find_user_visible_signal(db, query.from_user.id, signal_id)
    if not row:
        await query.answer("Signal unavailable." if language == "en" else "سیگنال در دسترس نیست.", show_alert=True)
        return ConversationHandler.END
    category = signal_market_category(row)
    symbol = normalize_market_symbol(str(row.get("symbol") or ""))
    if not symbol:
        await query.answer("Signal symbol is unavailable." if language == "en" else "نماد سیگنال معتبر نیست.", show_alert=True)
        return ConversationHandler.END
    mode = "crypto_futures" if category == MARKET_CRYPTO else "forex"
    context.user_data["calc"] = {
        "mode": mode,
        "market_category": category,
        "language": language,
        "symbol": symbol,
        "source_signal_id": signal_id,
    }
    await query.answer()
    return await _calculator_ask_balance_source(update, context)


async def calc_market_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    mode = query.data.split(":", 1)[1]
    if mode not in {"forex", "crypto_spot", "crypto_futures"}:
        await query.answer("نوع بازار نامعتبر است", show_alert=True)
        return CALC_MARKET
    market = MARKET_FOREX if mode == "forex" else MARKET_CRYPTO
    language = _language_for_user(query.from_user.id)
    context.user_data["calc"] = {"mode": mode, "market_category": market, "language": language}
    label = ("Forex" if market == MARKET_FOREX else "Crypto") if language == "en" else market_label(market)
    await edit(
        query,
        f"📌 Choose a <b>{label}</b> symbol:" if language == "en" else f"📌 نماد {label} را انتخاب کنید:",
        _calculator_symbol_rows(market, language),
    )
    return CALC_SYMBOL


async def calc_symbol(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    language = _language_for_user(query.from_user.id)
    value = query.data.split(":", 1)[1]
    if value == "manual":
        await edit(
            query,
            "✏️ Enter a symbol, for example <code>EURUSD</code> or <code>BTCUSDT</code>."
            if language == "en"
            else "✏️ نماد را وارد کنید؛ نمونه: <code>EURUSD</code> یا <code>BTCUSDT</code>",
            [[InlineKeyboardButton("🔙 Calculator" if language == "en" else "🔙 ماشین‌حساب", callback_data="u_calc")]],
        )
        return CALC_SYMBOL
    context.user_data.setdefault("calc", {})["symbol"] = value.upper()
    return await _calculator_ask_balance_source(update, context)


async def calc_symbol_text(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    language = _language_for_user(update.effective_user.id)
    raw = re.sub(r"[^A-Za-z0-9]", "", (update.effective_message.text or "").upper())
    if not 3 <= len(raw) <= 20:
        await reply(update, "❌ Enter a valid symbol such as <code>XAUUSD</code> or <code>ETHUSDT</code>." if language == "en" else "❌ نماد معتبر وارد کنید؛ مثال: <code>XAUUSD</code> یا <code>ETHUSDT</code>")
        return CALC_SYMBOL
    data = context.user_data.setdefault("calc", {})
    expected = data.get("market_category", MARKET_FOREX)
    detected = classify_market_symbol(raw)
    if expected != detected:
        text = (
            "❌ This symbol belongs to another market. Restart the calculator and choose the correct market."
            if language == "en"
            else f"❌ این نماد در دسته <b>{market_label(detected)}</b> قرار می‌گیرد. از منوی ماشین‌حساب دسته درست را انتخاب کنید."
        )
        await reply(update, text, [[InlineKeyboardButton("🔁 Choose market" if language == "en" else "🔁 انتخاب بازار", callback_data="u_calc")]])
        return CALC_SYMBOL
    data["symbol"] = raw
    return await _calculator_ask_balance_source(update, context)


async def calc_balance(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    language = _language_for_user(update.effective_user.id)
    try:
        context.user_data["calc"]["balance"] = parse_finite_float(update.message.text, positive=True, maximum=1_000_000_000_000)
    except (ValueError, KeyError) as exc:
        await reply(update, "❌ Enter a valid positive number:" if language == "en" else f"❌ {esc(exc)}\nعدد معتبر وارد کنید:")
        return CALC_BALANCE
    return await _calculator_ask_risk(update, context)


async def calc_risk_button(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    language = _language_for_user(query.from_user.id)
    value = query.data.split(":", 1)[1]
    if value == "manual":
        await edit(query, "📉 Enter risk percentage (maximum 20%):" if language == "en" else "📉 درصد ریسک را وارد کنید؛ بیشتر از ۲۰٪ پذیرفته نمی‌شود:", [[InlineKeyboardButton("🔙 Calculator" if language == "en" else "🔙 ماشین‌حساب", callback_data="u_calc")]])
        return CALC_RISK
    context.user_data["calc"]["risk"] = float(value)
    await edit(query, "📍 Enter the entry price:" if language == "en" else "📍 قیمت ورود را وارد کنید:", [[InlineKeyboardButton("🔙 Calculator" if language == "en" else "🔙 ماشین‌حساب", callback_data="u_calc")]])
    return CALC_ENTRY


async def calc_risk_text(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    language = _language_for_user(update.effective_user.id)
    try:
        context.user_data["calc"]["risk"] = parse_finite_float(update.message.text, positive=True, maximum=20)
    except (ValueError, KeyError) as exc:
        await reply(update, "❌ Enter a valid risk percentage." if language == "en" else f"❌ {esc(exc)}")
        return CALC_RISK
    await reply(update, "📍 Enter the entry price:" if language == "en" else "📍 قیمت ورود را وارد کنید:")
    return CALC_ENTRY


async def calc_entry(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    language = _language_for_user(update.effective_user.id)
    try:
        context.user_data["calc"]["entry"] = parse_finite_float(update.message.text, positive=True, maximum=1_000_000_000_000_000)
    except (ValueError, KeyError) as exc:
        await reply(update, "❌ Enter a valid entry price." if language == "en" else f"❌ {esc(exc)}")
        return CALC_ENTRY
    await reply(update, "🛑 Enter the stop-loss price:" if language == "en" else "🛑 قیمت حد ضرر را وارد کنید:")
    return CALC_SL


async def calc_stop(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    language = _language_for_user(update.effective_user.id)
    try:
        stop = parse_finite_float(update.message.text, positive=True, maximum=1_000_000_000_000_000)
        data = context.user_data["calc"]
        if abs(float(data["entry"]) - stop) <= 0:
            raise ValueError("Entry and stop loss must be different." if language == "en" else "قیمت ورود و حد ضرر نباید یکسان باشند.")
        data["stop"] = stop
    except (ValueError, KeyError) as exc:
        await reply(update, f"❌ {esc(exc)}")
        return CALC_SL
    mode = data.get("mode", "forex")
    if mode == "crypto_spot":
        data["leverage"] = 1.0
        return await _calculator_ask_fee(update, context)
    limits = [1, 10, 50, 100, 200, 500] if mode == "forex" else [1, 2, 3, 5, 10, 20, 50, 100]
    rows = [[InlineKeyboardButton(f"{value}×", callback_data=f"calc_leverage:{value}") for value in limits[i:i+3]] for i in range(0, len(limits), 3)]
    profile = await async_with_db(lambda db: _calculator_profile(db, update.effective_user.id))
    stored = profile.get("forex_leverage" if mode == "forex" else "crypto_leverage")
    if stored:
        # A saved leverage is the user's default. Continue automatically and
        # keep the dedicated profile menu available whenever they want to edit it.
        data["leverage"] = float(stored)
        return await _calculator_after_leverage(update, context)
    rows.append([InlineKeyboardButton("✏️ Custom leverage" if language == "en" else "✏️ اهرم دستی", callback_data="calc_leverage:manual")])
    await reply(update, "⚙️ Choose account/position leverage:" if language == "en" else "⚙️ اهرم حساب/پوزیشن را انتخاب کنید:", rows)
    return CALC_LEVERAGE


async def calc_leverage_button(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    language = _language_for_user(query.from_user.id)
    value = query.data.split(":", 1)[1]
    if value == "manual":
        await edit(query, "⚙️ Enter leverage, for example <code>10</code> or <code>100</code>:" if language == "en" else "⚙️ عدد اهرم را وارد کنید؛ مثال: <code>10</code> یا <code>100</code>:", [[InlineKeyboardButton("🔙 Calculator" if language == "en" else "🔙 ماشین‌حساب", callback_data="u_calc")]])
        return CALC_LEVERAGE
    context.user_data["calc"]["leverage"] = float(value)
    return await _calculator_after_leverage(update, context)


async def calc_leverage_text(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    try:
        mode = context.user_data["calc"].get("mode", "forex")
        maximum = 125 if mode.startswith("crypto") else 1000
        context.user_data["calc"]["leverage"] = parse_finite_float(update.message.text, positive=True, maximum=maximum)
    except (ValueError, KeyError) as exc:
        await reply(update, f"❌ {esc(exc)}")
        return CALC_LEVERAGE
    return await _calculator_after_leverage(update, context)


async def _calculator_after_leverage(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    data = context.user_data.get("calc", {})
    language = str(data.get("language") or _language_for_user(update.effective_user.id))
    if str(data.get("mode", "")).startswith("crypto"):
        return await _calculator_ask_fee(update, context)
    symbol = str(data.get("symbol") or "").upper()
    if len(symbol) == 6 and symbol.isalpha() and not symbol.startswith("USD") and not symbol.endswith("USD"):
        text = (
            f"🔁 For <b>{esc(symbol)}</b>, enter the USD conversion rate of <b>{esc(symbol[3:])}</b>.\nExample: if 1 GBP equals 1.27 USD, send <code>1.27</code>."
            if language == "en"
            else f"🔁 برای <b>{esc(symbol)}</b> نرخ تبدیل ارز مظنه <b>{esc(symbol[3:])}</b> به دلار را وارد کنید.\nمثال: اگر هر GBP برابر 1.27 USD است، <code>1.27</code> را بفرستید."
        )
        await _calculator_show(update, text)
        return CALC_CROSS
    return await _finish_calculator(update, context)


async def _calculator_ask_fee(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    language = str(context.user_data.get("calc", {}).get("language") or _language_for_user(update.effective_user.id))
    rows = [
        [InlineKeyboardButton("۰٪", callback_data="calc_fee:0"), InlineKeyboardButton("۰.۱٪", callback_data="calc_fee:0.1"), InlineKeyboardButton("۰.۲٪", callback_data="calc_fee:0.2")],
        [InlineKeyboardButton("✏️ Custom fee" if language == "en" else "✏️ کارمزد دستی", callback_data="calc_fee:manual")],
    ]
    text = (
        "💸 Choose the estimated round-trip fee percentage.\nThe exact fee depends on the exchange and your account tier."
        if language == "en"
        else "💸 مجموع تقریبی کارمزد ورود و خروج را به درصد انتخاب کنید.\nاین مقدار برای هر صرافی و سطح کاربری متفاوت است:"
    )
    await _calculator_show(update, text, rows)
    return CALC_FEE


async def calc_fee_button(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    language = _language_for_user(query.from_user.id)
    value = query.data.split(":", 1)[1]
    if value == "manual":
        await edit(query, "💸 Enter total round-trip fee as a percentage, for example <code>0.2</code>." if language == "en" else "💸 مجموع کارمزد رفت‌وبرگشت را به درصد وارد کنید؛ مثال: <code>0.2</code>", [[InlineKeyboardButton("🔙 Calculator" if language == "en" else "🔙 ماشین‌حساب", callback_data="u_calc")]])
        return CALC_FEE
    context.user_data["calc"]["fee"] = float(value)
    return await _finish_calculator(update, context)


async def calc_fee_text(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    try:
        context.user_data["calc"]["fee"] = parse_finite_float(update.message.text, positive=False, maximum=10)
        if context.user_data["calc"]["fee"] < 0:
            raise ValueError("کارمزد نمی‌تواند منفی باشد.")
    except (ValueError, KeyError) as exc:
        await reply(update, f"❌ {esc(exc)}")
        return CALC_FEE
    return await _finish_calculator(update, context)


async def calc_cross_text(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    try:
        context.user_data["calc"]["cross_rate"] = parse_finite_float(update.message.text, positive=True, maximum=1_000_000)
    except (ValueError, KeyError) as exc:
        await reply(update, f"❌ {esc(exc)}")
        return CALC_CROSS
    return await _finish_calculator(update, context)


async def _finish_calculator(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    language = str(context.user_data.get("calc", {}).get("language") or _language_for_user(update.effective_user.id))
    if not rate_limit_allow(update.effective_user.id, "risk_calculation", 2):
        await _calculator_show(update, "⏳ Please wait two seconds and try again." if language == "en" else "⏳ لطفاً دو ثانیه صبر کنید و دوباره تلاش کنید.", [[InlineKeyboardButton("🔁 Start again" if language == "en" else "🔁 شروع دوباره", callback_data="u_calc")]])
        return ConversationHandler.END
    data = context.user_data.get("calc", {})
    try:
        if str(data.get("mode", "forex")).startswith("crypto"):
            result = calculate_crypto_position_size(
                data["balance"], data["risk"], data["entry"], data["stop"],
                leverage=data.get("leverage", 1), fee_percent_round_trip=data.get("fee", 0),
            )
            constraint_en = "Margin capacity" if result.get("capped_by_margin") else "Risk budget"
            constraint_fa = "ظرفیت مارجین" if result.get("capped_by_margin") else "بودجه ریسک"
            text = (
                (
                    "📊 <b>Crypto risk result</b>\n\n"
                    f"📌 Symbol: <b>{esc(data.get('symbol'))}</b> | Mode: <b>{'Spot' if result['mode'] == 'crypto_spot' else 'Linear futures'}</b>\n"
                    f"💰 Balance: <b>${float(data['balance']):,.2f}</b> | Target risk: <b>${result['risk_amount']:,.2f}</b>\n"
                    f"📏 Stop distance: <b>{result['stop_percent']:.4f}%</b>\n"
                    f"🪙 Suggested quantity: <code>{result['quantity']:.8f}</code>\n"
                    f"💵 Position value: <b>${result['notional']:,.2f}</b>\n"
                    f"⚙️ Leverage: <b>{result['leverage']:.0f}×</b> | Estimated margin: <b>${result['estimated_margin']:,.2f}</b>\n"
                    f"💸 Assumed round-trip fee: <b>{result['fee_percent_round_trip']:.4f}%</b>\n"
                    f"🛡 Effective risk: <b>${result['effective_risk']:,.2f}</b> (<b>{result['effective_risk_percent']:.3f}%</b>)\n"
                    f"📐 Risk budget used: <b>{result['risk_budget_usage_percent']:.2f}%</b> | Margin used: <b>{result['margin_usage_percent']:.2f}%</b>\n"
                    f"🔒 Binding constraint: <b>{constraint_en}</b>"
                )
                if language == "en"
                else (
                    "📊 <b>نتیجه مدیریت ریسک کریپتو</b>\n\n"
                    f"📌 نماد: <b>{esc(data.get('symbol'))}</b> | حالت: <b>{'اسپات' if result['mode'] == 'crypto_spot' else 'فیوچرز خطی'}</b>\n"
                    f"💰 موجودی: <b>${float(data['balance']):,.2f}</b> | ریسک هدف: <b>${result['risk_amount']:,.2f}</b>\n"
                    f"📏 فاصله استاپ: <b>{result['stop_percent']:.4f}٪</b>\n"
                    f"🪙 مقدار پیشنهادی: <code>{result['quantity']:.8f}</code>\n"
                    f"💵 ارزش پوزیشن: <b>${result['notional']:,.2f}</b>\n"
                    f"⚙️ اهرم: <b>{result['leverage']:.0f}×</b> | مارجین تقریبی: <b>${result['estimated_margin']:,.2f}</b>\n"
                    f"💸 کارمزد رفت‌وبرگشت فرضی: <b>{result['fee_percent_round_trip']:.4f}٪</b>\n"
                    f"🛡 ریسک واقعی: <b>${result['effective_risk']:,.2f}</b> (<b>{result['effective_risk_percent']:.3f}٪</b>)\n"
                    f"📐 مصرف بودجه ریسک: <b>{result['risk_budget_usage_percent']:.2f}٪</b> | مصرف مارجین: <b>{result['margin_usage_percent']:.2f}٪</b>\n"
                    f"🔒 محدودکننده نهایی حجم: <b>{constraint_fa}</b>"
                )
            )
            if result.get("exceeds_spot_balance"):
                text += "\n⚠️ Spot balance is insufficient; reduce the quantity." if language == "en" else "\n⚠️ در اسپات، موجودی برای مقدار محاسبه‌شده کافی نیست؛ مقدار را تا سقف موجودی کاهش دهید."
            if result.get("below_minimum") or result.get("below_min_notional"):
                text += "\n⚠️ The calculated size is below the exchange minimum quantity/notional." if language == "en" else "\n⚠️ مقدار محاسبه‌شده از فیلتر حداقل مقدار/ارزش سفارش صرافی کمتر است."
            text += (
                "\n\n<i>Quantity step and minimum notional vary by exchange symbol. Verify the live symbol filters before placing an order.</i>"
                if language == "en"
                else "\n\n<i>گام مقدار و حداقل ارزش سفارش در هر نماد صرافی متفاوت است؛ قبل از ثبت سفارش، فیلترهای همان نماد را بررسی کنید.</i>"
            )
        else:
            result = calculate_position_size(
                symbol=data["symbol"], balance_usd=data["balance"], risk_percent=data["risk"],
                entry_price=data["entry"], stop_price=data["stop"], current_price=data["entry"],
                cross_rate=data.get("cross_rate"), leverage=data.get("leverage", 1),
            )
            constraint_en = "Margin capacity" if result.get("capped_by_margin") else "Risk budget"
            constraint_fa = "ظرفیت مارجین" if result.get("capped_by_margin") else "بودجه ریسک"
            text = (
                (
                    "📊 <b>Forex/CFD risk result</b>\n\n"
                    f"📌 Symbol: <b>{esc(result['symbol'])}</b>\n"
                    f"💰 Balance: <b>${float(data['balance']):,.2f}</b> | Target risk: <b>${result['risk_amount']:,.2f}</b>\n"
                    f"📏 Stop distance: <b>{result['pip_distance']:,.2f} pips</b>\n"
                    f"💎 Pip value per lot: <b>${result['pip_value_per_lot']:,.4f}</b>\n"
                    f"📦 Suggested size: <b>{result['lot']:.3f} Lot</b> | Units: <b>{result['units']:,.2f}</b>\n"
                    f"💵 Notional: <b>${result['notional']:,.2f}</b>\n"
                    f"⚙️ Leverage: <b>{result['leverage']:.0f}×</b> | Estimated margin: <b>${result['estimated_margin']:,.2f}</b>\n"
                    f"🛡 Effective risk: <b>${result['effective_risk']:,.2f}</b> (<b>{result['effective_risk_percent']:.3f}%</b>)\n"
                    f"📐 Raw/risk-limited/margin-limited: <b>{result['raw_lot']:.5f} / {result['risk_limited_lot']:.3f} / {result['margin_limited_lot']:.3f}</b> Lot\n"
                    f"📊 Risk budget used: <b>{result['risk_budget_usage_percent']:.2f}%</b> | Margin used: <b>{result['margin_usage_percent']:.2f}%</b>\n"
                    f"🔒 Binding constraint: <b>{constraint_en}</b>"
                )
                if language == "en"
                else (
                    "📊 <b>نتیجه مدیریت ریسک فارکس/CFD</b>\n\n"
                    f"📌 نماد: <b>{esc(result['symbol'])}</b>\n"
                    f"💰 موجودی: <b>${float(data['balance']):,.2f}</b> | ریسک هدف: <b>${result['risk_amount']:,.2f}</b>\n"
                    f"📏 فاصله استاپ: <b>{result['pip_distance']:,.2f} پیپ</b>\n"
                    f"💎 ارزش هر پیپ در یک لات: <b>${result['pip_value_per_lot']:,.4f}</b>\n"
                    f"📦 حجم پیشنهادی: <b>{result['lot']:.3f} Lot</b> | واحد: <b>{result['units']:,.2f}</b>\n"
                    f"💵 ارزش اسمی: <b>${result['notional']:,.2f}</b>\n"
                    f"⚙️ اهرم: <b>{result['leverage']:.0f}×</b> | مارجین تقریبی: <b>${result['estimated_margin']:,.2f}</b>\n"
                    f"🛡 ریسک واقعی: <b>${result['effective_risk']:,.2f}</b> (<b>{result['effective_risk_percent']:.3f}٪</b>)\n"
                    f"📐 حجم خام / محدود به ریسک / محدود به مارجین: <b>{result['raw_lot']:.5f} / {result['risk_limited_lot']:.3f} / {result['margin_limited_lot']:.3f}</b> لات\n"
                    f"📊 مصرف بودجه ریسک: <b>{result['risk_budget_usage_percent']:.2f}٪</b> | مصرف مارجین: <b>{result['margin_usage_percent']:.2f}٪</b>\n"
                    f"🔒 محدودکننده نهایی حجم: <b>{constraint_fa}</b>"
                )
            )
            if result["below_minimum"]:
                text += f"\n⚠️ The calculated size is below the minimum {result['min_lot']} lot." if language == "en" else f"\n⚠️ حجم محاسبه‌شده از حداقل {result['min_lot']} لات کمتر است."
            if result.get("note"):
                text += f"\n\nℹ️ {esc(result['note'])}"
            text += (
                "\n\n<i>Contract size, tick value and minimum lot vary by broker. Verify the symbol specification before trading.</i>"
                if language == "en"
                else "\n\n<i>اندازه قرارداد، ارزش پوینت و حداقل لات ممکن است بین بروکرها متفاوت باشد؛ مشخصات نماد بروکر را تطبیق دهید.</i>"
            )
    except (ValueError, KeyError) as exc:
        await _calculator_show(update, f"❌ {esc(exc)}", [[InlineKeyboardButton("🔁 Start again" if language == "en" else "🔁 شروع دوباره", callback_data="u_calc")]])
        return ConversationHandler.END
    except Exception:
        logger.exception("Risk calculator failed")
        await _calculator_show(update, "❌ Calculation failed. Check the inputs and start again." if language == "en" else "❌ محاسبه انجام نشد. ورودی‌ها را بررسی و دوباره شروع کنید.", [[InlineKeyboardButton("🔁 Start again" if language == "en" else "🔁 شروع دوباره", callback_data="u_calc")]])
        return ConversationHandler.END
    await async_with_db(lambda db: record_event(db, update.effective_user.id, "risk_calculator"))
    context.user_data.pop("calc", None)
    await _calculator_show(
        update,
        text,
        [
            [
                InlineKeyboardButton("🔁 New calculation" if language == "en" else "🔁 محاسبه جدید", callback_data="u_calc"),
            ],
            [InlineKeyboardButton("↩️ Main menu" if language == "en" else "↩️ منوی اصلی", callback_data="home", style="primary")],
        ],
    )
    return ConversationHandler.END



__feature_exports__ = ('_normalize_card_number', '_payment_unavailable_text', '_payment_method_ready', '_available_payment_methods', '_payment_method_label', '_usdt_amount', '_payment_instructions', '_order_caption', '_order_receipt_file', '_order_keyboard', '_notify_admins_about_order', '_notification_retry_at', '_notification_due', '_mark_order_admin_notified', '_mark_order_admin_notify_failed', '_notify_order_user', '_mark_order_user_notification', '_vip_plan_label', '_vip_plan_detail_text', '_user_has_vip_purchase', 'u_vip', 'vip_plan_select', 'vip_payment_method_select', 'buy_has_coupon', 'buy_no_coupon', 'buy_coupon_text', 'buy_txid_text', '_set_order_verification', '_create_pending_order', 'submit_vip_order', 'buy_receipt', 'buy_receipt_invalid', 'admin_approve', 'discount_refund_confirm', 'discount_refund_do', 'admin_reject', '_calculator_show', '_calculator_symbol_rows', '_calculator_profile', '_calculator_profile_set', '_calculator_profile_rows', 'calc_profile_start', 'calc_profile_input', '_calculator_ask_balance_source', '_calculator_ask_risk', 'calc_balance_choice', 'u_calc', 'signal_calc_start', 'calc_market_handler', 'calc_symbol', 'calc_symbol_text', 'calc_balance', 'calc_risk_button', 'calc_risk_text', 'calc_entry', 'calc_stop', 'calc_leverage_button', 'calc_leverage_text', '_calculator_after_leverage', '_calculator_ask_fee', 'calc_fee_button', 'calc_fee_text', 'calc_cross_text', '_finish_calculator')
