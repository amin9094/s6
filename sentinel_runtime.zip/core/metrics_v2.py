from __future__ import annotations

import threading
import time
from collections import defaultdict
from contextlib import contextmanager
from typing import Iterator

from core.observability import gauge, increment

_LOCK = threading.RLock()
_SUMS: dict[str, float] = defaultdict(float)
_COUNTS: dict[str, int] = defaultdict(int)
_MAX: dict[str, float] = defaultdict(float)
_SSE_ACTIVE = 0


def observe(name: str, seconds: float) -> None:
    clean = str(name).replace("/", "_").replace(" ", "_")
    value = max(0.0, float(seconds))
    with _LOCK:
        _SUMS[clean] += value
        _COUNTS[clean] += 1
        _MAX[clean] = max(_MAX[clean], value)
        count = _COUNTS[clean]
        total = _SUMS[clean]
        maximum = _MAX[clean]
    gauge(f"{clean}_seconds_sum", total)
    gauge(f"{clean}_seconds_count", count)
    gauge(f"{clean}_seconds_avg", total / count if count else 0)
    gauge(f"{clean}_seconds_max", maximum)


@contextmanager
def timer(name: str) -> Iterator[None]:
    started = time.monotonic()
    try:
        yield
    finally:
        observe(name, time.monotonic() - started)


def api_request(endpoint: str, method: str, status: int, duration: float) -> None:
    route = str(endpoint or "unknown").strip("/").replace("/", "_").replace("{", "").replace("}", "") or "root"
    method_name = str(method or "GET").lower()
    increment(f"api_requests_{method_name}_{route}_total")
    increment(f"api_responses_{status}_total")
    observe(f"api_latency_{method_name}_{route}", duration)


def sse_connected(delta: int) -> None:
    global _SSE_ACTIVE
    with _LOCK:
        _SSE_ACTIVE = max(0, _SSE_ACTIVE + int(delta))
        active = _SSE_ACTIVE
    if delta > 0:
        increment("sse_connections_total")
    gauge("sse_connections_active", active)


def action_result(action: str, *, ok: bool, duration: float) -> None:
    clean = str(action).replace("-", "_")
    increment(f"miniapp_action_{clean}_{'success' if ok else 'failure'}_total")
    observe(f"miniapp_action_{clean}_latency", duration)
