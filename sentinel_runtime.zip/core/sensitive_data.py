"""Transparent field-level encryption for sensitive values at rest."""

from __future__ import annotations

import base64
import copy
import hashlib
import hmac
from typing import Any

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

_PREFIX = "enc:v1:"
_SENSITIVE_KEYS = {
    "card",
    "card_number",
    "bank_card",
    "iban",
    "sheba",
    "phone",
    "phone_number",
    "mobile",
    "email",
    "wallet",
    "wallet_address",
    "payment_wallet",
    "usdt_wallet_address",
    "txid",
    "tx_hash",
    "transaction_hash",
    "receipt_hash",
    "connector_secret",
    "mt5_secret",
    "device_token",
    "gift_token",
}


def encryption_ready(secret: str) -> bool:
    return len(str(secret or "").strip()) >= 16


def _keys(secret: str) -> tuple[bytes, bytes]:
    material = hashlib.sha512(str(secret).encode("utf-8")).digest()
    return material[:32], material[32:]


def _associated_data(path: tuple[str, ...]) -> bytes:
    return ("/".join(path) or "root").encode("utf-8")


def _encrypt_value(value: str, *, path: tuple[str, ...], secret: str) -> str:
    if not value or value.startswith(_PREFIX):
        return value
    cipher_key, nonce_key = _keys(secret)
    plain = value.encode("utf-8")
    aad = _associated_data(path)
    nonce = hmac.new(nonce_key, aad + b"\0" + plain, hashlib.sha256).digest()[:12]
    encrypted = AESGCM(cipher_key).encrypt(nonce, plain, aad)
    token = base64.urlsafe_b64encode(nonce + encrypted).decode("ascii")
    return f"{_PREFIX}{token}"


def _decrypt_value(value: str, *, path: tuple[str, ...], secret: str) -> str:
    if not value.startswith(_PREFIX):
        return value
    cipher_key, _nonce_key = _keys(secret)
    payload = base64.urlsafe_b64decode(value[len(_PREFIX) :].encode("ascii"))
    if len(payload) < 29:
        raise ValueError("invalid encrypted sensitive field")
    nonce, encrypted = payload[:12], payload[12:]
    return AESGCM(cipher_key).decrypt(nonce, encrypted, _associated_data(path)).decode("utf-8")


def _transform(value: Any, *, path: tuple[str, ...], secret: str, decrypt: bool) -> Any:
    if isinstance(value, dict):
        result: dict[str, Any] = {}
        for raw_key, child in value.items():
            key = str(raw_key)
            child_path = (*path, key)
            if key.lower() in _SENSITIVE_KEYS and isinstance(child, str):
                result[raw_key] = (
                    _decrypt_value(child, path=child_path, secret=secret)
                    if decrypt
                    else _encrypt_value(child, path=child_path, secret=secret)
                )
            else:
                result[raw_key] = _transform(child, path=child_path, secret=secret, decrypt=decrypt)
        return result
    if isinstance(value, list):
        return [
            _transform(child, path=(*path, str(index)), secret=secret, decrypt=decrypt)
            for index, child in enumerate(value)
        ]
    return copy.deepcopy(value)


def protect_sensitive_payload(data: dict[str, Any], secret: str) -> dict[str, Any]:
    if not encryption_ready(secret):
        return copy.deepcopy(data)
    return _transform(data, path=(), secret=secret, decrypt=False)


def unprotect_sensitive_payload(data: dict[str, Any], secret: str) -> dict[str, Any]:
    if not encryption_ready(secret):
        return copy.deepcopy(data)
    return _transform(data, path=(), secret=secret, decrypt=True)


def mask_sensitive(value: Any, *, visible: int = 4) -> str:
    text = str(value or "")
    if not text:
        return ""
    if len(text) <= visible * 2:
        return "*" * len(text)
    return f"{text[:visible]}…{text[-visible:]}"


def protect_secret_value(value: str, secret: str, *, field_name: str = "connector_secret") -> str:
    """Encrypt a single connector credential using the application keyring."""
    payload = protect_sensitive_payload({field_name: str(value or "")}, secret)
    return str(payload.get(field_name) or "")


def unprotect_secret_value(value: str, secret: str, *, field_name: str = "connector_secret") -> str:
    """Decrypt a single connector credential using the application keyring."""
    payload = unprotect_sensitive_payload({field_name: str(value or "")}, secret)
    return str(payload.get(field_name) or "")
