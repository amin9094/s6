from __future__ import annotations

import html
import logging
import math
import os
from datetime import UTC, datetime
from logging.handlers import RotatingFileHandler
from zoneinfo import ZoneInfo

from config import SETTINGS
from core.logging_context import JsonFormatter, RedactingFilter


def configure_logging() -> None:
    SETTINGS.log_dir.mkdir(parents=True, exist_ok=True)
    structured = str(os.getenv("STRUCTURED_LOGGING", "true" if os.getenv("RAILWAY_PROJECT_ID") else "false")).lower() in {"1", "true", "yes", "on"}
    formatter: logging.Formatter = JsonFormatter() if structured else logging.Formatter(
        "%(asctime)s | %(levelname)s | %(name)s | correlation_id=%(correlation_id)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    redaction = RedactingFilter()
    root = logging.getLogger()
    root.setLevel(logging.INFO)
    root.handlers.clear()

    stream = logging.StreamHandler()
    stream.addFilter(redaction)
    stream.setFormatter(formatter)
    root.addHandler(stream)

    file_handler = RotatingFileHandler(
        SETTINGS.log_dir / "bot.log",
        maxBytes=5 * 1024 * 1024,
        backupCount=max(1, min(90, int(os.getenv("LOG_RETENTION_DAYS", "30") or 30))),
        encoding="utf-8",
    )
    file_handler.addFilter(redaction)
    file_handler.setFormatter(formatter)
    root.addHandler(file_handler)


def esc(value: object) -> str:
    return html.escape(str(value), quote=True)


def parse_finite_float(raw: str, *, positive: bool = False, maximum: float | None = None) -> float:
    value = float(str(raw).strip().replace(",", ""))
    if not math.isfinite(value):
        raise ValueError("عدد باید محدود و معتبر باشد")
    if positive and value <= 0:
        raise ValueError("عدد باید بزرگ‌تر از صفر باشد")
    if maximum is not None and value > maximum:
        raise ValueError(f"عدد نباید بیشتر از {maximum} باشد")
    return value


def parse_positive_int(raw: str, *, maximum: int | None = None) -> int:
    value = int(str(raw).strip().replace(",", ""))
    if value <= 0:
        raise ValueError("عدد باید بزرگ‌تر از صفر باشد")
    if maximum is not None and value > maximum:
        raise ValueError(f"عدد نباید بیشتر از {maximum} باشد")
    return value


def utc_now() -> datetime:
    return datetime.now(UTC)


def utc_iso(dt: datetime | None = None) -> str:
    return (dt or utc_now()).astimezone(UTC).isoformat()


def parse_dt(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=UTC)
        return dt.astimezone(UTC)
    except (TypeError, ValueError):
        return None


def display_dt(value: str | None) -> str:
    dt = parse_dt(value)
    if not dt:
        return "—"
    try:
        local = dt.astimezone(ZoneInfo(SETTINGS.timezone))
    except Exception:
        local = dt
    return local.strftime("%Y/%m/%d - %H:%M")


def chunk_text(text: str, limit: int = 3900) -> list[str]:
    if len(text) <= limit:
        return [text]
    chunks: list[str] = []
    current = ""
    for paragraph in text.splitlines(keepends=True):
        if len(current) + len(paragraph) <= limit:
            current += paragraph
            continue
        if current:
            chunks.append(current.rstrip())
        while len(paragraph) > limit:
            chunks.append(paragraph[:limit])
            paragraph = paragraph[limit:]
        current = paragraph
    if current:
        chunks.append(current.rstrip())
    return chunks
