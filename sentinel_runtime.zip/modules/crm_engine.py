from __future__ import annotations

from datetime import timedelta
from typing import Any

from core.utils import parse_dt, utc_iso, utc_now
from modules.user_intelligence import build_user_profile

CRM_STAGES = {
    "lead": "سرنخ",
    "interested": "علاقه‌مند",
    "qualified": "واجد شرایط",
    "checkout": "در آستانه خرید",
    "customer": "مشتری",
    "loyal": "وفادار",
    "at_risk": "در معرض ریزش",
    "churned": "ریزش‌کرده",
}


def calculate_lead_score(profile: dict[str, Any]) -> int:
    score = 0
    score += min(20, int(profile.get("activity_summary", {}).get("total", 0) or 0) // 5)
    score += 15 if "plan_interested" in profile.get("segments", []) else 0
    score += 20 if "checkout_started" in profile.get("segments", []) else 0
    score += 25 if int(profile.get("vip_purchase_count", 0) or 0) else 0
    score += min(15, int(profile.get("vip_purchase_count", 0) or 0) * 5)
    score += 10 if int(profile.get("referral_count", 0) or 0) else 0
    score += 5 if int(profile.get("ticket_count", 0) or 0) else 0
    score -= 20 if "churned_customer" in profile.get("segments", []) else 0
    return max(0, min(100, score))


def infer_stage(profile: dict[str, Any], score: int) -> str:
    segments = set(profile.get("segments", []))
    if "churned_customer" in segments:
        return "churned"
    if "renewal_due" in segments or ("vip_expired" in segments and score >= 35):
        return "at_risk"
    if "loyal_buyer" in segments or "high_value" in segments:
        return "loyal"
    if int(profile.get("vip_purchase_count", 0) or 0) > 0:
        return "customer"
    if "checkout_started" in segments or "pending_buyer" in segments:
        return "checkout"
    if score >= 55:
        return "qualified"
    if score >= 25:
        return "interested"
    return "lead"


def refresh_crm_profile(
    db: dict[str, Any],
    user_id: int | str,
    *,
    force: bool = False,
    max_age_seconds: int = 300,
) -> dict[str, Any]:
    uid = str(user_id)
    crm = db.setdefault("crm_profiles", {}).setdefault(uid, {})
    refreshed_at = parse_dt(crm.get("last_profile_refresh_at"))
    if (
        not force
        and refreshed_at is not None
        and refreshed_at > utc_now() - timedelta(seconds=max(15, int(max_age_seconds)))
        and str(crm.get("stage") or "") in CRM_STAGES
        and isinstance(crm.get("lead_score"), int)
    ):
        return crm
    profile = build_user_profile(db, uid)
    score = calculate_lead_score(profile)
    manual_stage = str(crm.get("manual_stage") or "")
    stage = manual_stage if manual_stage in CRM_STAGES else infer_stage(profile, score)
    crm.update(
        {
            "user_id": uid,
            "lead_score": score,
            "stage": stage,
            "stage_label": CRM_STAGES[stage],
            "segments": list(profile.get("segments", [])),
            "behavior_persona": str(profile.get("behavior_persona") or "explorer"),
            "engagement_score": int(profile.get("engagement_score", 0) or 0),
            "purchase_intent_score": int(profile.get("purchase_intent_score", 0) or 0),
            "churn_risk_score": int(profile.get("churn_risk_score", 0) or 0),
            "recency_days": int(profile.get("recency_days", 999) or 999),
            "last_profile_refresh_at": utc_iso(),
            "total_spend": int(profile.get("total_spend", 0) or 0),
            "vip_purchase_count": int(profile.get("vip_purchase_count", 0) or 0),
            "last_seen_at": profile.get("last_seen_at"),
        }
    )
    return crm


def set_crm_stage(db: dict[str, Any], user_id: int | str, stage: str, admin_id: int | str) -> dict[str, Any]:
    if stage not in CRM_STAGES:
        raise ValueError("مرحله CRM نامعتبر است")
    row = db.setdefault("crm_profiles", {}).setdefault(str(user_id), {})
    previous = str(row.get("stage") or "lead")
    row.update(
        {
            "manual_stage": stage,
            "stage": stage,
            "stage_label": CRM_STAGES[stage],
            "stage_updated_at": utc_iso(),
            "stage_admin_id": str(admin_id),
        }
    )
    from modules.crm_automation import record_crm_activity

    record_crm_activity(
        db,
        user_id,
        "stage_changed",
        actor_id=admin_id,
        detail=f"{CRM_STAGES.get(previous, previous)} → {CRM_STAGES[stage]}",
    )
    return row


def crm_pipeline_snapshot(db: dict[str, Any]) -> dict[str, list[str]]:
    output = {stage: [] for stage in CRM_STAGES}
    for uid in db.get("users", {}):
        row = refresh_crm_profile(db, uid)
        output[str(row.get("stage") or "lead")].append(str(uid))
    return output


def due_crm_followups(db: dict[str, Any], *, horizon_minutes: int = 60) -> list[dict[str, Any]]:
    now = utc_now()
    horizon = now + timedelta(minutes=max(0, min(int(horizon_minutes), 1440)))
    profiles = db.get("crm_profiles", {})
    if not isinstance(profiles, dict):
        profiles = {}
    due: list[dict[str, Any]] = []
    for uid, row in profiles.items():
        if not isinstance(row, dict):
            continue
        if str(row.get("follow_up_status") or "scheduled") not in {"scheduled", "notified"}:
            continue
        stamp = parse_dt(row.get("follow_up_at"))
        if not stamp or stamp > horizon or row.get("follow_up_notified_at"):
            continue
        item = {
            "user_id": str(uid),
            "follow_up_at": stamp.isoformat(),
            "note": str(row.get("follow_up_note") or ""),
            "assigned_admin": str(row.get("assigned_admin") or ""),
        }
        # Preserve the compact legacy payload for old records while exposing
        # the richer fields as soon as an operator has configured them.
        if "follow_up_priority" in row:
            item["priority"] = str(row.get("follow_up_priority") or "normal")
        if "follow_up_type" in row:
            item["type"] = str(row.get("follow_up_type") or "call")
        if "follow_up_repeat" in row:
            item["repeat"] = str(row.get("follow_up_repeat") or "none")
        due.append(item)
    return sorted(due, key=lambda item: item["follow_up_at"])


def mark_followup_notified(db: dict[str, Any], user_id: int | str) -> None:
    row = db.setdefault("crm_profiles", {}).setdefault(str(user_id), {})
    row["follow_up_notified_at"] = utc_iso()
    row["follow_up_status"] = "notified"
    row["updated_at"] = utc_iso()
