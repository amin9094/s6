"""Case context for the existing CRM screens and deterministic Back routing."""
from __future__ import annotations

import re
from typing import Any

CASE_KEY = "crm_case_context"


def crm_case_parent(context: Any, uid: str | int) -> str:
    case = context.user_data.get(CASE_KEY) or {}
    parent = str(case.get("parent") or "") if str(case.get("uid")) == str(uid) else ""
    if re.fullmatch(r"(?:a_crm|crm_pipeline_stage:[a-z_]+:\d+|crm_segment:[a-z_]+:\d+|funnel_users:(?:abandoned|viewers):(?:7|30|90):\d+)", parent):
        return parent
    return "a_crm"


def select_crm_case(context: Any, uid: str | int, parent: str | None = None) -> None:
    uid = str(uid)
    previous = crm_case_parent(context, uid)
    context.user_data[CASE_KEY] = {"uid": uid, "parent": parent or previous}
    context.user_data["admin_user_uid"] = uid


def crm_action_uid(context: Any, callback: str) -> str:
    """Explicit IDs win; legacy keyboards use only the current selected case."""
    match = re.fullmatch(r"crm_(?:note|tag|followup|followup_clear)(?::(\d+))?", str(callback))
    if not match:
        return ""
    uid = match.group(1) or str(context.user_data.get("admin_user_uid") or "")
    if not uid.isdigit():
        return ""
    select_crm_case(context, uid)
    return uid


def crm_open_parent(callback: str) -> str | None:
    parts = str(callback).split(":")
    if len(parts) == 5 and parts[2] in {"p", "s"} and re.fullmatch(r"[a-z_]+", parts[3]) and parts[4].isdigit():
        prefix = "crm_pipeline_stage" if parts[2] == "p" else "crm_segment"
        return f"{prefix}:{parts[3]}:{parts[4]}"
    if len(parts) == 6 and parts[2] == "f" and parts[3] in {"abandoned", "viewers"} and parts[4] in {"7", "30", "90"} and parts[5].isdigit():
        return f"funnel_users:{parts[3]}:{parts[4]}:{parts[5]}"
    return None
