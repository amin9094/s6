from __future__ import annotations

import secrets
from collections import Counter
from datetime import timedelta
from typing import Any

from core.utils import parse_dt, utc_iso, utc_now

DEFAULT_SECURITY_WINDOW_MINUTES = 15
DEFAULT_SECURITY_MAX_FAILURES = 8
DEFAULT_SECURITY_BLOCK_MINUTES = 15
MAX_DISCOUNT_EVENT_ROWS = 30_000
MAX_AFFILIATE_ROWS = 20_000


def _int(value: Any, default: int = 0) -> int:
    try:
        return int(str(value if value is not None else default).replace(",", "").strip())
    except (TypeError, ValueError):
        return default


def _bool(value: Any, default: bool = False) -> bool:
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    text = str(value).strip().casefold()
    if text in {"1", "true", "yes", "on", "بله", "فعال"}:
        return True
    if text in {"0", "false", "no", "off", "خیر", "غیرفعال"}:
        return False
    return default


def _string_list(value: Any) -> list[str]:
    if value is None or value == "":
        return []
    if isinstance(value, str):
        parts = value.replace("؛", ",").replace("|", ",").split(",")
    elif isinstance(value, (list, tuple, set)):
        parts = list(value)
    else:
        parts = [value]
    result: list[str] = []
    for part in parts:
        text = str(part or "").strip()
        if text and text not in result:
            result.append(text)
    return result


def _int_list(value: Any) -> list[int]:
    result: list[int] = []
    for part in _string_list(value):
        try:
            number = int(part)
        except (TypeError, ValueError):
            continue
        if number > 0 and number not in result:
            result.append(number)
    return result


def normalize_campaign_fields(item: dict[str, Any]) -> dict[str, Any]:
    """Backfill and sanitize enterprise discount campaign fields in-place."""
    item.setdefault("applicable_product_types", ["vip"])
    item["applicable_product_types"] = [
        value for value in _string_list(item.get("applicable_product_types")) if value in {"vip", "course", "all"}
    ] or ["vip"]
    item["applicable_plan_ids"] = _int_list(item.get("applicable_plan_ids"))
    item["excluded_plan_ids"] = _int_list(item.get("excluded_plan_ids"))
    item["allowed_crm_segments"] = _string_list(item.get("allowed_crm_segments"))
    item["allowed_payment_methods"] = [
        value.lower() for value in _string_list(item.get("allowed_payment_methods")) if value.lower() in {"card", "usdt"}
    ]
    item["customer_types"] = [
        value for value in _string_list(item.get("customer_types"))
        if value in {"new_customer", "existing_customer", "active_vip", "expired_vip", "never_vip"}
    ]
    item["minimum_order_amount"] = max(0, _int(item.get("minimum_order_amount")))
    item["maximum_order_amount"] = max(0, _int(item.get("maximum_order_amount")))
    item["maximum_discount_amount"] = max(0, _int(item.get("maximum_discount_amount")))
    item["minimum_final_price"] = max(0, _int(item.get("minimum_final_price")))
    item["first_purchase_only"] = _bool(item.get("first_purchase_only"), False)
    item["renewal_only"] = _bool(item.get("renewal_only"), False)
    item["allow_on_sale_plans"] = _bool(item.get("allow_on_sale_plans"), True)
    item["stackable"] = _bool(item.get("stackable"), False)
    item["max_uses_per_user"] = max(0, _int(item.get("max_uses_per_user"), 1 if item.get("one_per_user", True) else 0))
    weekdays: list[int] = []
    for raw_day in _string_list(item.get("allowed_weekdays")):
        try:
            day = int(raw_day)
        except (TypeError, ValueError):
            continue
        if 0 <= day <= 6 and day not in weekdays:
            weekdays.append(day)
    item["allowed_weekdays"] = weekdays
    start_hour = _int(item.get("daily_start_hour"), -1)
    end_hour = _int(item.get("daily_end_hour"), -1)
    item["daily_start_hour"] = start_hour if 0 <= start_hour <= 23 else None
    item["daily_end_hour"] = end_hour if 0 <= end_hour <= 23 else None
    item["affiliate_user_id"] = str(item.get("affiliate_user_id") or "").strip()
    item["affiliate_commission_percent"] = max(0, min(100, _int(item.get("affiliate_commission_percent"))))
    item["campaign_id"] = str(item.get("campaign_id") or item.get("code") or "")[:80]
    item["parent_campaign_code"] = str(item.get("parent_campaign_code") or "").upper()[:32]
    item["release_on_reject"] = _bool(item.get("release_on_reject"), True)
    item["release_on_cancel"] = _bool(item.get("release_on_cancel"), True)
    item["restore_on_full_refund"] = _bool(item.get("restore_on_full_refund"), False)
    item["restore_on_partial_refund"] = _bool(item.get("restore_on_partial_refund"), False)
    item["fraud_protection_enabled"] = _bool(item.get("fraud_protection_enabled"), True)
    item.setdefault("updated_at", item.get("created_at") or utc_iso())
    return item


def record_discount_event(
    db: dict[str, Any],
    event_type: str,
    *,
    code: str = "",
    user_id: int | str | None = None,
    order_id: str = "",
    amount: int = 0,
    discount_amount: int = 0,
    detail: str = "",
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    counters = db.setdefault("counters", {})
    event_id = _int(counters.get("discount_event")) + 1
    counters["discount_event"] = event_id
    row = {
        "id": event_id,
        "type": str(event_type or "event")[:64],
        "code": str(code or "").upper()[:32],
        "user_id": str(user_id or ""),
        "order_id": str(order_id or "")[:64],
        "amount": max(0, _int(amount)),
        "discount_amount": max(0, _int(discount_amount)),
        "detail": str(detail or "")[:500],
        "metadata": dict(metadata or {}),
        "created_at": utc_iso(),
    }
    events = db.setdefault("discount_events", [])
    if not isinstance(events, list):
        events = []
        db["discount_events"] = events
    events.append(row)
    if len(events) > MAX_DISCOUNT_EVENT_ROWS:
        db["discount_events"] = events[-MAX_DISCOUNT_EVENT_ROWS:]
    return row


def record_discount_crm_activity(
    db: dict[str, Any],
    user_id: int | str | None,
    activity_type: str,
    *,
    code: str = "",
    detail: str = "",
    metadata: dict[str, Any] | None = None,
) -> None:
    uid = str(user_id or "")
    if not uid.isdigit():
        return
    try:
        from modules.crm_automation import record_crm_activity

        record_crm_activity(
            db,
            uid,
            activity_type,
            detail=(f"{code}: {detail}" if detail else code)[:1500],
            metadata={"discount_code": code, **dict(metadata or {})},
        )
    except Exception:
        # Discount settlement must not fail because the optional CRM timeline is unavailable.
        return


def _security_settings(db: dict[str, Any]) -> dict[str, int]:
    settings = db.setdefault("discount_security_settings", {})
    settings.setdefault("window_minutes", DEFAULT_SECURITY_WINDOW_MINUTES)
    settings.setdefault("max_failures", DEFAULT_SECURITY_MAX_FAILURES)
    settings.setdefault("block_minutes", DEFAULT_SECURITY_BLOCK_MINUTES)
    return {
        "window_minutes": max(1, _int(settings.get("window_minutes"), DEFAULT_SECURITY_WINDOW_MINUTES)),
        "max_failures": max(3, _int(settings.get("max_failures"), DEFAULT_SECURITY_MAX_FAILURES)),
        "block_minutes": max(1, _int(settings.get("block_minutes"), DEFAULT_SECURITY_BLOCK_MINUTES)),
    }


def discount_security_status(db: dict[str, Any], user_id: int | str) -> tuple[bool, str]:
    uid = str(user_id)
    row = db.setdefault("discount_security", {}).setdefault(uid, {"failures": []})
    now = utc_now()
    blocked_until = parse_dt(row.get("blocked_until"))
    if blocked_until and blocked_until > now:
        minutes = max(1, int((blocked_until - now).total_seconds() // 60) + 1)
        return False, f"به‌دلیل تلاش‌های ناموفق متعدد، ورود کد برای {minutes} دقیقه موقتاً مسدود است."
    if blocked_until and blocked_until <= now:
        row["blocked_until"] = None
    return True, "OK"


def record_discount_attempt(
    db: dict[str, Any],
    user_id: int | str,
    code: str,
    *,
    success: bool,
    reason: str = "",
) -> None:
    uid = str(user_id)
    settings = _security_settings(db)
    security = db.setdefault("discount_security", {})
    row = security.setdefault(uid, {"failures": []})
    now = utc_now()
    history = row.setdefault("history", [])
    history.append({"code": str(code or "").upper()[:32], "success": bool(success), "reason": str(reason)[:120], "created_at": utc_iso(now)})
    row["history"] = history[-50:]
    if success:
        row["failures"] = []
        row["last_success_at"] = utc_iso(now)
        row["blocked_until"] = None
        return
    cutoff = now - timedelta(minutes=settings["window_minutes"])
    failures = [value for value in row.get("failures", []) if (parse_dt(value) or now) >= cutoff]
    failures.append(utc_iso(now))
    row["failures"] = failures[-settings["max_failures"] :]
    row["last_failure_at"] = utc_iso(now)
    if len(failures) >= settings["max_failures"]:
        row["blocked_until"] = utc_iso(now + timedelta(minutes=settings["block_minutes"]))
        record_discount_event(
            db,
            "security_block",
            code=code,
            user_id=uid,
            detail=reason or "too_many_failed_attempts",
        )


def _user_has_approved_purchase(db: dict[str, Any], user_id: int | str) -> bool:
    uid = str(user_id)
    return any(
        isinstance(order, dict)
        and str(order.get("user_id")) == uid
        and str(order.get("status")) == "approved"
        for order in db.get("vip_orders", [])
    )


def _user_is_active_vip(db: dict[str, Any], user_id: int | str) -> bool:
    row = db.get("vip_users", {}).get(str(user_id), {})
    expiry = parse_dt(row.get("expires_at")) if isinstance(row, dict) else None
    return bool(expiry and expiry > utc_now() and str(row.get("status") or "active") != "expired")


def _crm_segments_for_user(db: dict[str, Any], user_id: int | str) -> set[str]:
    uid = str(user_id)
    try:
        from modules.sales_growth import crm_segment_snapshot

        snapshot = crm_segment_snapshot(db)
        return {segment for segment, members in snapshot.items() if uid in {str(value) for value in members}}
    except Exception:
        profile = db.get("user_profiles", {}).get(uid, {})
        values = profile.get("segments", []) if isinstance(profile, dict) else []
        return set(_string_list(values))


def validate_campaign_conditions(
    db: dict[str, Any],
    item: dict[str, Any],
    user_id: int | str,
    *,
    plan_id: int | str | None = None,
    product_type: str = "vip",
    order_amount: int | str | None = None,
    payment_method: str | None = None,
) -> tuple[bool, str]:
    item = normalize_campaign_fields(item)
    uid = str(user_id)
    product = str(product_type or "vip").lower()
    products = set(item.get("applicable_product_types", []))
    if "all" not in products and product not in products:
        return False, "این کد برای این نوع محصول قابل استفاده نیست."

    target_plan = _int(plan_id)
    allowed_plans = set(item.get("applicable_plan_ids", []))
    excluded_plans = set(item.get("excluded_plan_ids", []))
    if allowed_plans and target_plan not in allowed_plans:
        return False, "این کد برای پلن انتخاب‌شده قابل استفاده نیست."
    if target_plan and target_plan in excluded_plans:
        return False, "پلن انتخاب‌شده از این کمپین مستثنا شده است."

    amount = max(0, _int(order_amount))
    minimum = _int(item.get("minimum_order_amount"))
    maximum = _int(item.get("maximum_order_amount"))
    if minimum and amount < minimum:
        return False, f"حداقل مبلغ سفارش برای این کد {minimum:,} تومان است."
    if maximum and amount > maximum:
        return False, f"حداکثر مبلغ سفارش مجاز برای این کد {maximum:,} تومان است."

    methods = set(item.get("allowed_payment_methods", []))
    if methods and str(payment_method or "").lower() not in methods:
        return False, "این کد برای روش پرداخت انتخاب‌شده فعال نیست."

    audience = item.get('eligible_group', 'everyone')
    if audience == 'selected' and uid not in {str(x) for x in item.get('allowed_user_ids', [])}:
        return False, 'این کد متعلق به کاربران انتخاب‌شده است.'
    if audience == 'vip' and not _user_is_active_vip(db, uid):
        return False, 'این کد مخصوص کاربران VIP است.'
    if audience == 'nonvip' and _user_is_active_vip(db, uid):
        return False, 'این کد مخصوص کاربران غیر VIP است.'
    if audience == 'referral' and not db.get('users', {}).get(uid, {}).get('referred_by'):
        return False, 'این کد مخصوص کاربران دعوت‌شده است.'
    has_purchase = _user_has_approved_purchase(db, uid)
    active_vip = _user_is_active_vip(db, uid)
    vip_row = db.get("vip_users", {}).get(uid, {})
    ever_vip = bool(vip_row) or has_purchase
    if item.get("first_purchase_only") and has_purchase:
        return False, "این کد فقط برای اولین خرید قابل استفاده است."
    if item.get("renewal_only") and not ever_vip:
        return False, "این کد فقط برای تمدید اشتراک قابل استفاده است."

    customer_types = set(item.get("customer_types", []))
    if customer_types:
        eligible = False
        eligible |= "new_customer" in customer_types and not has_purchase
        eligible |= "existing_customer" in customer_types and has_purchase
        eligible |= "active_vip" in customer_types and active_vip
        eligible |= "expired_vip" in customer_types and ever_vip and not active_vip
        eligible |= "never_vip" in customer_types and not ever_vip
        if not eligible:
            return False, "این کد برای نوع حساب شما فعال نیست."

    segments = set(item.get("allowed_crm_segments", []))
    if segments and not (_crm_segments_for_user(db, uid) & segments):
        return False, "این کد فقط برای کاربران واجد شرایط کمپین فعال است."

    weekdays = set(item.get("allowed_weekdays", []))
    now = utc_now()
    if weekdays and now.weekday() not in weekdays:
        return False, "این کد امروز قابل استفاده نیست."
    start_hour = item.get("daily_start_hour")
    end_hour = item.get("daily_end_hour")
    if start_hour is not None and end_hour is not None:
        current_hour = now.hour
        if start_hour <= end_hour:
            allowed = start_hour <= current_hour < end_hour
        else:
            allowed = current_hour >= start_hour or current_hour < end_hour
        if not allowed:
            return False, "این کد در ساعت فعلی فعال نیست."

    if target_plan and not item.get("allow_on_sale_plans", True):
        from modules.sales_growth import get_vip_plan

        plan = get_vip_plan(db, target_plan)
        if plan and _int(plan.get("original_price")) > _int(plan.get("price")) > 0:
            return False, "این کد روی پلن دارای تخفیف داخلی قابل استفاده نیست."
    return True, "OK"


def calculate_discount_amount(item: dict[str, Any], base_amount: int | str) -> dict[str, int]:
    item = normalize_campaign_fields(item)
    base = max(0, _int(base_amount))
    percent = max(0, min(100, _int(item.get("percent"))))
    discount = min(base, max(0, _int(item.get("fixed_amount")))) if item.get("discount_type") == "fixed" else (base * percent + 50) // 100
    cap = _int(item.get("maximum_discount_amount"))
    if cap:
        discount = min(discount, cap)
    minimum_final = _int(item.get("minimum_final_price"))
    if minimum_final:
        discount = min(discount, max(0, base - minimum_final))
    final = max(0, base - discount)
    effective_percent = round(discount / base * 100) if base else 0
    return {
        "base_amount": base,
        "discount_amount": discount,
        "final_amount": final,
        "configured_percent": percent,
        "effective_percent": effective_percent,
    }


def update_discount_campaign(
    db: dict[str, Any],
    code: str,
    changes: dict[str, Any],
    *,
    admin_id: int | str = "",
) -> dict[str, Any]:
    key = str(code or "").strip().upper()
    item = db.setdefault("discount_codes", {}).get(key)
    if not isinstance(item, dict):
        raise ValueError("کد تخفیف پیدا نشد")
    allowed = {
        "percent",
        "starts_at",
        "expires_at",
        "max_uses",
        "one_per_user",
        "max_uses_per_user",
        "applicable_product_types",
        "applicable_plan_ids",
        "excluded_plan_ids",
        "allowed_crm_segments",
        "allowed_payment_methods",
        "customer_types",
        "minimum_order_amount",
        "maximum_order_amount",
        "maximum_discount_amount",
        "minimum_final_price",
        "first_purchase_only",
        "renewal_only",
        "allow_on_sale_plans",
        "allowed_weekdays",
        "daily_start_hour",
        "daily_end_hour",
        "affiliate_user_id",
        "affiliate_commission_percent",
        "campaign_id",
        "release_on_reject",
        "release_on_cancel",
        "restore_on_full_refund",
        "restore_on_partial_refund",
        "fraud_protection_enabled",
    }
    before = {field: item.get(field) for field in allowed}
    for field, value in changes.items():
        if field not in allowed:
            continue
        if field == "percent":
            pct = _int(value)
            if not 1 <= pct <= 100:
                raise ValueError("درصد باید بین ۱ تا ۱۰۰ باشد")
            item[field] = pct
        elif field in {"starts_at", "expires_at"}:
            if value in {None, "", "-"}:
                item[field] = None
            else:
                parsed = parse_dt(value)
                if not parsed:
                    raise ValueError(f"زمان {field} نامعتبر است")
                item[field] = utc_iso(parsed)
        elif field in {"one_per_user", "first_purchase_only", "renewal_only", "allow_on_sale_plans", "release_on_reject", "release_on_cancel", "restore_on_full_refund", "restore_on_partial_refund", "fraud_protection_enabled"}:
            item[field] = _bool(value)
        elif field in {"applicable_plan_ids", "excluded_plan_ids"}:
            item[field] = _int_list(value)
        elif field == "allowed_weekdays":
            weekdays: list[int] = []
            for raw_day in _string_list(value):
                try:
                    day = int(raw_day)
                except (TypeError, ValueError):
                    continue
                if 0 <= day <= 6 and day not in weekdays:
                    weekdays.append(day)
            item[field] = weekdays
        elif field in {"applicable_product_types", "allowed_crm_segments", "allowed_payment_methods", "customer_types"}:
            item[field] = _string_list(value)
        elif field in {"affiliate_user_id", "campaign_id"}:
            item[field] = str(value or "").strip()[:80]
        else:
            item[field] = max(0, _int(value))
    normalize_campaign_fields(item)
    starts = parse_dt(item.get("starts_at"))
    expires = parse_dt(item.get("expires_at"))
    if starts and expires and expires <= starts:
        item.update(before)
        raise ValueError("زمان پایان باید بعد از شروع باشد")
    item["updated_at"] = utc_iso()
    item["updated_by"] = str(admin_id or "")
    record_discount_event(
        db,
        "campaign_updated",
        code=key,
        detail="campaign rules updated",
        metadata={"changed_fields": sorted(field for field in allowed if before.get(field) != item.get(field)), "admin_id": str(admin_id)},
    )
    return item


def parse_campaign_update_text(text: str) -> dict[str, Any]:
    aliases = {
        "plans": "applicable_plan_ids",
        "exclude_plans": "excluded_plan_ids",
        "segments": "allowed_crm_segments",
        "payments": "allowed_payment_methods",
        "customers": "customer_types",
        "min": "minimum_order_amount",
        "max": "maximum_order_amount",
        "cap": "maximum_discount_amount",
        "min_final": "minimum_final_price",
        "first": "first_purchase_only",
        "renewal": "renewal_only",
        "sale_plans": "allow_on_sale_plans",
        "weekdays": "allowed_weekdays",
        "hour_start": "daily_start_hour",
        "hour_end": "daily_end_hour",
        "affiliate": "affiliate_user_id",
        "commission": "affiliate_commission_percent",
        "reject": "release_on_reject",
        "cancel": "release_on_cancel",
        "refund": "restore_on_full_refund",
        "partial_refund": "restore_on_partial_refund",
        "fraud": "fraud_protection_enabled",
        "uses": "max_uses",
        "per_user": "max_uses_per_user",
        "one_per_user": "one_per_user",
        "start": "starts_at",
        "end": "expires_at",
        "percent": "percent",
        "campaign": "campaign_id",
    }
    result: dict[str, Any] = {}
    normalized = str(text or "").replace("\n", "|").replace("؛", "|")
    for part in normalized.split("|"):
        if "=" not in part:
            continue
        key, value = part.split("=", 1)
        key = aliases.get(key.strip().lower(), key.strip().lower())
        value = value.strip()
        if value.lower() in {"all", "همه", "none", "-"} and key in {
            "applicable_plan_ids", "excluded_plan_ids", "allowed_crm_segments", "allowed_payment_methods", "customer_types", "allowed_weekdays"
        }:
            value = []
        result[key] = value
    if not result:
        raise ValueError("هیچ تنظیم معتبر با قالب کلید=مقدار پیدا نشد")
    return result


def generate_one_time_codes(
    db: dict[str, Any],
    parent_code: str,
    *,
    count: int,
    prefix: str = "",
    created_by: int | str = "",
) -> list[dict[str, Any]]:
    parent_key = str(parent_code or "").strip().upper()
    parent = db.setdefault("discount_codes", {}).get(parent_key)
    if not isinstance(parent, dict):
        raise ValueError("کمپین مادر پیدا نشد")
    normalize_campaign_fields(parent)
    total = max(1, min(500, _int(count, 1)))
    clean_prefix = "".join(ch for ch in str(prefix or parent_key[:8]).upper() if ch.isalnum() or ch in {"-", "_"})[:12]
    created: list[dict[str, Any]] = []
    inherited_fields = {
        key: parent.get(key)
        for key in (
            "percent", "starts_at", "expires_at", "applicable_product_types", "applicable_plan_ids", "excluded_plan_ids",
            "allowed_crm_segments", "allowed_payment_methods", "customer_types", "minimum_order_amount", "maximum_order_amount",
            "maximum_discount_amount", "minimum_final_price", "first_purchase_only", "renewal_only", "allow_on_sale_plans",
            "allowed_weekdays", "daily_start_hour", "daily_end_hour", "affiliate_user_id", "affiliate_commission_percent",
            "campaign_id", "release_on_reject", "release_on_cancel", "restore_on_full_refund", "restore_on_partial_refund",
            "fraud_protection_enabled",
            "discount_type", "fixed_amount", "eligible_group", "allowed_user_ids", "stackable",
        )
    }
    codes = db.setdefault("discount_codes", {})
    for _ in range(total):
        for attempt in range(10):
            code = f"{clean_prefix[:3]}-{secrets.token_hex(10).upper()}"
            if code not in codes:
                break
        else:
            raise ValueError('ساخت کد یکتا ممکن نشد؛ دوباره تلاش کنید.')
        row = {
            "code": code,
            "status": "active",
            "scope": "public",
            "assigned_to": "",
            "max_uses": 1,
            "used_count": 0,
            "used_by": [],
            "one_per_user": True,
            "max_uses_per_user": 1,
            "reservations": {},
            "reserved_order_id": None,
            "created_at": utc_iso(),
            "created_by": str(created_by),
            "source": "batch_one_time",
            "pool": False,
            "parent_campaign_code": parent_key,
            "admin_distribution_only": True,
            **inherited_fields,
        }
        normalize_campaign_fields(row)
        codes[code] = row
        created.append(row)
    record_discount_event(
        db,
        "batch_generated",
        code=parent_key,
        detail=f"{len(created)} one-time codes",
        metadata={"codes": [row["code"] for row in created], "created_by": str(created_by)},
    )
    return created


def register_discount_distribution(
    db: dict[str, Any],
    code: str,
    recipients: list[int | str],
    *,
    segment: str = "",
    campaign_job_id: str = "",
) -> None:
    key = str(code or "").upper()
    item = db.get("discount_codes", {}).get(key)
    if isinstance(item, dict) and segment:
        segments = _string_list(item.get("allowed_crm_segments"))
        if segment not in segments:
            segments.append(segment)
        item["allowed_crm_segments"] = segments
        item["updated_at"] = utc_iso()
    for uid in recipients:
        record_discount_crm_activity(
            db,
            uid,
            "discount_sent",
            code=key,
            detail=f"segment={segment or 'all'}",
            metadata={"segment": segment, "broadcast_job_id": campaign_job_id},
        )
    record_discount_event(
        db,
        "distribution_queued",
        code=key,
        detail=f"segment={segment or 'all'}",
        metadata={"recipient_count": len(recipients), "segment": segment, "broadcast_job_id": campaign_job_id},
    )


def register_affiliate_commission(db: dict[str, Any], item: dict[str, Any], order: dict[str, Any]) -> dict[str, Any] | None:
    normalize_campaign_fields(item)
    affiliate_id = str(item.get("affiliate_user_id") or "")
    percent = _int(item.get("affiliate_commission_percent"))
    if not affiliate_id.isdigit() or percent <= 0:
        return None
    base = max(0, _int(order.get("price")))
    amount = round(base * percent / 100)
    if amount <= 0:
        return None
    order_id = str(order.get("order_id") or "")
    rows = db.setdefault("affiliate_commissions", [])
    existing = next((row for row in rows if isinstance(row, dict) and str(row.get("order_id")) == order_id), None)
    if existing:
        return existing
    row = {
        "id": len(rows) + 1,
        "affiliate_user_id": affiliate_id,
        "customer_user_id": str(order.get("user_id") or ""),
        "order_id": order_id,
        "discount_code": str(item.get("code") or ""),
        "campaign_id": str(item.get("campaign_id") or ""),
        "commission_percent": percent,
        "commission_amount": amount,
        "status": "earned",
        "created_at": utc_iso(),
    }
    rows.append(row)
    if len(rows) > MAX_AFFILIATE_ROWS:
        db["affiliate_commissions"] = rows[-MAX_AFFILIATE_ROWS:]
    balances = db.setdefault("affiliate_balances", {})
    balances[affiliate_id] = max(0, _int(balances.get(affiliate_id))) + amount
    record_discount_event(
        db,
        "affiliate_commission_earned",
        code=item.get("code", ""),
        user_id=affiliate_id,
        order_id=order_id,
        amount=amount,
        metadata={"customer_user_id": str(order.get("user_id") or "")},
    )
    return row


def reverse_affiliate_commission(db: dict[str, Any], order_id: str, *, reason: str) -> int:
    reversed_amount = 0
    balances = db.setdefault("affiliate_balances", {})
    for row in db.setdefault("affiliate_commissions", []):
        if not isinstance(row, dict) or str(row.get("order_id")) != str(order_id) or row.get("status") != "earned":
            continue
        affiliate_id = str(row.get("affiliate_user_id") or "")
        amount = max(0, _int(row.get("commission_amount")))
        balances[affiliate_id] = max(0, _int(balances.get(affiliate_id)) - amount)
        row.update({"status": "reversed", "reversed_at": utc_iso(), "reverse_reason": str(reason)[:300]})
        reversed_amount += amount
    return reversed_amount


def campaign_report(db: dict[str, Any], code: str) -> dict[str, Any]:
    key = str(code or "").strip().upper()
    item = db.get("discount_codes", {}).get(key)
    if not isinstance(item, dict):
        raise ValueError("کد تخفیف پیدا نشد")
    normalize_campaign_fields(item)
    related_codes = {key}
    related_codes.update(
        str(row.get("code") or "")
        for row in db.get("discount_codes", {}).values()
        if isinstance(row, dict) and str(row.get("parent_campaign_code") or "").upper() == key
    )
    events = [row for row in db.get("discount_events", []) if isinstance(row, dict) and str(row.get("code") or "").upper() in related_codes]
    counts = Counter(str(row.get("type") or "") for row in events)
    approved_orders = [
        order for order in db.get("vip_orders", [])
        if isinstance(order, dict)
        and str(order.get("coupon") or "").upper() in related_codes
        and str(order.get("status")) == "approved"
    ]
    pending_orders = [
        order for order in db.get("vip_orders", [])
        if isinstance(order, dict)
        and str(order.get("coupon") or "").upper() in related_codes
        and str(order.get("status")) in {"pending", "approving"}
    ]
    rejected_orders = [
        order for order in db.get("vip_orders", [])
        if isinstance(order, dict)
        and str(order.get("coupon") or "").upper() in related_codes
        and str(order.get("status")) == "rejected"
    ]
    revenue = sum(max(0, _int(row.get("price"))) for row in approved_orders)
    discount_total = sum(max(0, _int(row.get("discount_amount"))) for row in approved_orders)
    distributed = sum(_int((row.get("metadata") or {}).get("recipient_count")) for row in events if row.get("type") == "distribution_queued")
    attempts = counts.get("validation_success", 0) + counts.get("validation_failed", 0)
    conversions = len(approved_orders) / max(1, distributed) * 100 if distributed else 0.0
    return {
        "code": key,
        "related_code_count": len(related_codes),
        "distributed": distributed,
        "attempts": attempts,
        "valid_attempts": counts.get("validation_success", 0),
        "invalid_attempts": counts.get("validation_failed", 0),
        "reservations": counts.get("reserved", 0),
        "approved_orders": len(approved_orders),
        "pending_orders": len(pending_orders),
        "rejected_orders": len(rejected_orders),
        "refunds": counts.get("refunded", 0),
        "revenue": revenue,
        "discount_total": discount_total,
        "conversion_rate": round(conversions, 2),
        "affiliate_commission": sum(
            _int(row.get("commission_amount"))
            for row in db.get("affiliate_commissions", [])
            if isinstance(row, dict) and str(row.get("discount_code") or "").upper() in related_codes and row.get("status") == "earned"
        ),
    }


def settle_discount_for_order(
    db: dict[str, Any],
    order: dict[str, Any],
    outcome: str,
    *,
    refund_type: str = "full",
    reason: str = "",
) -> dict[str, Any] | None:
    code = str(order.get("coupon") or "").upper()
    item = db.get("discount_codes", {}).get(code)
    if not isinstance(item, dict):
        return None
    normalize_campaign_fields(item)
    outcome = str(outcome or "").lower()
    if outcome == 'refunded':
        if refund_type not in {'full', 'partial'}:
            raise ValueError('نوع بازپرداخت نامعتبر است.')
        order_key = str(order.get('order_id') or order.get('id') or '')
        if not order_key:
            raise ValueError('شناسه سفارش لازم است.')
        from core.economy_integrity import economic_event
        if not economic_event(db, f'coupon_refund:{order_key}:{refund_type}', order['user_id'], kind='coupon_refund', value=1,
                              actor=reason or 'payment_service', metadata={'code':code,'refund_type':refund_type}):
            return item
    should_restore = False
    if outcome == "rejected":
        should_restore = bool(item.get("release_on_reject", True))
    elif outcome in {"cancelled", "expired"}:
        should_restore = bool(item.get("release_on_cancel", True))
    elif outcome == "refunded":
        should_restore = bool(item.get("restore_on_full_refund")) if refund_type == "full" else bool(item.get("restore_on_partial_refund"))

    order_id = str(order.get("order_id") or "")
    uid = str(order.get("user_id") or "")
    restored_orders=item.setdefault('restored_refund_order_ids',[]) if outcome=='refunded' else []
    if outcome=='refunded' and order_id in restored_orders:should_restore=False
    if outcome=='refunded' and f'coupon_refund:{order_id}' in db.get('economic_events',{}):should_restore=False
    if should_restore:
        if outcome=='refunded':restored_orders.append(order_id)
        if str(item.get("scope") or "") == "public":
            reservations = item.get("reservations", {})
            if isinstance(reservations, dict):
                reservations.pop(order_id, None)
            if outcome == "refunded":
                used_by = [str(value) for value in item.get("used_by", [])]
                if uid in used_by:
                    used_by.remove(uid)
                    item["used_by"] = used_by
                item["used_count"] = max(0, _int(item.get("used_count")) - 1)
                consumed_orders = [str(value) for value in item.get("consumed_order_ids", [])]
                if order_id in consumed_orders:
                    consumed_orders.remove(order_id)
                    item["consumed_order_ids"] = consumed_orders
                if item.get("status") == "disabled" and (_int(item.get("max_uses")) == 0 or _int(item.get("used_count")) < _int(item.get("max_uses"))):
                    item["status"] = "active"
        else:
            item.update({"status": "active", "reserved_order_id": None, "used_at": None, "used_by": ""})
    if outcome == "refunded":
        reverse_affiliate_commission(db, order_id, reason=reason or refund_type)
    record_discount_event(
        db,
        "refunded" if outcome == "refunded" else "released",
        code=code,
        user_id=uid,
        order_id=order_id,
        discount_amount=_int(order.get("discount_amount")),
        detail=f"outcome={outcome}; restored={should_restore}; reason={reason}"[:500],
        metadata={"refund_type": refund_type, "restored": should_restore},
    )
    record_discount_crm_activity(
        db,
        uid,
        "discount_refunded" if outcome == "refunded" else "discount_released",
        code=code,
        detail=f"{outcome}; restored={should_restore}",
        metadata={"order_id": order_id, "refund_type": refund_type},
    )
    return item


def claim_discount_reminder_events(db: dict[str, Any], *, delay_hours: int = 24, limit: int = 200) -> list[dict[str, Any]]:
    """Claim reminders for distributed codes that a user has not used yet."""
    now = utc_now()
    cutoff = now - timedelta(hours=max(1, int(delay_hours)))
    logs = db.setdefault("discount_automation_log", {})
    activities = [row for row in db.get("crm_activities", []) if isinstance(row, dict)]
    output: list[dict[str, Any]] = []
    # Newest first so recent active campaigns win when a user received many codes.
    sent_rows = sorted(
        (row for row in activities if str(row.get("type")) == "discount_sent"),
        key=lambda row: str(row.get("created_at") or ""),
        reverse=True,
    )
    seen: set[tuple[str, str]] = set()
    for row in sent_rows:
        if len(output) >= max(1, int(limit)):
            break
        uid = str(row.get("user_id") or "")
        metadata = row.get("metadata") if isinstance(row.get("metadata"), dict) else {}
        code = str(metadata.get("discount_code") or "").upper()
        if not uid.isdigit() or not code or (uid, code) in seen:
            continue
        seen.add((uid, code))
        sent_at = parse_dt(row.get("created_at"))
        if sent_at is None or sent_at > cutoff:
            continue
        item = db.get("discount_codes", {}).get(code)
        if not isinstance(item, dict):
            continue
        normalize_campaign_fields(item)
        expiry = parse_dt(item.get("expires_at"))
        if item.get("status") != "active" or (expiry and expiry <= now):
            continue
        # Already used or reserved by this user means no reminder is needed.
        if uid in {str(value) for value in item.get("used_by", [])}:
            continue
        reservations = item.get("reservations", {}) if isinstance(item.get("reservations"), dict) else {}
        if uid in {str(value) for value in reservations.values()}:
            continue
        used_after = any(
            str(activity.get("user_id")) == uid
            and str(activity.get("type")) == "discount_used"
            and str((activity.get("metadata") or {}).get("discount_code") or "").upper() == code
            and (parse_dt(activity.get("created_at")) or now) >= sent_at
            for activity in activities
            if isinstance(activity, dict)
        )
        if used_after:
            continue
        key = f"discount_reminder:{uid}:{code}"
        existing = logs.get(key)
        if isinstance(existing, dict) and str(existing.get("status")) in {"pending", "sent"}:
            continue
        logs[key] = {
            "key": key,
            "type": "unused_discount_reminder",
            "user_id": uid,
            "code": code,
            "status": "pending",
            "attempts": _int((existing or {}).get("attempts")) + 1 if isinstance(existing, dict) else 1,
            "claimed_at": utc_iso(),
        }
        output.append({"key": key, "user_id": int(uid), "code": code, "expires_at": item.get("expires_at")})
    return output


def mark_discount_reminder_event(db: dict[str, Any], key: str, *, success: bool, detail: str = "") -> None:
    row = db.setdefault("discount_automation_log", {}).setdefault(str(key), {})
    row.update({"status": "sent" if success else "failed", "updated_at": utc_iso(), "detail": str(detail)[:500]})
    uid = str(row.get("user_id") or "")
    code = str(row.get("code") or "")
    if uid:
        record_discount_crm_activity(
            db,
            uid,
            "automation_sent" if success else "automation_failed",
            code=code,
            detail="یادآوری کد تخفیف استفاده‌نشده" if success else f"خطای یادآوری: {detail}",
        )
