from __future__ import annotations

import hashlib
import math
from datetime import timedelta
from typing import Any

from core.utils import parse_dt, utc_iso, utc_now

EXPERIMENT_STATUSES = {"draft", "running", "paused", "completed", "cancelled"}
EVENT_TYPES = {"impression", "checkout_started", "purchase", "renewal", "refund"}


def ensure_experiment_lab(db: dict[str, Any]) -> None:
    db.setdefault("growth_experiments", {})
    db.setdefault("experiment_assignments", {})
    db.setdefault("experiment_events", [])


def _next_id(db: dict[str, Any], key: str) -> int:
    next_ids = db.setdefault("next_ids", {})
    value = int(next_ids.get(key, 1) or 1)
    next_ids[key] = value + 1
    return value


def _variant_rows(values: Any) -> list[dict[str, Any]]:
    if not isinstance(values, list) or len(values) < 2:
        raise ValueError("EXPERIMENT_VARIANTS_REQUIRED")
    rows: list[dict[str, Any]] = []
    keys: set[str] = set()
    controls = 0
    for index, item in enumerate(values[:8]):
        if not isinstance(item, dict):
            raise ValueError("EXPERIMENT_VARIANT_INVALID")
        key = str(item.get("key") or f"variant_{index + 1}").strip().lower().replace(" ", "_")
        if not key or key in keys:
            raise ValueError("EXPERIMENT_VARIANT_DUPLICATE")
        keys.add(key)
        try:
            weight = max(0.01, min(float(item.get("weight", 1) or 1), 100.0))
        except (TypeError, ValueError) as exc:
            raise ValueError("EXPERIMENT_VARIANT_WEIGHT_INVALID") from exc
        is_control = bool(item.get("is_control", index == 0))
        controls += int(is_control)
        rows.append(
            {
                "key": key,
                "label": str(item.get("label") or key)[:120],
                "weight": weight,
                "is_control": is_control,
                "payload": item.get("payload") if isinstance(item.get("payload"), dict) else {},
            }
        )
    if controls != 1:
        raise ValueError("EXPERIMENT_CONTROL_REQUIRED")
    return rows


def create_experiment(
    db: dict[str, Any],
    *,
    name: str,
    hypothesis: str,
    variants: Any,
    primary_metric: str,
    created_by: int | str,
    holdout_percent: float = 10.0,
    conversion_window_hours: int = 168,
    min_sample_per_variant: int = 100,
    stop_loss_percent: float = 25.0,
    starts_at: str | None = None,
    ends_at: str | None = None,
) -> dict[str, Any]:
    ensure_experiment_lab(db)
    title = str(name or "").strip()
    theory = str(hypothesis or "").strip()
    metric = str(primary_metric or "purchase").strip().lower()
    if len(title) < 3 or len(theory) < 5:
        raise ValueError("EXPERIMENT_NAME_HYPOTHESIS_REQUIRED")
    if metric not in EVENT_TYPES - {"impression", "refund"}:
        raise ValueError("EXPERIMENT_METRIC_INVALID")
    rows = _variant_rows(variants)
    try:
        holdout = max(0.0, min(float(holdout_percent), 50.0))
        window = max(1, min(int(conversion_window_hours), 24 * 90))
        minimum = max(10, min(int(min_sample_per_variant), 1_000_000))
        stop_loss = max(0.0, min(float(stop_loss_percent), 100.0))
    except (TypeError, ValueError) as exc:
        raise ValueError("EXPERIMENT_CONFIGURATION_INVALID") from exc
    start = parse_dt(starts_at) if starts_at else utc_now()
    end = parse_dt(ends_at) if ends_at else None
    if end and end <= start:
        raise ValueError("EXPERIMENT_DATE_RANGE_INVALID")
    experiment_id = _next_id(db, "growth_experiment")
    row = {
        "id": experiment_id,
        "name": title[:200],
        "hypothesis": theory[:1000],
        "variants": rows,
        "primary_metric": metric,
        "holdout_percent": round(holdout, 3),
        "conversion_window_hours": window,
        "min_sample_per_variant": minimum,
        "stop_loss_percent": round(stop_loss, 3),
        "status": "draft",
        "starts_at": utc_iso(start),
        "ends_at": utc_iso(end) if end else None,
        "created_by": str(created_by),
        "created_at": utc_iso(),
        "updated_at": utc_iso(),
    }
    db["growth_experiments"][str(experiment_id)] = row
    return dict(row)


def _experiment(db: dict[str, Any], experiment_id: int | str) -> dict[str, Any]:
    ensure_experiment_lab(db)
    row = db["growth_experiments"].get(str(experiment_id))
    if not isinstance(row, dict):
        raise ValueError("EXPERIMENT_NOT_FOUND")
    return row


def set_experiment_status(
    db: dict[str, Any],
    experiment_id: int | str,
    *,
    status: str,
    changed_by: int | str,
) -> dict[str, Any]:
    row = _experiment(db, experiment_id)
    next_status = str(status or "").strip().lower()
    if next_status not in EXPERIMENT_STATUSES:
        raise ValueError("EXPERIMENT_STATUS_INVALID")
    current = str(row.get("status") or "draft")
    allowed = {
        "draft": {"running", "cancelled"},
        "running": {"paused", "completed", "cancelled"},
        "paused": {"running", "completed", "cancelled"},
        "completed": set(),
        "cancelled": set(),
    }
    if next_status != current and next_status not in allowed.get(current, set()):
        raise ValueError("EXPERIMENT_TRANSITION_INVALID")
    row["status"] = next_status
    row["updated_at"] = utc_iso()
    row["changed_by"] = str(changed_by)
    return dict(row)


def _hash_unit(*parts: Any) -> float:
    digest = hashlib.sha256("|".join(str(value) for value in parts).encode()).digest()
    return int.from_bytes(digest[:8], "big") / float(2**64 - 1)


def assign_variant(db: dict[str, Any], experiment_id: int | str, user_id: int | str) -> dict[str, Any]:
    experiment = _experiment(db, experiment_id)
    if experiment.get("status") != "running":
        raise ValueError("EXPERIMENT_NOT_RUNNING")
    now = utc_now()
    start = parse_dt(experiment.get("starts_at"))
    end = parse_dt(experiment.get("ends_at"))
    if start and now < start:
        raise ValueError("EXPERIMENT_NOT_STARTED")
    if end and now > end:
        raise ValueError("EXPERIMENT_ENDED")
    uid = str(user_id)
    assignments = db.setdefault("experiment_assignments", {}).setdefault(str(experiment_id), {})
    existing = assignments.get(uid)
    if isinstance(existing, dict):
        return dict(existing)
    bucket = _hash_unit(experiment_id, uid, "assignment") * 100.0
    holdout = float(experiment.get("holdout_percent", 0) or 0)
    if bucket < holdout:
        variant_key = "holdout"
    else:
        variants = experiment.get("variants", [])
        total = sum(float(row.get("weight", 1) or 1) for row in variants if isinstance(row, dict))
        cursor = _hash_unit(experiment_id, uid, "variant") * max(total, 1.0)
        running = 0.0
        variant_key = str(variants[-1].get("key"))
        for row in variants:
            running += float(row.get("weight", 1) or 1)
            if cursor <= running:
                variant_key = str(row.get("key"))
                break
    assignment = {
        "experiment_id": int(experiment_id),
        "user_id": uid,
        "variant": variant_key,
        "assigned_at": utc_iso(now),
        "expires_at": utc_iso(now + timedelta(hours=int(experiment.get("conversion_window_hours", 168) or 168))),
    }
    assignments[uid] = assignment
    return dict(assignment)


def record_experiment_event(
    db: dict[str, Any],
    experiment_id: int | str,
    user_id: int | str,
    *,
    event: str,
    revenue: float = 0.0,
    event_id: str = "",
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    ensure_experiment_lab(db)
    kind = str(event or "").strip().lower()
    if kind not in EVENT_TYPES:
        raise ValueError("EXPERIMENT_EVENT_INVALID")
    assignment = assign_variant(db, experiment_id, user_id)
    unique = str(event_id or "").strip()
    if unique:
        duplicate = next(
            (
                row
                for row in db["experiment_events"]
                if isinstance(row, dict)
                and str(row.get("experiment_id")) == str(experiment_id)
                and str(row.get("event_id")) == unique
            ),
            None,
        )
        if duplicate:
            return dict(duplicate)
    try:
        amount = float(revenue or 0)
    except (TypeError, ValueError) as exc:
        raise ValueError("EXPERIMENT_REVENUE_INVALID") from exc
    row = {
        "id": _next_id(db, "experiment_event"),
        "event_id": unique,
        "experiment_id": int(experiment_id),
        "user_id": str(user_id),
        "variant": assignment["variant"],
        "event": kind,
        "revenue": round(amount, 2),
        "metadata": metadata if isinstance(metadata, dict) else {},
        "created_at": utc_iso(),
    }
    db["experiment_events"].append(row)
    return dict(row)


def _wilson(successes: int, total: int, z: float = 1.96) -> tuple[float, float]:
    if total <= 0:
        return 0.0, 0.0
    p = successes / total
    denominator = 1 + z * z / total
    center = (p + z * z / (2 * total)) / denominator
    margin = z * math.sqrt((p * (1 - p) + z * z / (4 * total)) / total) / denominator
    return max(0.0, center - margin), min(1.0, center + margin)


def experiment_report(db: dict[str, Any], experiment_id: int | str) -> dict[str, Any]:
    experiment = _experiment(db, experiment_id)
    assignments = db.get("experiment_assignments", {}).get(str(experiment_id), {})
    events = [
        row
        for row in db.get("experiment_events", [])
        if isinstance(row, dict) and str(row.get("experiment_id")) == str(experiment_id)
    ]
    variants = ["holdout"] + [str(row.get("key")) for row in experiment.get("variants", [])]
    metric = str(experiment.get("primary_metric") or "purchase")
    rows: list[dict[str, Any]] = []
    control_key = next(
        (str(row.get("key")) for row in experiment.get("variants", []) if row.get("is_control")),
        "holdout",
    )
    for key in variants:
        assigned_users = {
            uid for uid, row in assignments.items() if isinstance(row, dict) and str(row.get("variant")) == key
        }
        converted_users = {
            str(row.get("user_id"))
            for row in events
            if str(row.get("variant")) == key and str(row.get("event")) == metric
        }
        purchases = [row for row in events if str(row.get("variant")) == key and str(row.get("event")) == "purchase"]
        sample = len(assigned_users)
        conversions = len(converted_users)
        rate = conversions / max(1, sample)
        low, high = _wilson(conversions, sample)
        rows.append(
            {
                "variant": key,
                "sample_size": sample,
                "conversions": conversions,
                "conversion_rate": round(rate * 100, 4),
                "confidence_interval_95": [round(low * 100, 4), round(high * 100, 4)],
                "revenue": round(sum(float(row.get("revenue", 0) or 0) for row in purchases), 2),
                "purchase_count": len(purchases),
            }
        )
    control = next((row for row in rows if row["variant"] == control_key), rows[0])
    control_rate = float(control["conversion_rate"])
    for row in rows:
        delta = float(row["conversion_rate"]) - control_rate
        row["uplift_points_vs_control"] = round(delta, 4)
        row["incremental_conversions_vs_control"] = round(
            delta / 100.0 * int(row["sample_size"]), 3
        )
    min_sample = int(experiment.get("min_sample_per_variant", 100) or 100)
    eligible = all(row["sample_size"] >= min_sample for row in rows if row["variant"] != "holdout")
    stop_loss = float(experiment.get("stop_loss_percent", 25) or 25)
    stop_candidates = [
        row["variant"]
        for row in rows
        if row["variant"] not in {"holdout", control_key}
        and row["sample_size"] >= min_sample
        and control_rate > 0
        and float(row["conversion_rate"]) < control_rate * (1 - stop_loss / 100.0)
    ]
    best = max(rows, key=lambda row: (float(row["conversion_rate"]), float(row["revenue"]))) if rows else None
    return {
        "experiment": dict(experiment),
        "variants": rows,
        "control_variant": control_key,
        "minimum_sample_reached": eligible,
        "stop_loss_candidates": stop_candidates,
        "best_observed_variant": best["variant"] if best else None,
        "decision_note": (
            "minimum sample not reached; do not declare a winner"
            if not eligible
            else "observational result only; validate confidence intervals and guardrails before rollout"
        ),
        "generated_at": utc_iso(),
    }


def experiment_lab_snapshot(db: dict[str, Any]) -> dict[str, Any]:
    ensure_experiment_lab(db)
    rows = []
    for experiment_id, experiment in db["growth_experiments"].items():
        report = experiment_report(db, experiment_id)
        rows.append(
            {
                "id": int(experiment_id),
                "name": experiment.get("name"),
                "status": experiment.get("status"),
                "primary_metric": experiment.get("primary_metric"),
                "minimum_sample_reached": report["minimum_sample_reached"],
                "best_observed_variant": report["best_observed_variant"],
                "stop_loss_candidates": report["stop_loss_candidates"],
            }
        )
    rows.sort(key=lambda row: row["id"], reverse=True)
    return {"experiments": rows, "count": len(rows), "generated_at": utc_iso()}
