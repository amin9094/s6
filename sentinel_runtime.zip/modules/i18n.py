from __future__ import annotations

from typing import Any

SUPPORTED_LANGUAGES = {"fa", "en"}
DEFAULT_LANGUAGE = "fa"


def normalize_language(value: Any) -> str:
    language = str(value or "").strip().lower().replace("_", "-")
    if language.startswith("en"):
        return "en"
    if language.startswith("fa") or language.startswith("per"):
        return "fa"
    return DEFAULT_LANGUAGE


def user_language(db: dict[str, Any], user_id: int | str) -> str | None:
    from modules.shared_preferences import migrate_shared_preference
    migrate_shared_preference(db, user_id, "user_profiles")
    uid = str(int(user_id))
    user = db.get("users", {}).get(uid, {})
    profile = db.get("user_profiles", {}).get(uid, {})
    if not isinstance(user, dict):
        user = {}
    if not isinstance(profile, dict):
        profile = {}
    raw = user.get("language") or profile.get("language")
    if not raw:
        return None
    return normalize_language(raw)


def set_user_language(
    db: dict[str, Any],
    user_id: int | str,
    language: str,
    *,
    selected_at: str | None = None,
) -> str:
    language = normalize_language(language)
    from modules.shared_preferences import migrate_shared_preference
    migrate_shared_preference(db, user_id, "user_profiles")
    uid = str(int(user_id))
    user = db.setdefault("users", {}).setdefault(uid, {"id": int(user_id)})
    profile = db.setdefault("user_profiles", {}).setdefault(uid, {"user_id": uid})
    user["language"] = language
    profile["language"] = language
    if selected_at:
        user["language_selected_at"] = selected_at
        profile["language_selected_at"] = selected_at
    from core.utils import utc_iso
    profile["updated_at"] = selected_at or utc_iso()
    return language


def is_english(db: dict[str, Any], user_id: int | str) -> bool:
    return user_language(db, user_id) == "en"


TEXTS: dict[str, dict[str, str]] = {
    "choose_language": {
        "fa": "🌐 <b>زبان ربات را انتخاب کنید</b>\n\nهر زمان بخواهید می‌توانید زبان را از بخش حساب تغییر دهید.",
        "en": "🌐 <b>Choose your language</b>\n\nYou can change it later from your account settings.",
    },
    "language_saved": {
        "fa": "✅ زبان فارسی انتخاب شد.",
        "en": "✅ English has been selected.",
    },
    "rules_missing": {
        "fa": "هنوز متن قوانین فارسی منتشر نشده است.",
        "en": "The English rules have not been published yet.",
    },
    "rules_accept": {
        "fa": "✅ قوانین را خواندم و می‌پذیرم",
        "en": "✅ I have read and accept the rules",
    },
    "rules_accepted": {
        "fa": "✅ <b>قوانین پذیرفته شد</b>\n\nاکنون تمام بخش‌های فعال ربات در دسترس شماست.",
        "en": "✅ <b>Rules accepted</b>\n\nAll enabled bot features are now available.",
    },
    "rules_required": {
        "fa": "ابتدا قوانین را مطالعه و تأیید کنید.",
        "en": "Please read and accept the rules first.",
    },
    "home": {"fa": "🏠 منوی اصلی", "en": "🏠 Main menu"},
    "choose_option": {"fa": "یک گزینه را انتخاب کنید:", "en": "Choose an option:"},
    "disabled": {
        "fa": "⛔️ این بخش در حال حاضر توسط مدیریت غیرفعال است.",
        "en": "⛔️ This section is currently disabled by management.",
    },
}


def tr(key: str, language: str | None = None, **values: Any) -> str:
    lang = normalize_language(language)
    row = TEXTS.get(key, {})
    text = row.get(lang) or row.get(DEFAULT_LANGUAGE) or key
    return text.format(**values) if values else text

