from __future__ import annotations

from collections import Counter
from datetime import UTC, datetime, timedelta
from typing import Any, Iterable

from core.utils import parse_dt, utc_iso

HEALTHY = {"healthy", "recovering"}
_SYNTHETIC_PREFIXES = ("consensus:", "market-router", "shared-cache", "last-known-good")
_RECENT_WINDOW = 20


def _rows(db: dict[str, Any]) -> dict[str, dict[str, Any]]:
    root = db.setdefault("provider_health", {})
    if not isinstance(root, dict):
        root = {}
        db["provider_health"] = root
    return root


def _normalized_provider(value: str) -> str:
    return str(value or "unknown").strip().lower()[:80]


def _is_synthetic(name: str) -> bool:
    normalized = _normalized_provider(name)
    return any(normalized.startswith(prefix) for prefix in _SYNTHETIC_PREFIXES) or "(last-known-good)" in normalized


def record_provider_result(
    db: dict[str, Any],
    provider: str,
    *,
    success: bool,
    latency_ms: float = 0,
    price: float | None = None,
    symbol: str = "",
    error: str = "",
) -> dict[str, Any]:
    """Persist provider health using recent/consecutive outcomes.

    Older releases classified a provider from its lifetime failure ratio. A
    single historical outage could therefore leave the provider permanently
    degraded even after it recovered. The new model keeps lifetime counters for
    reporting, but status is based on the rolling window and consecutive
    failures so successful probes recover immediately.
    """

    name = _normalized_provider(provider)
    row = _rows(db).setdefault(
        name,
        {
            "provider": name,
            "requests": 0,
            "successes": 0,
            "failures": 0,
            "consecutive_failures": 0,
            "consecutive_successes": 0,
            "latency_ms_ema": 0.0,
            "status": "unknown",
            "active": True,
            "recent_results": [],
        },
    )
    now = utc_iso()
    row["provider"] = name
    row["active"] = not _is_synthetic(name)
    row["requests"] = int(row.get("requests", 0) or 0) + 1
    row["last_checked_at"] = now
    row["last_active_at"] = now
    row["last_symbol"] = str(symbol or "")[:40]

    recent = row.get("recent_results") if isinstance(row.get("recent_results"), list) else []
    recent.append(1 if success else 0)
    row["recent_results"] = recent[-_RECENT_WINDOW:]

    if success:
        row["successes"] = int(row.get("successes", 0) or 0) + 1
        row["consecutive_failures"] = 0
        row["consecutive_successes"] = int(row.get("consecutive_successes", 0) or 0) + 1
        row["last_success_at"] = now
        row["last_price"] = price
        row["last_error"] = ""
    else:
        row["failures"] = int(row.get("failures", 0) or 0) + 1
        row["consecutive_failures"] = int(row.get("consecutive_failures", 0) or 0) + 1
        row["consecutive_successes"] = 0
        row["last_failure_at"] = now
        row["last_error"] = str(error or "provider request failed")[:300]

    previous = float(row.get("latency_ms_ema", 0) or 0)
    current = max(0.0, float(latency_ms or 0))
    row["latency_ms_ema"] = round(current if not previous else previous * 0.8 + current * 0.2, 2)

    recent_values = [int(item) for item in row["recent_results"] if item in {0, 1, False, True}]
    recent_failures = sum(1 for item in recent_values if not item)
    recent_failure_rate = recent_failures / max(1, len(recent_values))
    consecutive_failures = int(row.get("consecutive_failures", 0) or 0)

    if not row["active"]:
        row["status"] = "inactive"
    elif success:
        # A fresh valid response is the strongest signal of current health.
        row["status"] = "healthy"
    elif consecutive_failures >= 5:
        row["status"] = "offline"
    elif consecutive_failures >= 2 or (
        len(recent_values) >= 5 and recent_failure_rate >= 0.5
    ) or row["latency_ms_ema"] > 8000:
        row["status"] = "degraded"
    else:
        row["status"] = "recovering"

    row["success_rate"] = round(int(row["successes"]) / max(1, int(row["requests"])) * 100, 2)
    row["recent_success_rate"] = round((1.0 - recent_failure_rate) * 100, 2)
    from modules.provider_intelligence import update_provider_quarantine
    update_provider_quarantine(row)
    return dict(row)


def sanitize_provider_health(
    db: dict[str, Any],
    *,
    active_providers: Iterable[str] | None = None,
    delete_after_hours: int = 168,
) -> dict[str, int]:
    """Remove synthetic rows and retire obsolete provider records safely."""

    rows = _rows(db)
    active = {_normalized_provider(item) for item in (active_providers or []) if str(item or "").strip()}
    now = datetime.now(UTC)
    removed = retired = active_count = 0
    for name in list(rows):
        row = rows.get(name)
        if not isinstance(row, dict) or _is_synthetic(name):
            rows.pop(name, None)
            removed += 1
            continue
        checked = parse_dt(row.get("last_checked_at") or row.get("last_success_at") or row.get("last_failure_at"))
        if checked and checked.tzinfo is None:
            checked = checked.replace(tzinfo=UTC)
        too_old = bool(checked and now - checked.astimezone(UTC) > timedelta(hours=max(24, int(delete_after_hours))))
        if too_old and active and name not in active:
            rows.pop(name, None)
            removed += 1
            continue
        if active:
            row["active"] = name in active
        else:
            row["active"] = bool(row.get("active", True))
        if row["active"]:
            active_count += 1
        else:
            retired += 1
            row["status"] = "inactive"
    return {"removed": removed, "retired": retired, "active": active_count, "total": len(rows)}


def active_provider_rows(db: dict[str, Any]) -> list[dict[str, Any]]:
    return [
        dict(row)
        for name, row in _rows(db).items()
        if isinstance(row, dict) and bool(row.get("active", True)) and not _is_synthetic(name)
    ]


def provider_health_summary(db: dict[str, Any], *, include_inactive: bool = False) -> dict[str, Any]:
    rows = [
        dict(row)
        for name, row in _rows(db).items()
        if isinstance(row, dict) and not _is_synthetic(name) and (include_inactive or bool(row.get("active", True)))
    ]
    rows.sort(key=lambda item: (str(item.get("status")) not in HEALTHY, -float(item.get("recent_success_rate", item.get("success_rate", 0)) or 0)))
    states = Counter(str(row.get("status") or "unknown") for row in rows)
    return {
        "total": len(rows),
        "healthy": states.get("healthy", 0),
        "recovering": states.get("recovering", 0),
        "degraded": states.get("degraded", 0),
        "offline": states.get("offline", 0),
        "unknown": states.get("unknown", 0),
        "inactive": states.get("inactive", 0),
        "providers": rows,
        "generated_at": utc_iso(),
    }


def select_healthy_provider(db: dict[str, Any], candidates: list[str]) -> str | None:
    rows = _rows(db)
    try:
        from modules.feature_flags import feature_enabled
        intelligent = feature_enabled(db, "providers.intelligence", default=True)
    except Exception:
        intelligent = True
    if intelligent:
        from modules.provider_intelligence import rank_providers
        ranked = rank_providers(rows, candidates)
        return ranked[0]["provider"] if ranked and float(ranked[0]["score"]) > 0 else None
    ranked = []
    for index, candidate in enumerate(candidates):
        row = rows.get(_normalized_provider(candidate), {})
        status = str(row.get("status") or "unknown")
        status_score = {"healthy": 0, "recovering": 1, "unknown": 1, "degraded": 2, "offline": 3, "inactive": 3}.get(status, 2)
        ranked.append((status_score, float(row.get("latency_ms_ema", 0) or 0), index, candidate))
    ranked.sort(key=lambda item: item[:3])
    return ranked[0][3] if ranked and ranked[0][0] < 3 else None
