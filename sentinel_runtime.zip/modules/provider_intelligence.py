from __future__ import annotations

import os
from datetime import UTC, datetime, timedelta
from typing import Any

from core.utils import parse_dt, utc_iso

_STATUS_BASE = {
    "healthy": 100.0,
    "recovering": 75.0,
    "unknown": 60.0,
    "degraded": 35.0,
    "offline": 0.0,
    "inactive": 0.0,
}


def _cost_per_1000(row: dict[str, Any]) -> float:
    raw = row.get("cost_per_1000_requests", row.get("cost_per_1k", 0))
    try:
        return max(0.0, float(raw or 0))
    except (TypeError, ValueError):
        return 0.0


def provider_estimated_cost(row: dict[str, Any]) -> float:
    requests = max(0, int(row.get("requests", 0) or 0))
    return round(requests / 1000.0 * _cost_per_1000(row), 6)


def provider_score(row: dict[str, Any]) -> float:
    status = str(row.get("status") or "unknown")
    score = _STATUS_BASE.get(status, 40.0)
    recent = float(row.get("recent_success_rate", row.get("success_rate", 0)) or 0)
    latency = max(0.0, float(row.get("latency_ms_ema", 0) or 0))
    streak = max(0, int(row.get("consecutive_failures", 0) or 0))
    score += min(20.0, recent * 0.2)
    score -= min(30.0, latency / 300.0)
    score -= min(40.0, streak * 10.0)
    quarantine_until = parse_dt(row.get("quarantine_until"))
    if quarantine_until and quarantine_until > datetime.now(UTC):
        return -1000.0
    try:
        cost_weight = max(0.0, min(20.0, float(os.getenv("PROVIDER_COST_SCORE_WEIGHT", "2") or 2)))
    except ValueError:
        cost_weight = 2.0
    score -= min(20.0, _cost_per_1000(row) * cost_weight)
    return round(score, 3)


def update_provider_quarantine(row: dict[str, Any], *, now: datetime | None = None) -> dict[str, Any]:
    now = (now or datetime.now(UTC)).astimezone(UTC)
    failures = int(row.get("consecutive_failures", 0) or 0)
    if failures >= 5 or str(row.get("status")) == "offline":
        row["quarantine_until"] = (now + timedelta(minutes=5)).isoformat()
        row["quarantine_reason"] = "consecutive_failures"
    elif bool(row.get("quarantine_until")) and failures == 0 and str(row.get("status")) == "healthy":
        row["quarantine_until"] = None
        row["quarantine_reason"] = ""
    row["intelligence_score"] = provider_score(row)
    row["intelligence_updated_at"] = utc_iso()
    row["estimated_cost"] = provider_estimated_cost(row)
    return row


def rank_providers(rows: dict[str, dict[str, Any]], candidates: list[str]) -> list[dict[str, Any]]:
    ranked: list[dict[str, Any]] = []
    for index, candidate in enumerate(candidates):
        row = dict(rows.get(str(candidate).strip().lower()) or {})
        row.setdefault("provider", candidate)
        ranked.append({
            "provider": candidate,
            "score": provider_score(row),
            "status": str(row.get("status") or "unknown"),
            "latency_ms": float(row.get("latency_ms_ema", 0) or 0),
            "success_rate": float(row.get("recent_success_rate", row.get("success_rate", 0)) or 0),
            "cost_per_1000_requests": _cost_per_1000(row),
            "estimated_cost": provider_estimated_cost(row),
            "order": index,
        })
    ranked.sort(key=lambda item: (-float(item["score"]), int(item["order"])))
    return ranked


def provider_cost_summary(db: dict[str, Any]) -> dict[str, Any]:
    rows = db.get("provider_health") if isinstance(db.get("provider_health"), dict) else {}
    items = []
    for name, raw in rows.items():
        if not isinstance(raw, dict):
            continue
        item = {
            "provider": str(raw.get("provider") or name),
            "requests": int(raw.get("requests", 0) or 0),
            "cost_per_1000_requests": _cost_per_1000(raw),
            "estimated_cost": provider_estimated_cost(raw),
            "score": provider_score(raw),
        }
        items.append(item)
    items.sort(key=lambda item: (-item["estimated_cost"], item["provider"]))
    return {
        "providers": items,
        "estimated_total_cost": round(sum(item["estimated_cost"] for item in items), 6),
        "generated_at": utc_iso(),
    }
