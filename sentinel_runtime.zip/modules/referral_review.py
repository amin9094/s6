"""Qualification delay and review for new referrals; attribution never changes."""
from datetime import timedelta

from core.utils import parse_dt, utc_iso, utc_now


def begin_qualification(db, referred, referrer):
    uid, owner = str(referred), str(referrer)
    now = utc_now()
    rows = db.setdefault('referral_qualification', {})
    row = rows.setdefault(uid, {
        'user_id': uid, 'referrer_id': owner, 'status': 'pending',
        'created_at': utc_iso(now), 'eligible_at': utc_iso(now + timedelta(hours=24)),
        'reasons': [],
    })
    recent = [r for r in rows.values() if r['referrer_id'] == owner
              and (parse_dt(r.get('created_at')) or now) >= now - timedelta(hours=1)]
    if len(recent) >= 5:
        for item in recent:
            if item['status'] == 'pending':
                item['status'] = 'review'
                item['reasons'] = ['invitation_burst']
        from modules.incident_center import record_incident
        record_incident(db, source='referral', kind='invitation_burst',
                        detail=f'referrer={owner}', severity='warning', dedupe_minutes=60)
    return row


def is_qualified(db, user_id):
    uid = str(user_id)
    from modules.advanced_features import active_ban
    if active_ban(db, uid):
        return False
    row = db.get('referral_qualification', {}).get(uid)
    # Existing attribution is grandfathered; do not invalidate earned rewards.
    if row is None:
        return True
    return row.get('status') == 'qualified'


def settle_qualifications(db, *, limit=100):
    from core.domain import add_points, referral_program_settings, record_event, record_referral_purchase
    from core.economy_integrity import verified_referral_activity
    count = 0
    for row in db.get('referral_qualification', {}).values():
        if count >= limit:
            break
        if row.get('status') not in {'pending', 'approved'}:
            continue
        due = parse_dt(row.get('eligible_at'))
        if not due or due > utc_now():
            continue
        uid, owner = row['user_id'], row['referrer_id']
        if owner not in db.get('user_referrals', {}):
            row.update(status='rejected', reasons=['referrer_unavailable'])
            continue
        user = db.get('users', {}).get(uid, {})
        from modules.advanced_features import active_ban
        if not user or user.get('blocked') or user.get('banned') or active_ban(db, uid):
            continue
        row.update(status='qualified', qualified_at=utc_iso())
        qualified, _ = verified_referral_activity(db, owner)
        settings = referral_program_settings(db)
        referral = db['user_referrals'][owner]
        previous = int(referral.get('awarded_batches', 0))
        batches = len(qualified) // settings['signup_batch_size']
        if batches > previous:
            add_points(db, owner, (batches - previous) * settings['signup_batch_points'], 'referral',
                       source_event=f'referral_signup:{owner}:{batches}')
            referral['awarded_batches'] = batches
            referral['points_awarded'] = batches * settings['signup_batch_points']
        record_event(db, owner, 'referral_join')
        # Re-evaluate previously approved purchases after qualification matures.
        order_ids = {str(o.get('order_id') or o.get('id')) for o in db.get('vip_orders', [])
                     if str(o.get('user_id')) == uid and o.get('status') == 'approved' and o.get('refund_status') != 'full'}
        order_ids.update(str(e['metadata']['payment_id']) for e in db.get('economic_events', {}).values()
                         if e.get('kind') == 'verified_purchase' and str(e.get('metadata', {}).get('referred_user')) == uid)
        for order_id in order_ids:
            try:
                record_referral_purchase(db, uid, order_id)
            except ValueError as exc:
                if str(exc) != 'APPROVED_ORDER_REQUIRED':
                    raise
        count += 1
    return count


def review_referral(db, actor, user_id, decision):
    from modules.admin_access import has_permission, PERMISSION_REWARD_POINTS, PERMISSION_INCIDENTS
    from core.domain import audit
    from core.economy_integrity import economic_event
    if not all(has_permission(db, actor, p) for p in (PERMISSION_REWARD_POINTS, PERMISSION_INCIDENTS)):
        raise PermissionError('مجوز پاداش و رخدادها لازم است.')
    if decision not in {'approved', 'rejected'}:
        raise ValueError('تصمیم نامعتبر است.')
    row = db.get('referral_qualification', {}).get(str(user_id))
    if not row or row['status'] != 'review':
        raise ValueError('این دعوت در انتظار بررسی نیست.')
    economic_event(db, f'referral_review:{user_id}', row['referrer_id'], kind='referral_review',
                   value=decision, actor=actor, reason=','.join(row['reasons']), metadata={'referred_user': str(user_id)})
    row.update(status=decision, reviewed_by=str(actor), reviewed_at=utc_iso())
    audit(db, actor, 'referral_review', f'{user_id}:{decision}')
    return row
