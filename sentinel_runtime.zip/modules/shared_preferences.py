"""Migrate pre-8.34 Mini App preferences into the existing Bot authority.

The per-user marker prevents an old projection from overriding later Bot edits.
No second preference system is maintained after migration.
"""
from __future__ import annotations

from copy import deepcopy
from typing import Any

MARKER = "_shared_preferences_v1"


def migrate_shared_preference(db: dict[str, Any], user_id: int | str, section: str) -> None:
    uid = str(int(user_id))
    rows = db.setdefault(section, {})
    current = rows.get(uid)
    if isinstance(current, dict) and current.get(MARKER):
        return
    from core.storage import engine as storage
    from repositories.v2.common import json_load

    engine = storage.normalized_engine()
    legacy = None
    edited_at = ""
    if engine is not None and engine._schema_ready:
        with engine.transaction(read_only=True) as cursor:
            row = cursor.execute(
                "SELECT payload,updated_at FROM v8_user_preferences WHERE user_id=? AND section=?",
                (uid, section),
            ).fetchone()
        if row:
            legacy = json_load(row.get("payload"), {})
            edited_at = str(row.get("updated_at") or "")
    current = deepcopy(current) if isinstance(current, dict) else {}
    if section == "rules_acceptances" and "version" in current:
        current = {str(current.get("language") or "fa"): current}
    if isinstance(legacy, dict):
        if section == "rules_acceptances":
            if "version" in legacy:
                legacy = {str(legacy.get("language") or "fa"): legacy}
            for language in ("fa", "en"):
                old = legacy.get(language)
                present = current.get(language)
                if isinstance(old, dict) and (
                    not isinstance(present, dict)
                    or str(old.get("accepted_at") or "") > str(present.get("accepted_at") or "")
                ):
                    current[language] = deepcopy(old)
        else:
            latest = str(current.get("updated_at") or current.get("language_selected_at") or "")
            if not latest or edited_at >= latest:
                current.update(deepcopy(legacy))
                current["updated_at"] = edited_at
                if section == "user_profiles" and current.get("language") in {"fa", "en"}:
                    db.setdefault("users", {}).setdefault(uid, {"id": int(uid)})["language"] = current["language"]
    current[MARKER] = True
    rows[uid] = current
