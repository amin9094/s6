from __future__ import annotations

from typing import Any

from core.db import next_id
from core.domain import record_event
from core.utils import utc_iso
from modules.management_suite import FINAL_SIGNAL_STATUSES, signal_status_label
from modules.market_scope import MARKET_CATEGORIES, MARKET_FOREX, normalize_market_category, signal_market_category


def _default_cycle_name(cycle_id: int) -> str:
    return f"دوره #{max(1, int(cycle_id or 1))}"


def _clean_cycle_name(value: Any, *, fallback_id: int | None = None, required: bool = False) -> str:
    name = " ".join(str(value or "").replace("\r", " ").replace("\n", " ").split()).strip()
    if not name and fallback_id is not None:
        name = _default_cycle_name(fallback_id)
    if required and len(name) < 2:
        raise ValueError("نام دوره باید حداقل دو نویسه باشد")
    if len(name) > 120:
        raise ValueError("نام دوره حداکثر ۱۲۰ نویسه است")
    return name


def _period_index(periods: list[dict[str, Any]], cycle_id: int) -> int:
    for index, row in enumerate(periods):
        if isinstance(row, dict) and int(row.get("id", 0) or 0) == int(cycle_id):
            return index
    return -1


def ensure_signal_portal(db: dict[str, Any]) -> dict[str, Any]:
    """Normalize signal cycles, named period history, archive and user choices.

    A closed period is immutable history: its signals remain in ``signal_archive``
    and can be inspected or exported later.  Only the active period lives in
    ``signals`` and receives new public display numbers.
    """
    archive = db.setdefault("signal_archive", [])
    if not isinstance(archive, list):
        archive = []
        db["signal_archive"] = archive

    choices = db.setdefault("user_signal_choices", {})
    if not isinstance(choices, dict):
        choices = {}
        db["user_signal_choices"] = choices

    cycle = db.setdefault("signal_cycle", {})
    if not isinstance(cycle, dict):
        cycle = {}
        db["signal_cycle"] = cycle
    cycle_id = max(1, int(cycle.get("current_id", 1) or 1))
    cycle["current_id"] = cycle_id
    if not cycle.get("started_at"):
        cycle["started_at"] = utc_iso()
    cycle.setdefault("started_by", "migration")
    status = str(cycle.get("status") or cycle.get("current_status") or "active").strip().lower()
    if status not in {"active", "closed"}:
        status = "active"
    cycle["status"] = status
    cycle["current_status"] = status
    cycle_name = _clean_cycle_name(cycle.get("name") or cycle.get("current_name"), fallback_id=cycle_id)
    cycle["name"] = cycle_name
    cycle["current_name"] = cycle_name

    reset_history = cycle.setdefault("reset_history", [])
    if not isinstance(reset_history, list):
        reset_history = []
        cycle["reset_history"] = reset_history

    periods = cycle.setdefault("periods", [])
    if not isinstance(periods, list):
        periods = []
        cycle["periods"] = periods

    # Migrate the old reset-only history into first-class named periods.
    known_ids = {
        int(row.get("id", 0) or 0)
        for row in periods
        if isinstance(row, dict) and int(row.get("id", 0) or 0) > 0
    }
    for old in reset_history:
        if not isinstance(old, dict):
            continue
        old_id = int(old.get("cycle_id", 0) or 0)
        if old_id <= 0 or old_id in known_ids:
            continue
        periods.append(
            {
                "id": old_id,
                "name": _clean_cycle_name(old.get("name"), fallback_id=old_id),
                "status": "closed",
                "started_at": old.get("started_at"),
                "started_by": old.get("started_by") or "migration",
                "closed_at": old.get("ended_at") or old.get("closed_at"),
                "closed_by": str(old.get("reset_by") or old.get("closed_by") or "migration"),
                "signal_count": int(old.get("archived_signals", 0) or 0),
                "cancelled_schedules": int(old.get("cancelled_schedules", 0) or 0),
                "migrated_from_reset_history": True,
            }
        )
        known_ids.add(old_id)

    current_index = _period_index(periods, cycle_id)
    current_period = {
        "id": cycle_id,
        "name": cycle_name,
        "status": status,
        "started_at": cycle.get("started_at"),
        "started_by": str(cycle.get("started_by") or "system"),
        "closed_at": cycle.get("closed_at") if status == "closed" else None,
        "closed_by": str(cycle.get("closed_by") or "") if status == "closed" else "",
    }
    if current_index < 0:
        periods.append(current_period)
    else:
        existing = periods[current_index] if isinstance(periods[current_index], dict) else {}
        periods[current_index] = {**existing, **{key: value for key, value in current_period.items() if value not in {None, ""}}}
        periods[current_index]["status"] = status
        periods[current_index]["name"] = cycle_name
    periods.sort(key=lambda row: int(row.get("id", 0) or 0) if isinstance(row, dict) else 0)
    cycle["periods"] = periods[-1000:]

    highest = {category: 0 for category in MARKET_CATEGORIES}
    signals = db.setdefault("signals", [])
    if not isinstance(signals, list):
        signals = []
        db["signals"] = signals
    for row in signals:
        if not isinstance(row, dict):
            continue
        row.setdefault("cycle_id", cycle_id)
        category = signal_market_category(row)
        row["market_category"] = category
        if not int(row.get("display_number", 0) or 0):
            row["display_number"] = int(row.get("id", 0) or 0)
        if int(row.get("cycle_id", cycle_id) or cycle_id) == cycle_id:
            highest[category] = max(highest[category], int(row.get("display_number", 0) or 0))

    raw_numbers = cycle.get("next_numbers")
    next_numbers = raw_numbers if isinstance(raw_numbers, dict) else {}
    legacy_next = max(1, int(cycle.get("next_number", 1) or 1))
    for category in MARKET_CATEGORIES:
        default_next = legacy_next if not raw_numbers and category == MARKET_FOREX else 1
        next_numbers[category] = max(1, int(next_numbers.get(category, default_next) or default_next), highest[category] + 1)
    cycle["next_numbers"] = next_numbers
    cycle["next_number"] = next_numbers[MARKET_FOREX]
    return cycle

def renumber_public_signals(db: dict[str, Any]) -> None:
    """Compact display numbers per existing market/period; never mutate ids."""
    cycle = ensure_signal_portal(db)
    groups = {}
    seen = set()
    for row in [*db.get('signals', []), *db.get('signal_archive', [])]:
        if not isinstance(row, dict):
            continue
        key = (int(row.get('cycle_id') or cycle['current_id']), signal_market_category(row))
        identity = (key, str(row['id']))
        if identity in seen:
            continue
        seen.add(identity)
        groups.setdefault(key, []).append(row)
    numbers = {}
    for key, rows in groups.items():
        rows.sort(key=lambda r: (str(r.get('created_at') or ''), int(r['id'])))
        for number, row in enumerate(rows, 1):
            row['display_number'] = number
            numbers[str(row['id'])] = number
    for row in [*db.get('signals', []), *db.get('signal_archive', [])]:
        if isinstance(row, dict) and str(row['id']) in numbers:
            row['display_number'] = numbers[str(row['id'])]
    for category in MARKET_CATEGORIES:
        cycle['next_numbers'][category] = len(groups.get((int(cycle['current_id']), category), [])) + 1
    cycle['next_number'] = cycle['next_numbers'][MARKET_FOREX]
    for choices in db.get('user_signal_choices', {}).values():
        if isinstance(choices, dict):
            for sid, choice in choices.items():
                if str(sid) in numbers and isinstance(choice, dict):
                    choice['display_number'] = numbers[str(sid)]


def reserve_signal_identity(db: dict[str, Any], market_category: str = MARKET_FOREX) -> dict[str, Any]:
    cycle = ensure_signal_portal(db)
    if str(cycle.get("status") or "active") != "active":
        raise ValueError("دوره فعالی وجود ندارد؛ ابتدا یک دوره جدید شروع کنید")
    category = normalize_market_category(market_category)
    numbers = cycle.setdefault("next_numbers", {})
    display_number = max(1, int(numbers.get(category, 1) or 1))
    numbers[category] = display_number + 1
    if category == MARKET_FOREX:
        cycle["next_number"] = numbers[category]
    return {
        "id": next_id(db, "signal"),
        "cycle_id": int(cycle.get("current_id", 1) or 1),
        "display_number": display_number,
        "market_category": category,
    }


def release_reserved_signal_number(db: dict[str, Any], identity: dict[str, Any]) -> bool:
    """Return the latest category counter when rendering failed before storage."""
    cycle = ensure_signal_portal(db)
    cycle_id = int(identity.get("cycle_id", 0) or 0)
    display_number = int(identity.get("display_number", 0) or 0)
    category = normalize_market_category(identity.get("market_category"))
    if cycle_id != int(cycle.get("current_id", 1) or 1):
        return False
    numbers = cycle.setdefault("next_numbers", {})
    if int(numbers.get(category, 1) or 1) != display_number + 1:
        return False
    if any(
        isinstance(row, dict)
        and int(row.get("cycle_id", 0) or 0) == cycle_id
        and signal_market_category(row) == category
        and signal_display_number(row) == display_number
        for row in db.get("signals", [])
    ):
        return False
    numbers[category] = max(1, display_number)
    if category == MARKET_FOREX:
        cycle["next_number"] = numbers[category]
    return True


def signal_display_number(row: dict[str, Any] | None) -> int:
    if not isinstance(row, dict):
        return 0
    return int(row.get("display_number", 0) or row.get("id", 0) or 0)


def current_signal_cycle(db: dict[str, Any]) -> dict[str, Any]:
    return dict(ensure_signal_portal(db))


def reset_signal_cycle(
    db: dict[str, Any],
    admin_id: int | str,
    name: str = "",
) -> dict[str, Any]:
    """Backward-compatible rollover used by older Telegram buttons.

    Nothing is deleted: the active period is closed and archived, then a named
    period starts with display number ``#1`` for each market.
    """
    cycle = ensure_signal_portal(db)
    next_id_value = int(cycle.get("current_id", 1) or 1) + 1
    result = rollover_signal_cycle(
        db,
        admin_id,
        new_name=_clean_cycle_name(name, fallback_id=next_id_value),
    )
    closed = result["closed"]
    started = result["started"]
    return {
        "old_cycle_id": int(closed["id"]),
        "old_cycle_name": str(closed["name"]),
        "new_cycle_id": int(started["id"]),
        "new_cycle_name": str(started["name"]),
        "archived_signals": int(closed.get("signal_count", 0) or 0),
        "cancelled_schedules": int(closed.get("cancelled_schedules", 0) or 0),
        "reset_at": started.get("started_at"),
    }

def _delivered_to(row: dict[str, Any], channel: str) -> bool:
    delivered = row.get("delivered_channels")
    if isinstance(delivered, list):
        return channel in delivered
    return row.get("target") in {channel, "both"}


def user_visible_signals(
    db: dict[str, Any],
    *,
    vip: bool,
    market_category: str | None = None,
) -> list[dict[str, Any]]:
    ensure_signal_portal(db)
    category = normalize_market_category(market_category) if market_category else None
    rows: list[dict[str, Any]] = []
    for row in db.get("signals", []):
        if not isinstance(row, dict):
            continue
        if category and signal_market_category(row) != category:
            continue
        if _delivered_to(row, "public") or (vip and _delivered_to(row, "private")):
            rows.append(row)
    rows.sort(key=lambda row: (str(row.get("created_at") or ""), int(row.get("id", 0) or 0)), reverse=True)
    return rows


def set_user_signal_choice(
    db: dict[str, Any],
    user_id: int | str,
    signal_id: int | str,
    choice: str,
) -> dict[str, Any]:
    if choice not in {"taken", "skipped"}:
        raise ValueError("انتخاب سیگنال نامعتبر است")
    target = int(signal_id)
    signal = next(
        (row for row in db.get("signals", []) if isinstance(row, dict) and int(row.get("id", 0) or 0) == target),
        None,
    )
    if not signal:
        raise ValueError("سیگنال در دوره فعلی پیدا نشد")
    uid = str(user_id)
    user_rows = db.setdefault("user_signal_choices", {}).setdefault(uid, {})
    key = str(target)
    previous = user_rows.get(key) if isinstance(user_rows.get(key), dict) else {}
    row = {
        "signal_id": target,
        "cycle_id": int(signal.get("cycle_id", 1) or 1),
        "display_number": signal_display_number(signal),
        "market_category": signal_market_category(signal),
        "choice": choice,
        "selected_at": previous.get("selected_at") or utc_iso(),
        "updated_at": utc_iso(),
    }
    user_rows[key] = row
    return row


def get_user_signal_choice(db: dict[str, Any], user_id: int | str, signal_id: int | str) -> dict[str, Any] | None:
    rows = db.get("user_signal_choices", {}).get(str(user_id), {})
    if not isinstance(rows, dict):
        return None
    row = rows.get(str(int(signal_id)))
    return dict(row) if isinstance(row, dict) else None


def _result_bucket(row: dict[str, Any]) -> str:
    status = str(row.get("status") or "open")
    highest = int(row.get("highest_target_hit", 0) or 0)
    profit = float(row.get("profit_percent", 0) or 0)
    if status == "target_complete":
        return "full_win"
    if status == "stop":
        return "loss"
    if status == "breakeven":
        return "breakeven"
    if status == "manual_close":
        if profit > 0:
            return "partial_win"
        if profit < 0:
            return "loss"
        return "breakeven"
    if status == "no_entry":
        return "no_entry"
    if status == "cancelled":
        return "cancelled"
    if highest > 0 or status.startswith("tp") or status == "partial_close":
        return "partial_win"
    if status in FINAL_SIGNAL_STATUSES:
        return "settled"
    return "open"



def signal_cycle_rows(db: dict[str, Any], cycle_id: int | str) -> list[dict[str, Any]]:
    """Return one de-duplicated immutable view of all signals in a period."""
    ensure_signal_portal(db)
    target = int(cycle_id)
    selected: dict[tuple[int, int], dict[str, Any]] = {}
    # Archived rows first; a live row with the same identity wins.
    for source_priority, source in ((0, db.get("signal_archive", [])), (1, db.get("signals", []))):
        if not isinstance(source, list):
            continue
        for raw in source:
            if not isinstance(raw, dict) or int(raw.get("cycle_id", 0) or 0) != target:
                continue
            row = dict(raw)
            key = (int(row.get("id", 0) or 0), signal_display_number(row))
            previous = selected.get(key)
            previous_priority = int(previous.get("_source_priority", -1)) if isinstance(previous, dict) else -1
            if previous is None or source_priority > previous_priority:
                row["_source_priority"] = source_priority
                selected[key] = row
    rows = []
    for row in selected.values():
        row.pop("_source_priority", None)
        rows.append(row)
    rows.sort(
        key=lambda row: (
            str(row.get("created_at") or row.get("published_at") or ""),
            int(row.get("id", 0) or 0),
        )
    )
    return rows


def _cycle_stats_from_rows(rows: list[dict[str, Any]]) -> dict[str, Any]:
    buckets = {
        "open": 0,
        "full_win": 0,
        "partial_win": 0,
        "breakeven": 0,
        "loss": 0,
        "no_entry": 0,
        "cancelled": 0,
        "settled": 0,
    }
    profit_sum = 0.0
    risk_sum = 0.0
    forex = 0
    crypto = 0
    for row in rows:
        bucket = _result_bucket(row)
        buckets[bucket if bucket in buckets else "settled"] += 1
        profit_sum += float(row.get("profit_percent", 0) or 0)
        try:
            risk_sum += float(row.get("risk", row.get("risk_percent", 0)) or 0)
        except (TypeError, ValueError):
            pass
        if signal_market_category(row) == MARKET_FOREX:
            forex += 1
        else:
            crypto += 1
    wins = buckets["full_win"] + buckets["partial_win"]
    losses = buckets["loss"]
    decided = wins + losses
    return {
        "total": len(rows),
        "forex": forex,
        "crypto": crypto,
        **buckets,
        "wins": wins,
        "losses": losses,
        "decided": decided,
        "win_rate": wins / decided * 100 if decided else 0.0,
        "profit_percent_sum": round(profit_sum, 4),
        "average_profit_percent": round(profit_sum / len(rows), 4) if rows else 0.0,
        "average_risk_percent": round(risk_sum / len(rows), 4) if rows else 0.0,
        "first_signal_at": (rows[0].get("created_at") or rows[0].get("published_at")) if rows else None,
        "last_signal_at": (rows[-1].get("created_at") or rows[-1].get("published_at")) if rows else None,
    }


def signal_cycle_summary(db: dict[str, Any], cycle_id: int | str) -> dict[str, Any]:
    cycle = ensure_signal_portal(db)
    target = int(cycle_id)
    period = next(
        (dict(row) for row in cycle.get("periods", []) if isinstance(row, dict) and int(row.get("id", 0) or 0) == target),
        None,
    )
    if period is None:
        raise ValueError("دوره موردنظر پیدا نشد")
    stats = _cycle_stats_from_rows(signal_cycle_rows(db, target))
    return {**period, "stats": stats, "signal_count": stats["total"]}


def list_signal_cycles(db: dict[str, Any], *, limit: int = 100) -> list[dict[str, Any]]:
    cycle = ensure_signal_portal(db)
    rows: list[dict[str, Any]] = []
    for period in cycle.get("periods", []):
        if not isinstance(period, dict):
            continue
        try:
            rows.append(signal_cycle_summary(db, int(period.get("id", 0) or 0)))
        except ValueError:
            continue
    rows.sort(key=lambda row: int(row.get("id", 0) or 0), reverse=True)
    return rows[: max(1, min(int(limit or 100), 1000))]


def rename_signal_cycle(
    db: dict[str, Any],
    cycle_id: int | str,
    name: str,
    admin_id: int | str,
) -> dict[str, Any]:
    cycle = ensure_signal_portal(db)
    target = int(cycle_id)
    clean_name = _clean_cycle_name(name, required=True)
    index = _period_index(cycle.get("periods", []), target)
    if index < 0:
        raise ValueError("دوره موردنظر پیدا نشد")
    cycle["periods"][index]["name"] = clean_name
    cycle["periods"][index]["renamed_at"] = utc_iso()
    cycle["periods"][index]["renamed_by"] = str(admin_id)
    if target == int(cycle.get("current_id", 1) or 1):
        cycle["name"] = clean_name
        cycle["current_name"] = clean_name
    return signal_cycle_summary(db, target)



def delete_signal_cycle(db: dict[str, Any], cycle_id: int | str, admin_id: int | str) -> dict[str, Any]:
    """Permanently remove one closed signal period and its period-owned rows."""
    cycle = ensure_signal_portal(db)
    target = int(cycle_id)
    current_id = int(cycle.get("current_id", 1) or 1)
    if target == current_id and str(cycle.get("status") or "active") == "active":
        raise ValueError("دوره فعال قابل حذف نیست؛ ابتدا آن را ببندید.")
    periods = cycle.get("periods", [])
    index = _period_index(periods, target)
    if index < 0:
        raise ValueError("دوره موردنظر پیدا نشد")
    period = dict(periods[index])
    if str(period.get("status") or "closed") == "active":
        raise ValueError("دوره فعال قابل حذف نیست؛ ابتدا آن را ببندید.")
    signal_ids = {
        int(row.get("id", 0) or 0)
        for source in (db.get("signals", []), db.get("signal_archive", []))
        for row in source
        if isinstance(row, dict) and int(row.get("cycle_id", 0) or 0) == target
    }
    before_live = len(db.get("signals", []))
    before_archive = len(db.get("signal_archive", []))
    db["signals"] = [row for row in db.get("signals", []) if not (isinstance(row, dict) and int(row.get("cycle_id", 0) or 0) == target)]
    db["signal_archive"] = [row for row in db.get("signal_archive", []) if not (isinstance(row, dict) and int(row.get("cycle_id", 0) or 0) == target)]
    periods.pop(index)
    for user_rows in db.get("user_signal_choices", {}).values():
        if not isinstance(user_rows, dict):
            continue
        for key in list(user_rows):
            row = user_rows.get(key)
            if (isinstance(row, dict) and int(row.get("cycle_id", 0) or 0) == target) or int(key or 0) in signal_ids:
                user_rows.pop(key, None)
    for key in ("journal", "journal_entries"):
        rows = db.get(key)
        if isinstance(rows, list):
            db[key] = [row for row in rows if not (isinstance(row, dict) and int(row.get("cycle_id", 0) or 0) == target)]
    record_event(db, str(admin_id), "delete_signal_cycle")
    return {
        "id": target,
        "name": str(period.get("name") or f"دوره #{target}"),
        "deleted_live": before_live - len(db["signals"]),
        "deleted_archive": before_archive - len(db["signal_archive"]),
        "deleted_signal_ids": sorted(signal_ids),
    }

def close_signal_cycle(db: dict[str, Any], admin_id: int | str) -> dict[str, Any]:
    """Close the active period without deleting any signal or starting another."""
    cycle = ensure_signal_portal(db)
    if str(cycle.get("status") or "active") != "active":
        return {**signal_cycle_summary(db, cycle.get("current_id", 1)), "already_closed": True}
    now = utc_iso()
    cycle_id = int(cycle.get("current_id", 1) or 1)
    active_rows = [
        dict(row)
        for row in db.get("signals", [])
        if isinstance(row, dict) and int(row.get("cycle_id", cycle_id) or cycle_id) == cycle_id
    ]
    archive = db.setdefault("signal_archive", [])
    existing_index = {
        (int(row.get("cycle_id", 0) or 0), int(row.get("id", 0) or 0)): index
        for index, row in enumerate(archive)
        if isinstance(row, dict)
    }
    for row in active_rows:
        key = (cycle_id, int(row.get("id", 0) or 0))
        archived = {
            **(archive[existing_index[key]] if key in existing_index and isinstance(archive[existing_index[key]], dict) else {}),
            **row,
            "archived_at": now,
            "archived_by": str(admin_id),
            "archive_reason": "signal_period_closed",
        }
        if key in existing_index:
            # A compatibility mirror may already exist in the archive. The live
            # row is authoritative at close time, so update rather than keeping
            # a stale result/P&L snapshot.
            archive[existing_index[key]] = archived
        else:
            existing_index[key] = len(archive)
            archive.append(archived)
    # Remove only the rows that belong to the period being closed. Future or
    # migrated rows from another period remain untouched.
    db["signals"] = [
        row
        for row in db.get("signals", [])
        if not isinstance(row, dict) or int(row.get("cycle_id", cycle_id) or cycle_id) != cycle_id
    ]

    cancelled_schedules = 0
    for row in db.get("scheduled_signals", []):
        if not isinstance(row, dict) or row.get("status") not in {"pending", "retry", "retrying", "processing", "failed"}:
            continue
        row["status"] = "cancelled"
        row["cancelled_at"] = now
        row["cancelled_by"] = str(admin_id)
        row["cancel_reason"] = "signal_period_closed"
        cancelled_schedules += 1

    cycle["status"] = "closed"
    cycle["current_status"] = "closed"
    cycle["closed_at"] = now
    cycle["closed_by"] = str(admin_id)
    index = _period_index(cycle.get("periods", []), cycle_id)
    if index < 0:
        cycle["periods"].append({"id": cycle_id})
        index = len(cycle["periods"]) - 1
    summary_stats = _cycle_stats_from_rows(signal_cycle_rows(db, cycle_id))
    cycle["periods"][index].update(
        {
            "id": cycle_id,
            "name": _clean_cycle_name(cycle.get("name"), fallback_id=cycle_id),
            "status": "closed",
            "started_at": cycle.get("started_at"),
            "started_by": str(cycle.get("started_by") or "system"),
            "closed_at": now,
            "closed_by": str(admin_id),
            "signal_count": summary_stats["total"],
            "cancelled_schedules": cancelled_schedules,
            "stats_snapshot": summary_stats,
        }
    )
    history = cycle.setdefault("reset_history", [])
    if not any(isinstance(row, dict) and int(row.get("cycle_id", 0) or 0) == cycle_id for row in history):
        history.append(
            {
                "cycle_id": cycle_id,
                "name": cycle["periods"][index]["name"],
                "started_at": cycle.get("started_at"),
                "ended_at": now,
                "reset_by": str(admin_id),
                "archived_signals": summary_stats["total"],
                "cancelled_schedules": cancelled_schedules,
            }
        )
    cycle["reset_history"] = history[-1000:]
    return signal_cycle_summary(db, cycle_id)


def start_signal_cycle(
    db: dict[str, Any],
    admin_id: int | str,
    name: str,
) -> dict[str, Any]:
    """Start a named period after the previous one has been closed."""
    cycle = ensure_signal_portal(db)
    if str(cycle.get("status") or "active") == "active":
        raise ValueError("ابتدا دوره فعال را ببندید")
    periods = cycle.setdefault("periods", [])
    next_cycle_id = max(
        [int(cycle.get("current_id", 1) or 1)]
        + [int(row.get("id", 0) or 0) for row in periods if isinstance(row, dict)]
    ) + 1
    clean_name = _clean_cycle_name(name, required=True)
    now = utc_iso()
    period = {
        "id": next_cycle_id,
        "name": clean_name,
        "status": "active",
        "started_at": now,
        "started_by": str(admin_id),
        "closed_at": None,
        "closed_by": "",
        "signal_count": 0,
    }
    periods.append(period)
    periods.sort(key=lambda row: int(row.get("id", 0) or 0) if isinstance(row, dict) else 0)
    cycle.update(
        {
            "current_id": next_cycle_id,
            "name": clean_name,
            "current_name": clean_name,
            "status": "active",
            "current_status": "active",
            "started_at": now,
            "started_by": str(admin_id),
            "closed_at": None,
            "closed_by": "",
            "next_numbers": {category: 1 for category in MARKET_CATEGORIES},
            "next_number": 1,
        }
    )
    return signal_cycle_summary(db, next_cycle_id)


def rollover_signal_cycle(
    db: dict[str, Any],
    admin_id: int | str,
    *,
    new_name: str,
) -> dict[str, Any]:
    """Atomically close the active period and start a new named one."""
    ensure_signal_portal(db)
    clean_name = _clean_cycle_name(new_name, required=True)
    closed = close_signal_cycle(db, admin_id)
    started = start_signal_cycle(db, admin_id, clean_name)
    return {"closed": closed, "started": started}


def signal_cycle_detail(
    db: dict[str, Any],
    cycle_id: int | str,
    *,
    offset: int = 0,
    limit: int = 50,
) -> dict[str, Any]:
    rows = signal_cycle_rows(db, cycle_id)
    start = max(0, int(offset or 0))
    size = max(1, min(int(limit or 50), 500))
    return {
        "cycle": signal_cycle_summary(db, cycle_id),
        "items": rows[start : start + size],
        "total": len(rows),
        "offset": start,
        "limit": size,
        "next_offset": start + size if start + size < len(rows) else None,
    }

def signal_portal_stats(
    db: dict[str, Any],
    user_id: int | str,
    *,
    vip: bool,
    market_category: str | None = None,
) -> dict[str, Any]:
    rows = user_visible_signals(db, vip=vip, market_category=market_category)
    uid = str(user_id)
    choices = db.get("user_signal_choices", {}).get(uid, {})
    choices = choices if isinstance(choices, dict) else {}
    result: dict[str, Any] = {
        "cycle_id": int(ensure_signal_portal(db).get("current_id", 1) or 1),
        "market_category": normalize_market_category(market_category) if market_category else "all",
        "total": len(rows),
        "open": 0,
        "full_win": 0,
        "partial_win": 0,
        "breakeven": 0,
        "loss": 0,
        "no_entry": 0,
        "cancelled": 0,
        "taken": 0,
        "skipped": 0,
        "taken_open": 0,
        "taken_wins": 0,
        "taken_losses": 0,
        "taken_breakeven": 0,
        "taken_profit_sum": 0.0,
        "taken_win_rate": 0.0,
    }
    for row in rows:
        bucket = _result_bucket(row)
        if bucket in result:
            result[bucket] += 1
        choice = choices.get(str(int(row.get("id", 0) or 0)))
        selected = str(choice.get("choice")) if isinstance(choice, dict) else ""
        if selected == "skipped":
            result["skipped"] += 1
            continue
        if selected != "taken":
            continue
        result["taken"] += 1
        result["taken_profit_sum"] += float(row.get("profit_percent", 0) or 0)
        if bucket == "open":
            result["taken_open"] += 1
        elif bucket in {"full_win", "partial_win"}:
            result["taken_wins"] += 1
        elif bucket == "loss":
            result["taken_losses"] += 1
        elif bucket == "breakeven":
            result["taken_breakeven"] += 1
    decided = result["taken_wins"] + result["taken_losses"]
    result["taken_win_rate"] = result["taken_wins"] / decided * 100 if decided else 0.0
    return result


def user_signal_status_text(row: dict[str, Any]) -> str:
    highest = int(row.get("highest_target_hit", 0) or 0)
    if str(row.get("status") or "open") == "target_complete":
        return "تمام تارگت‌ها لمس شد"
    if highest:
        return f"TP{highest} لمس شده"
    return signal_status_label(str(row.get("status") or "open"))
