from __future__ import annotations

from typing import Any

from core.db import next_id
from core.utils import utc_iso

FOLLOWUP_LABELS = {
    "entry_hit": "ورود فعال شد",
    "tp1": "تارگت اول لمس شد",
    "tp2": "تارگت دوم لمس شد",
    "tp3": "تارگت سوم لمس شد",
    "breakeven": "معامله ریسک‌فری شد",
    "near_stop": "قیمت به حد ضرر نزدیک شده",
    "stop": "حد ضرر لمس شد",
}


def create_followup(db: dict[str, Any], signal: dict[str, Any], event: str, *, actor_id: int | str, message: str = "") -> dict[str, Any]:
    row = {
        "id": next_id(db, "smart_followup"),
        "signal_id": signal.get("id"),
        "display_number": signal.get("display_number"),
        "symbol": signal.get("symbol"),
        "event": event,
        "label": FOLLOWUP_LABELS.get(event, event),
        "message": str(message or "")[:1000],
        "actor_id": str(actor_id),
        "status": "created",
        "created_at": utc_iso(),
    }
    db.setdefault("smart_followups", []).append(row)
    db["smart_followups"] = db["smart_followups"][-2000:]
    return row
