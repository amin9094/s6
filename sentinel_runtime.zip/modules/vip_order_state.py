from __future__ import annotations

from dataclasses import dataclass
from typing import Any

PAYMENT_METHOD_CARD = "card"
PAYMENT_METHOD_USDT = "usdt"
MANUAL_PAYMENT_METHODS = frozenset({PAYMENT_METHOD_CARD, PAYMENT_METHOD_USDT})

ORDER_PENDING = "pending"
ORDER_APPROVING = "approving"
ORDER_APPROVED = "approved"
ORDER_REJECTED = "rejected"
ORDER_CANCELLED = "cancelled"
ORDER_EXPIRED = "expired"
ORDER_NEEDS_RECEIPT = "needs_receipt"

ORDER_STATES = frozenset(
    {
        ORDER_PENDING,
        ORDER_APPROVING,
        ORDER_APPROVED,
        ORDER_REJECTED,
        ORDER_CANCELLED,
        ORDER_EXPIRED,
        ORDER_NEEDS_RECEIPT,
    }
)
TERMINAL_STATES = frozenset({ORDER_APPROVED, ORDER_REJECTED, ORDER_CANCELLED, ORDER_EXPIRED})
REVIEWABLE_STATES = frozenset({ORDER_PENDING})
RESUBMITTABLE_STATES = frozenset({ORDER_REJECTED, ORDER_CANCELLED, ORDER_NEEDS_RECEIPT, ORDER_EXPIRED})
CANCELLABLE_STATES = frozenset({ORDER_PENDING, ORDER_NEEDS_RECEIPT})

_ALLOWED_TRANSITIONS: dict[str, frozenset[str]] = {
    ORDER_PENDING: frozenset({ORDER_APPROVING, ORDER_REJECTED, ORDER_CANCELLED, ORDER_NEEDS_RECEIPT, ORDER_EXPIRED}),
    ORDER_APPROVING: frozenset({ORDER_APPROVED, ORDER_PENDING}),
    ORDER_REJECTED: frozenset({ORDER_PENDING}),
    ORDER_CANCELLED: frozenset({ORDER_PENDING}),
    ORDER_NEEDS_RECEIPT: frozenset({ORDER_PENDING, ORDER_CANCELLED}),
    ORDER_EXPIRED: frozenset({ORDER_PENDING}),
    ORDER_APPROVED: frozenset(),
}


@dataclass(frozen=True)
class ManualPaymentEvidence:
    payment_method: str
    amount_toman: int
    receipt_required: bool
    receipt_attached: bool
    zero_value_valid: bool

    @property
    def valid(self) -> bool:
        if self.payment_method not in MANUAL_PAYMENT_METHODS:
            return False
        if self.amount_toman < 0:
            return False
        if self.receipt_required:
            return self.receipt_attached
        return self.zero_value_valid


def _safe_int(value: Any, default: int = 0) -> int:
    try:
        return int(round(float(value)))
    except (TypeError, ValueError, OverflowError):
        return default


def order_amount_toman(order: dict[str, Any]) -> int:
    """Return the canonical integer Toman amount for legacy or normalized rows."""
    for key in ("amount_toman", "price", "payable_toman"):
        if key in order and order.get(key) is not None:
            return _safe_int(order.get(key), -1)
    pricing = order.get("pricing") if isinstance(order.get("pricing"), dict) else {}
    return _safe_int(pricing.get("payable_toman"), -1)


def order_base_price_toman(order: dict[str, Any]) -> int:
    for key in ("base_price", "original_amount_toman"):
        if key in order and order.get(key) is not None:
            return max(0, _safe_int(order.get(key)))
    pricing = order.get("pricing") if isinstance(order.get("pricing"), dict) else {}
    return max(0, _safe_int(pricing.get("base_price", order_amount_toman(order))))


def order_discount_amount_toman(order: dict[str, Any]) -> int:
    if order.get("discount_amount") is not None:
        return max(0, _safe_int(order.get("discount_amount")))
    pricing = order.get("pricing") if isinstance(order.get("pricing"), dict) else {}
    return max(0, _safe_int(pricing.get("discount_amount")))


def order_receipt_reference(order: dict[str, Any]) -> str:
    for key in ("receipt_key", "receipt_id", "receipt_file_id", "receipt_object_key", "receipt_path"):
        value = str(order.get(key) or "").strip()
        if value:
            return value
    return ""


def zero_value_order_is_valid(order: dict[str, Any]) -> bool:
    """Validate that a zero-value order came from a real free plan or full discount.

    This prevents an arbitrary malformed order with amount=0 from being manually
    approved. Free plans are valid when their base price is zero. A paid plan is
    valid only when the recorded discount covers the full base price and a coupon
    snapshot is present.
    """
    amount = order_amount_toman(order)
    if amount != 0:
        return False
    base = order_base_price_toman(order)
    if base == 0:
        return True
    coupon = str(order.get("coupon") or "").strip()
    pricing = order.get("pricing") if isinstance(order.get("pricing"), dict) else {}
    coupon = coupon or str(pricing.get("coupon") or "").strip()
    return bool(coupon) and order_discount_amount_toman(order) >= base


def manual_payment_evidence(
    order: dict[str, Any],
    *,
    receipt_attached: bool | None = None,
) -> ManualPaymentEvidence:
    method = str(order.get("payment_method") or "").strip().lower()
    amount = order_amount_toman(order)
    attached = bool(order_receipt_reference(order)) if receipt_attached is None else bool(receipt_attached)
    return ManualPaymentEvidence(
        payment_method=method,
        amount_toman=amount,
        receipt_required=amount > 0,
        receipt_attached=attached,
        zero_value_valid=zero_value_order_is_valid(order),
    )


def assert_manual_payment_evidence(
    order: dict[str, Any],
    *,
    receipt_attached: bool | None = None,
) -> ManualPaymentEvidence:
    evidence = manual_payment_evidence(order, receipt_attached=receipt_attached)
    if evidence.payment_method not in MANUAL_PAYMENT_METHODS:
        raise ValueError("PAYMENT_METHOD_INVALID")
    if evidence.amount_toman < 0:
        raise ValueError("PAYMENT_AMOUNT_INVALID")
    if evidence.receipt_required and not evidence.receipt_attached:
        raise ValueError("RECEIPT_REQUIRED")
    if not evidence.receipt_required and not evidence.zero_value_valid:
        raise ValueError("ZERO_VALUE_ORDER_INVALID")
    return evidence


def assert_transition(current: str, target: str) -> None:
    source = str(current or "").strip().lower()
    destination = str(target or "").strip().lower()
    if source not in ORDER_STATES or destination not in ORDER_STATES:
        raise ValueError("ORDER_STATE_INVALID")
    if destination not in _ALLOWED_TRANSITIONS.get(source, frozenset()):
        raise ValueError(f"ORDER_TRANSITION_INVALID:{source}->{destination}")


def assert_reviewable(order: dict[str, Any], *, receipt_attached: bool | None = None) -> ManualPaymentEvidence:
    status = str(order.get("status") or "").strip().lower()
    if status != ORDER_PENDING:
        raise ValueError("ORDER_NOT_PENDING")
    return assert_manual_payment_evidence(order, receipt_attached=receipt_attached)
