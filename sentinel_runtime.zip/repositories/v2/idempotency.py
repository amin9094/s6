from __future__ import annotations

import secrets
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from typing import Any

from core.storage.engine import DatabaseEngine, normalized_engine
from repositories.v2.common import json_dump, json_load, utc_iso

@dataclass(frozen=True)
class Reservation:
    state:str
    token:str=""
    response:dict[str,Any]|None=None

class IdempotencyRepository:
    def __init__(self,engine:DatabaseEngine|None=None): self.engine=engine or normalized_engine()

    def reserve(self,user_id:int|str,request_id:str,*,action:str,fingerprint:str,ttl_seconds:int=86400)->Reservation:
        if not request_id: raise ValueError("IDEMPOTENCY_KEY_REQUIRED")
        uid=str(user_id); now=datetime.now(UTC); expires=(now+timedelta(seconds=max(60,ttl_seconds))).isoformat(); token=secrets.token_hex(16)
        with self.engine.transaction() as cursor:
            row=cursor.execute("SELECT * FROM v8_idempotency WHERE user_id=? AND request_id=?",(uid,request_id)).fetchone()
            if row:
                if str(row["action"])!=action or str(row["fingerprint"])!=fingerprint: return Reservation("conflict")
                try: expired=datetime.fromisoformat(str(row["expires_at"]).replace("Z","+00:00"))<=now
                except Exception: expired=True
                if not expired:
                    if str(row["state"])=="complete": return Reservation("replay",response=json_load(row.get("response"),{}) or {})
                    return Reservation("in_progress")
                cursor.execute("DELETE FROM v8_idempotency WHERE user_id=? AND request_id=?",(uid,request_id))
            cursor.execute("INSERT INTO v8_idempotency(user_id,request_id,action,fingerprint,state,response,owner_token,expires_at,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
                           (uid,request_id,action,fingerprint,"in_progress",None,token,expires,now.isoformat(),now.isoformat()))
        return Reservation("new",token=token)

    def complete(self,user_id:int|str,request_id:str,*,token:str,response:dict[str,Any])->None:
        with self.engine.transaction() as cursor:
            row=cursor.execute("SELECT owner_token,state FROM v8_idempotency WHERE user_id=? AND request_id=?",(str(user_id),request_id)).fetchone()
            if not row or str(row["owner_token"])!=token or str(row["state"])!="in_progress": raise ValueError("IDEMPOTENCY_OWNERSHIP_LOST")
            cursor.execute("UPDATE v8_idempotency SET state='complete',response=?,updated_at=? WHERE user_id=? AND request_id=?",
                           (json_dump(response),utc_iso(),str(user_id),request_id))

    def replace_completed_response(self,user_id:int|str,request_id:str,*,response:dict[str,Any])->None:
        """Replace a completed response after an async post-commit finalizer.

        Some actions, notably manual VIP approval, must create a Telegram invite
        on the bot event loop after the synchronous database action. The final
        response is written back so idempotent replays never return an
        intermediate ``approving`` state.
        """
        with self.engine.transaction() as cursor:
            cursor.execute(
                "UPDATE v8_idempotency SET response=?,updated_at=? WHERE user_id=? AND request_id=? AND state='complete'",
                (json_dump(response),utc_iso(),str(user_id),request_id),
            )
            if cursor.rowcount != 1:
                raise ValueError("IDEMPOTENCY_COMPLETION_NOT_FOUND")

    def reset_completed(self,user_id:int|str,request_id:str)->None:
        """Delete a completed reservation when its required async finalizer fails."""
        with self.engine.transaction() as cursor:
            cursor.execute(
                "DELETE FROM v8_idempotency WHERE user_id=? AND request_id=? AND state='complete'",
                (str(user_id),request_id),
            )

    def abort(self,user_id:int|str,request_id:str,*,token:str)->None:
        with self.engine.transaction() as cursor:
            cursor.execute("DELETE FROM v8_idempotency WHERE user_id=? AND request_id=? AND owner_token=? AND state='in_progress'",
                           (str(user_id),request_id,token))

    def cleanup(self)->int:
        now=utc_iso()
        with self.engine.transaction() as cursor:
            cursor.execute("DELETE FROM v8_idempotency WHERE expires_at < ?",(now,)); return cursor.rowcount
