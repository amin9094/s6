from __future__ import annotations

from typing import Any

from core.storage.engine import DatabaseEngine, normalized_engine
from repositories.v2.common import decode_cursor, encode_cursor, json_dump, json_load, new_id, utc_iso


class JournalRepository:
    def __init__(self,engine:DatabaseEngine|None=None): self.engine=engine or normalized_engine()
    def add(self,user_id:int|str,payload:dict[str,Any])->dict[str,Any]:
        """Create a journal row once for each position.

        The partial unique index on ``position_id`` is the concurrency boundary.
        ``ON CONFLICT DO NOTHING`` keeps PostgreSQL transactions usable and lets
        an idempotent retry return the canonical row instead of surfacing an
        integrity error or creating a second journal entry.
        """
        now=str(payload.get("opened_at") or utc_iso())
        row={**payload,"id":str(payload.get("id") or new_id("jnl")),"user_id":str(user_id),
             "symbol":str(payload.get("symbol") or "").upper().replace("/",""),"side":str(payload.get("side") or "").upper(),
             "status":str(payload.get("status") or "open"),"volume":float(payload.get("volume") or 0),
             "remaining_volume":float(payload.get("remaining_volume",payload.get("volume") or 0)),
             "pnl_amount":float(payload.get("pnl_amount") or 0),"pnl_percent":float(payload.get("pnl_percent") or 0),
             "opened_at":now,"updated_at":utc_iso()}
        if not row["symbol"] or row["side"] not in {"BUY","SELL"}: raise ValueError("INVALID_JOURNAL_ENTRY")
        position_id=str(row.get("position_id") or "") or None
        with self.engine.transaction() as cursor:
            cursor.execute("""INSERT INTO v8_journal_entries(id,user_id,account_id,position_id,signal_id,symbol,side,status,entry_price,exit_price,
                volume,remaining_volume,pnl_amount,pnl_percent,opened_at,closed_at,updated_at,payload) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT DO NOTHING""",
                (row["id"],row["user_id"],str(row.get("account_id") or "") or None,position_id,
                 str(row.get("signal_id") or "") or None,row["symbol"],row["side"],row["status"],row.get("entry_price"),row.get("exit_price"),
                 row["volume"],row["remaining_volume"],row["pnl_amount"],row["pnl_percent"],row["opened_at"],row.get("closed_at"),row["updated_at"],json_dump(row)))
            if cursor.rowcount == 1:
                return row
            canonical=None
            if position_id:
                canonical=cursor.execute("SELECT * FROM v8_journal_entries WHERE user_id=? AND position_id=?",(row["user_id"],position_id)).fetchone()
            if canonical is None:
                canonical=cursor.execute("SELECT * FROM v8_journal_entries WHERE user_id=? AND id=?",(row["user_id"],row["id"])).fetchone()
            if not canonical:
                raise RuntimeError("JOURNAL_PERSISTENCE_FAILED")
            return self._decode(canonical)
    def get(self,user_id:int|str,entry_id:str|int)->dict[str,Any]|None:
        with self.engine.transaction(read_only=True) as cursor:
            row=cursor.execute("SELECT * FROM v8_journal_entries WHERE user_id=? AND id=?",(str(user_id),str(entry_id))).fetchone()
        return self._decode(row) if row else None
    def get_by_position(self,user_id:int|str,position_id:str|int)->dict[str,Any]|None:
        with self.engine.transaction(read_only=True) as cursor:
            row=cursor.execute("SELECT * FROM v8_journal_entries WHERE user_id=? AND position_id=?",(str(user_id),str(position_id))).fetchone()
        return self._decode(row) if row else None
    def get_by_signal(self,user_id:int|str,signal_id:str|int,*,source:str="")->dict[str,Any]|None:
        """Return the most recent journal decision for a signal.

        A signal may legitimately have an older skipped row and a newer taken
        row, so this lookup is ordered and may optionally be narrowed by the
        transparent ``source`` stored inside the payload.
        """
        with self.engine.transaction(read_only=True) as cursor:
            rows=cursor.execute(
                "SELECT * FROM v8_journal_entries WHERE user_id=? AND signal_id=? ORDER BY opened_at DESC,id DESC",
                (str(user_id),str(signal_id)),
            ).fetchall()
        decoded=[self._decode(row) for row in rows]
        if source:
            decoded=[row for row in decoded if str(row.get("source") or "")==str(source)]
        return decoded[0] if decoded else None

    def update_by_position(self,user_id:int|str,position_id:str|int,values:dict[str,Any])->dict[str,Any]:
        row=self.get_by_position(user_id,position_id)
        if not row: raise ValueError("JOURNAL_ENTRY_NOT_FOUND")
        return self.update(user_id,row["id"],values)
    def update(self,user_id:int|str,entry_id:str|int,values:dict[str,Any])->dict[str,Any]:
        row=self.get(user_id,entry_id)
        if not row: raise ValueError("JOURNAL_ENTRY_NOT_FOUND")
        row.update(values); row["updated_at"]=utc_iso()
        with self.engine.transaction() as cursor:
            cursor.execute("""UPDATE v8_journal_entries SET status=?,exit_price=?,remaining_volume=?,pnl_amount=?,pnl_percent=?,closed_at=?,updated_at=?,payload=?
                WHERE id=? AND user_id=?""",
                (row.get("status"),row.get("exit_price"),float(row.get("remaining_volume") or 0),float(row.get("pnl_amount") or 0),float(row.get("pnl_percent") or 0),
                 row.get("closed_at"),row["updated_at"],json_dump(row),str(entry_id),str(user_id)))
        return row
    def archive(self,user_id:int|str,entry_id:str|int)->dict[str,Any]: return self.update(user_id,entry_id,{"status":"archived"})
    def list_for_user(self,user_id:int|str,*,cursor:str|None=None,limit:int=30,status:str="",symbol:str="")->dict[str,Any]:
        size=max(1,min(int(limit or 30),100)); clauses=["user_id=?"]; params:list[Any]=[str(user_id)]
        if status: clauses.append("status=?");params.append(status)
        else: clauses.append("status<>\'archived\'")
        if symbol: clauses.append("symbol=?");params.append(str(symbol).upper().replace("/",""))
        decoded=decode_cursor(cursor)
        if decoded: clauses.append("(opened_at < ? OR (opened_at = ? AND id < ?))");params.extend([decoded[0],decoded[0],decoded[1]])
        params.append(size+1)
        with self.engine.transaction(read_only=True) as db:
            rows=db.execute(f"SELECT * FROM v8_journal_entries WHERE {' AND '.join(clauses)} ORDER BY opened_at DESC,id DESC LIMIT ?",params).fetchall()  # nosec B608
        more=len(rows)>size;rows=rows[:size];items=[self._decode(r) for r in rows]
        nxt=encode_cursor(str(rows[-1]["opened_at"]),str(rows[-1]["id"])) if more and rows else None
        return {"items":items,"next_cursor":nxt,"limit":size}
    @staticmethod
    def _decode(row:dict[str,Any])->dict[str,Any]:
        data=json_load(row.get("payload"),{}) or {};data.update({k:row.get(k) for k in row if k!="payload"});return data
