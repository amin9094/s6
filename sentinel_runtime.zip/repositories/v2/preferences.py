from __future__ import annotations

from typing import Any

from core.storage.engine import DatabaseEngine, normalized_engine
from repositories.v2.common import json_dump, json_load, utc_iso


class PreferenceRepository:
    def __init__(self,engine:DatabaseEngine|None=None): self.engine=engine or normalized_engine()
    def get(self,user_id:int|str,section:str,default:Any=None)->Any:
        with self.engine.transaction(read_only=True) as cursor:
            row=cursor.execute("SELECT payload FROM v8_user_preferences WHERE user_id=? AND section=?",(str(user_id),str(section))).fetchone()
        return json_load(row.get("payload"),default) if row else default
    def set(self,user_id:int|str,section:str,payload:Any)->Any:
        now=utc_iso()
        with self.engine.transaction() as cursor:
            cursor.execute("""INSERT INTO v8_user_preferences(user_id,section,updated_at,payload) VALUES(?,?,?,?)
                ON CONFLICT(user_id,section) DO UPDATE SET updated_at=excluded.updated_at,payload=excluded.payload""",
                (str(user_id),str(section),now,json_dump(payload)))
        return payload
    def patch(self,user_id:int|str,section:str,values:dict[str,Any])->dict[str,Any]:
        uid, key = str(user_id), str(section)
        with self.engine.atomic() as cursor:
            cursor.execute("""INSERT INTO v8_user_preferences(user_id,section,updated_at,payload) VALUES(?,?,?,?)
                ON CONFLICT(user_id,section) DO NOTHING""",(uid,key,utc_iso(),json_dump({})))
            sql="SELECT payload FROM v8_user_preferences WHERE user_id=? AND section=?"
            if self.engine.dialect.name == "postgres": sql += " FOR UPDATE"
            row=cursor.execute(sql,(uid,key)).fetchone()
            current=json_load(row.get("payload"),{}) if row else {}
            if not isinstance(current,dict): current={}
            current.update(values)
            return self.set(uid,key,current)
