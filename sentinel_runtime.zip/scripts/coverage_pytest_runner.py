#!/usr/bin/env python3
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

from coverage import Coverage
import pytest

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ["bot_runtime", "core", "modules", "services", "repositories", "handlers", "jobs", "ui"]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("test_target", nargs="*")
    args = parser.parse_args()
    existing = str(os.environ.get("PYTHONPATH") or "").strip()
    os.environ["PYTHONPATH"] = str(ROOT) if not existing else f"{ROOT}{os.pathsep}{existing}"
    if str(ROOT) not in sys.path:
        sys.path.insert(0, str(ROOT))
    coverage = Coverage(
        data_file=str(ROOT / ".coverage"),
        data_suffix=True,
        branch=True,
        source=SOURCE,
    )
    coverage.start()
    return_code = 1
    try:
        return_code = int(pytest.main(["-q", *args.test_target]) or 0)
    finally:
        coverage.stop()
        coverage.save()
        sys.stdout.flush()
        sys.stderr.flush()
    return return_code


if __name__ == "__main__":
    code = 1
    try:
        code = main()
    finally:
        sys.stdout.flush(); sys.stderr.flush()
        os._exit(int(code))
