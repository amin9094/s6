#!/usr/bin/env python3
from __future__ import annotations

import json
import tempfile
import sys
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from core.storage.engine import DatabaseEngine
from repositories.v2.commerce import CommerceRepository
from scripts.vip_database_integrity import audit_database


def run_manual_payment_smoke(*, operations: int = 60) -> dict[str, Any]:
    total = max(12, min(500, int(operations)))
    with tempfile.TemporaryDirectory(prefix="sentinel-payment-smoke-") as directory:
        engine = DatabaseEngine(database_url="", sqlite_path=Path(directory) / "smoke.sqlite3")
        engine.ensure_schema()
        repo = CommerceRepository(engine)
        approved = 0
        rejected_then_resubmitted = 0
        simulated_failures = 0
        for index in range(total):
            user_id = str(900_000 + index)
            method = "usdt" if index % 2 else "card"
            receipt_id = f"smoke-receipt-{index}-a"
            repo.create_receipt(user_id, {
                "id": receipt_id,
                "receipt_id": receipt_id,
                "checksum": f"{index:064x}"[-64:],
                "object_key": f"smoke/{index}/a.webp",
                "storage_backend": "local",
                "mime_type": "image/webp",
                "size_bytes": 256,
            })
            quote_id = f"smoke-quote-{index}"
            repo.create_quote(user_id, {
                "quote_id": quote_id,
                "plan_id": "vip-smoke",
                "plan_name": "VIP Smoke",
                "duration_days": 30,
                "base_price": 1_000_000,
                "payable_toman": 1_000_000,
                "payment_method": method,
                "payment_amount_usdt": "10.000000" if method == "usdt" else "0.000000",
                "expires_at": "2999-01-01T00:00:00+00:00",
            })
            order = repo.submit_order_from_quote(
                user_id,
                quote_id=quote_id,
                receipt_id=receipt_id,
                transaction_hash=f"smoke-tx-{index}" if method == "usdt" else "",
            )
            if index % 4 == 0:
                repo.reject_order(order["id"], actor_id="1", reason="smoke resubmission check")
                receipt_b = f"smoke-receipt-{index}-b"
                repo.create_receipt(user_id, {
                    "id": receipt_b,
                    "receipt_id": receipt_b,
                    "checksum": f"{index + total:064x}"[-64:],
                    "object_key": f"smoke/{index}/b.webp",
                    "storage_backend": "local",
                    "mime_type": "image/webp",
                    "size_bytes": 256,
                })
                order = repo.resubmit_order(user_id, order["id"], receipt_id=receipt_b)
                rejected_then_resubmitted += 1
            if index % 7 == 0:
                repo.claim_order_for_approval(order["id"], actor_id="2")
                repo.release_order_approval(order["id"], actor_id="2", error="simulated Telegram outage")
                simulated_failures += 1
            repo.claim_order_for_approval(order["id"], actor_id="3")
            link = f"https://t.me/+payment-smoke-{index}"
            repo.store_order_approval_invite(order["id"], actor_id="3", invite_link=link)
            final = repo.finalize_order_approval(order["id"], actor_id="3", invite_link=link)
            if final.get("status") != "approved":
                raise RuntimeError(f"manual payment smoke did not approve order {order['id']}")
            approved += 1
        audit = audit_database(engine, repair_safe=False, project_legacy=False)
        if not audit["healthy"]:
            raise RuntimeError(f"manual payment smoke integrity failure: {audit['issues']}")
        if len(repo.list_entitlements()) != total:
            raise RuntimeError("manual payment smoke entitlement count mismatch")
        return {
            "status": "passed",
            "operations": total,
            "approved": approved,
            "rejected_then_resubmitted": rejected_then_resubmitted,
            "simulated_telegram_failures": simulated_failures,
            "integrity_issue_count": audit["issue_count"],
        }


def main() -> int:
    print(json.dumps(run_manual_payment_smoke(), ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
