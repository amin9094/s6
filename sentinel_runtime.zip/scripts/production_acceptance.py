#!/usr/bin/env python3
"""Explicit, credential-gated production acceptance for SENTINEL.

This script never converts missing external credentials into a pass. It combines
local release checks with the deployed HTTPS surface, test-only PostgreSQL,
Redis and Telegram probes, a real Gemini generation test, the Mini App browser
smoke, and the compiled MT5 connector requirement. Results are written as a
machine-readable attestation that can later be bound to a production proof.
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess  # nosec B404 -- fixed internal acceptance commands
import sys
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]


def _now() -> str:
    return datetime.now(UTC).isoformat()


def _run(name: str, command: list[str], *, env: dict[str, str] | None = None) -> dict[str, Any]:
    completed = subprocess.run(  # nosec B603 -- command is assembled from fixed project scripts
        command,
        cwd=ROOT,
        env=env or os.environ.copy(),
        text=True,
        capture_output=True,
        check=False,
        timeout=600,
    )
    return {
        "name": name,
        "ok": completed.returncode == 0,
        "returncode": completed.returncode,
        "stdout": completed.stdout[-12_000:],
        "stderr": completed.stderr[-12_000:],
    }


def _gemini_check() -> dict[str, Any]:
    from modules.gemini_ai import gemini_live_health

    health = gemini_live_health(force=True, generation_test=True)
    required = ("reachable", "authenticated", "model_available", "generation_test_passed")
    return {
        "name": "gemini_live_generation",
        "ok": all(bool(health.get(key)) for key in required),
        "health": health,
    }



def _configuration_check() -> dict[str, Any]:
    raw_owner = str(os.getenv("PRIMARY_ADMIN_ID") or "").strip()
    digest = str(os.getenv("SENTINEL_DOCKER_IMAGE_DIGEST") or "").strip()
    owner_ok = raw_owner.isdigit() and int(raw_owner) > 0
    digest_ok = digest.startswith("sha256:") and len(digest) >= 71
    python_ok = sys.version_info[:2] == (3, 12)
    return {
        "name": "production_configuration",
        "ok": owner_ok and digest_ok and python_ok,
        "primary_admin_configured": owner_ok,
        "docker_image_digest_configured": digest_ok,
        "python_runtime": f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
        "python_target_ok": python_ok,
    }


def _dependency_lock_check() -> dict[str, Any]:
    path = ROOT / "DEPENDENCY_LOCK_STATUS.json"
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        return {"name": "dependency_lock_attestation", "ok": False, "error": f"{type(exc).__name__}: {exc}"}
    ok = bool(payload.get("complete_transitive_lock")) and bool(payload.get("hashes_required")) and bool(payload.get("production_attested")) and str(payload.get("python_target")) == "3.12"
    return {"name": "dependency_lock_attestation", "ok": ok, "status": payload}


def _security_audit_check() -> dict[str, Any]:
    from core.db import read_db_sections
    from modules.security_audit import verify_security_audit_chain
    rows = read_db_sections(("security_audit_log",)).get("security_audit_log", [])
    result = verify_security_audit_chain([row for row in rows if isinstance(row, dict)])
    return {"name": "security_audit_chain", "ok": bool(result.get("valid")), **result}

def _mt5_artifact_check() -> dict[str, Any]:
    source = ROOT / "webapp" / "downloads" / "SentinelConnector.mq5"
    binary = ROOT / "webapp" / "downloads" / "SentinelConnector.ex5"
    return {
        "name": "mt5_compiled_connector",
        "ok": source.is_file() and binary.is_file() and binary.stat().st_size > 0,
        "source_present": source.is_file(),
        "ex5_present": binary.is_file(),
        "ex5_size": binary.stat().st_size if binary.is_file() else 0,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Run credential-gated SENTINEL production acceptance.")
    parser.add_argument("--base-url", required=True, help="Deployed HTTPS URL")
    parser.add_argument("--output", type=Path, default=ROOT / "quality-artifacts" / "production_acceptance.json")
    parser.add_argument("--skip-browser", action="store_true", help="Skip Playwright only while preparing a candidate")
    parser.add_argument("--skip-mt5-ex5", action="store_true", help="Skip EX5 only while preparing a candidate")
    args = parser.parse_args()
    if not args.base_url.startswith("https://"):
        raise RuntimeError("production base URL must use HTTPS")

    started = _now()
    checks: list[dict[str, Any]] = []
    checks.append(_configuration_check())
    checks.append(_dependency_lock_check())
    try:
        checks.append(_security_audit_check())
    except Exception as exc:
        checks.append({"name": "security_audit_chain", "ok": False, "error": f"{type(exc).__name__}: {exc}"})
    checks.append(_run("release_gate", [sys.executable, "scripts/release_gate.py"]))
    checks.append(_run("postdeploy_http", [sys.executable, "scripts/postdeploy_smoke.py", "--base-url", args.base_url]))
    checks.append(_run("live_staging", [sys.executable, "scripts/live_staging_attestation.py"]))
    try:
        checks.append(_gemini_check())
    except Exception as exc:
        checks.append({"name": "gemini_live_generation", "ok": False, "error": f"{type(exc).__name__}: {exc}"})

    if not args.skip_browser:
        checks.append(_run(
            "miniapp_playwright",
            ["node", "scripts/miniapp_playwright_smoke.mjs", args.base_url],
        ))
    else:
        checks.append({"name": "miniapp_playwright", "ok": False, "skipped": True, "reason": "explicit candidate-only skip"})

    mt5 = _mt5_artifact_check()
    if args.skip_mt5_ex5 and not mt5["ok"]:
        mt5.update({"skipped": True, "reason": "explicit candidate-only skip"})
    checks.append(mt5)

    failures = [row["name"] for row in checks if not row.get("ok")]
    report = {
        "schema_version": 1,
        "version": (ROOT / "VERSION").read_text(encoding="utf-8").strip(),
        "started_at": started,
        "finished_at": _now(),
        "base_url": args.base_url,
        "status": "PASSED" if not failures else "FAILED",
        "failures": failures,
        "checks": checks,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
