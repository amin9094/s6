#!/usr/bin/env python3
from __future__ import annotations

import argparse
import gzip
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from typing import Any

from core.db import read_db_sections
from modules.security_audit import verify_security_audit_chain


def main() -> int:
    parser = argparse.ArgumentParser(description="Verify and optionally archive SENTINEL's tamper-evident security audit chain.")
    parser.add_argument("--archive", type=Path, help="Write the verified rows as gzip JSONL.")
    args = parser.parse_args()
    db = read_db_sections(("security_audit_log",))
    rows = [row for row in db.get("security_audit_log", []) if isinstance(row, dict)]
    result = verify_security_audit_chain(rows)
    if args.archive and result.get("valid"):
        args.archive.parent.mkdir(parents=True, exist_ok=True)
        with gzip.open(args.archive, "wt", encoding="utf-8") as handle:
            for row in rows:
                handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True, default=str) + "\n")
        result["archive"] = str(args.archive)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result.get("valid") else 1


if __name__ == "__main__":
    raise SystemExit(main())
