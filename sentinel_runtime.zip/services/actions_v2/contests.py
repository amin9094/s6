from __future__ import annotations

import math
from typing import Any

from core.db import with_db
from modules.contest import (
    add_candle_guess,
    add_chart_answer,
    add_news_direction_answer,
    add_price_guess,
)
from services.actions_v2.context import ActionContext
from services.actions_v2.registry import action


def _positive_number(value: Any) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError("CONTEST_ANSWER_INVALID") from exc
    if not math.isfinite(number) or number <= 0:
        raise ValueError("CONTEST_ANSWER_INVALID")
    return number


@action("contest_submit")
def contest_submit(ctx: ActionContext) -> dict[str, Any]:
    """Submit one Mini App contest entry into the same legacy contest store used by Telegram.

    Contest helpers remain the single source of truth for deadline, duplicate-entry,
    validation and winner semantics. The Mini App only adapts transport payloads.
    """
    kind = str(ctx.payload.get("kind") or "").strip().lower()
    raw_answer = ctx.payload.get("answer")

    def operation(db: dict[str, Any]) -> str:
        if kind == "price":
            return add_price_guess(db, ctx.user_id, _positive_number(raw_answer))
        if kind == "candle":
            return add_candle_guess(db, ctx.user_id, _positive_number(raw_answer))
        if kind == "chart":
            return add_chart_answer(db, ctx.user_id, str(raw_answer or "").upper().strip())
        if kind in {"news", "news_direction"}:
            return add_news_direction_answer(db, ctx.user_id, str(raw_answer or "").upper().strip())
        raise ValueError("CONTEST_KIND_INVALID")

    result = with_db(operation)
    if result == "INVALID":
        raise ValueError("CONTEST_ANSWER_INVALID")
    return {
        "kind": "news_direction" if kind == "news" else kind,
        "result": result,
        "accepted": result == "OK",
    }
