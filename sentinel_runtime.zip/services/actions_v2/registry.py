from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable

from services.actions_v2.context import ActionContext

Handler = Callable[[ActionContext], Any]

@dataclass(frozen=True)
class ActionSpec:
    name: str
    handler: Handler
    mutation: bool = True
    idempotency_required: bool = True
    admin_only: bool = False
    permission: str = ""

_REGISTRY: dict[str, ActionSpec] = {}


def action(name: str, *, mutation: bool = True, idempotency_required: bool = True,
           admin_only: bool = False, permission: str = "") -> Callable[[Handler], Handler]:
    def decorator(handler: Handler) -> Handler:
        if name in _REGISTRY:
            raise RuntimeError(f"duplicate Mini App action: {name}")
        _REGISTRY[name] = ActionSpec(name, handler, mutation, idempotency_required, admin_only, permission)
        return handler
    return decorator


def get_action(name: str) -> ActionSpec:
    try:
        return _REGISTRY[name]
    except KeyError:
        raise ValueError("UNKNOWN_ACTION") from None


def action_specs() -> dict[str, ActionSpec]:
    return dict(_REGISTRY)
