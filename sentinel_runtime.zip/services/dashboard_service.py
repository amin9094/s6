from __future__ import annotations

from typing import Any

from config import is_admin as is_primary_admin
from core.db import load_db
from core.domain import is_vip
from core.models import TicketRecord, UserRecord, VipOrderRecord
from core.rate_limit import allow as rate_limit_allow
from core.utils import utc_iso
from core.webapp_auth import validate_init_data
from modules.admin_access import (
    PERMISSION_CAMPAIGNS,
    PERMISSION_CHANNEL_ATTRIBUTION,
    PERMISSION_CRM,
    PERMISSION_DASHBOARD,
    PERMISSION_MISSION_CONTROL,
    PERMISSION_RISK_BOARDS,
    PERMISSION_KPI_TRADER_MANAGE,
    PERMISSION_KPI_TRADER_VIEW,
    has_permission,
    is_any_admin,
)
from modules.action_inbox import action_inbox_snapshot
from modules.admin_control_center import is_module_enabled, notification_preferences
from modules.campaign_studio import campaign_studio_summary
from modules.channel_attribution import public_channel_attribution_summary
from modules.business_dashboard import commercial_dashboard
from modules.growth_link_lab import growth_link_lab
from modules.i18n import user_language
from modules.kpi_trader import (
    kpi_settings,
    kpi_team_dashboard,
    kpi_trader_dashboard,
    list_tasks_for_trader,
    monthly_points_awarded,
    trader_task_submission,
)
from modules.management_suite import FINAL_SIGNAL_STATUSES, is_admin_on_shift
from modules.mission_control import mission_control_snapshot
from modules.market_scope import MARKET_CRYPTO, MARKET_FOREX, signal_market_category
from modules.market_sessions import session_performance
from modules.personal_risk import personal_exposure, position_for_signal, prop_firm_snapshot, risk_profile
from modules.portfolio import journal_entries, journal_stats, watchlist_for_user
from modules.risk_exposure import exposure_snapshot, professional_exposure_boards
from modules.signal_live_card import live_card_payload
from modules.signal_portal import get_user_signal_choice, signal_portal_stats
from modules.signal_safety import entry_display
from modules.trust_center import build_trust_snapshot
from modules.market_intelligence import latest_snapshot
from modules.economic_calendar import cached_calendar_events, user_calendar_preferences
from modules.miniapp_product import vip_catalog
from modules.rules import current_rules, user_has_accepted_rules
from modules.user_intelligence import build_user_profile
from modules.team_operations import (
    notification_intelligence,
    subscription_growth_center,
    team_operations_calendar,
    team_performance_dashboard,
)
from services.access_policy import enabled_feature_payload


def _signal_entry_text(item: dict[str, Any]) -> str:
    try:
        return entry_display(item.get("entries") or [item.get("entry")])
    except (TypeError, ValueError):
        return str(item.get("entry") or "—")


def _signal_payload(db: dict[str, Any], uid: str, item: dict[str, Any]) -> dict[str, Any]:
    choice = get_user_signal_choice(db, uid, item.get("id", 0)) or {}
    targets = [str(value) for value in item.get("targets", []) if str(value).strip()]
    entries = [str(value) for value in item.get("entries", []) if str(value).strip()]
    if not entries and item.get("entry") not in {None, ""}:
        entries = [str(item.get("entry"))]
    return {
        "id": int(item.get("id", 0) or 0),
        "display_number": int(item.get("display_number", item.get("id", 0)) or 0),
        "cycle_id": int(item.get("cycle_id", 1) or 1),
        "market_category": signal_market_category(item),
        "symbol": str(item.get("symbol") or ""),
        "side": str(item.get("side") or "").lower(),
        "entries": entries,
        "entry": _signal_entry_text(item),
        "stop": str(item.get("stop") or ""),
        "targets": targets,
        "target": targets[0] if targets else "",
        "risk": str(item.get("risk") or ""),
        "risk_reward": str(item.get("risk_reward") or item.get("rr") or ""),
        "status": str(item.get("status") or "open"),
        "session": str(item.get("market_session_label") or item.get("market_session") or ""),
        "revision": int(item.get("revision", 1) or 1),
        "created_at": item.get("created_at"),
        "updated_at": item.get("updated_at"),
        "expires_at": item.get("expires_at"),
        "note": str(item.get("note") or item.get("analysis") or "")[:3000],
        "highest_target_hit": int(item.get("highest_target_hit", 0) or 0),
        "profit_percent": float(item.get("profit_percent", 0) or 0),
        "remaining_risk_percent": float(item.get("remaining_risk_percent", item.get("risk", 0)) or 0),
        "live": live_card_payload(item),
        "choice": dict(choice),
        "position": position_for_signal(db, uid, item),
    }


def build_dashboard_payload(
    init_data: str,
    bot_token: str,
    *,
    max_age_seconds: int = 900,
    scope: str = "full",
) -> dict[str, Any]:
    """Build the authenticated Mini App dashboard without exposing admin data."""
    identity = validate_init_data(init_data, bot_token, max_age_seconds=max_age_seconds)
    clean_scope = str(scope or "core").strip().lower()
    if clean_scope not in {"core", "admin", "full"}:
        raise ValueError("invalid dashboard scope")
    db = load_db()
    uid = str(identity.user_id)
    language = user_language(db, uid) or "fa"
    if not rate_limit_allow(uid, f"miniapp:dashboard:{clean_scope}", 0.25):
        raise ValueError("درخواست‌ها خیلی سریع ارسال می‌شوند؛ چند لحظه صبر کنید.")
    users = db.get("users", {})
    vip_users = db.get("vip_users", {})
    points = db.get("user_points", {})
    signal_choices = db.get("user_signal_choices", {})

    user: UserRecord = users.get(uid, {}) if isinstance(users, dict) else {}
    vip = vip_users.get(uid, {}) if isinstance(vip_users, dict) else {}
    orders: list[VipOrderRecord] = [
        item
        for item in db.get("vip_orders", [])
        if isinstance(item, dict) and str(item.get("user_id")) == uid
    ]
    tickets: list[TicketRecord] = [
        item
        for item in db.get("tickets", [])
        if isinstance(item, dict) and str(item.get("user_id")) == uid
    ]
    choices = signal_choices.get(uid, {}) if isinstance(signal_choices, dict) else {}
    active_signals = [
        item
        for item in db.get("signals", [])
        if isinstance(item, dict) and str(item.get("status") or "open") not in FINAL_SIGNAL_STATUSES
    ]
    vip_active = is_vip(db, uid)

    def visible_to_user(item: dict[str, Any]) -> bool:
        delivered = {str(value) for value in item.get("delivered_channels", [])}
        requested = {str(value) for value in item.get("requested_channels", [])}
        target = str(item.get("target") or "")
        public_visible = "public" in delivered or (not delivered and ("public" in requested or target in {"public", "both"}))
        private_visible = "private" in delivered or (not delivered and ("private" in requested or target in {"private", "both"}))
        return public_visible or (vip_active and private_visible)

    visible_signals = [item for item in db.get("signals", []) if isinstance(item, dict) and visible_to_user(item)]
    visible_signals.sort(key=lambda row: str(row.get("created_at") or ""), reverse=True)
    recent_orders = sorted(orders, key=lambda row: str(row.get("created_at") or ""), reverse=True)[:5]

    payload = {
        "user": {
            "id": identity.user_id,
            "username": identity.username or str(user.get("username") or ""),
            "first_name": identity.first_name or str(user.get("first_name") or ""),
            "last_name": identity.last_name or str(user.get("last_name") or ""),
            "language": language,
        },
        "account": {
            "points": max(0, int(points.get(uid, 0) or 0)) if isinstance(points, dict) else 0,
            "vip_active": vip_active,
            "vip_expires_at": vip.get("expires_at") if isinstance(vip, dict) else None,
            "orders_total": len(orders),
            "pending_orders": sum(1 for item in orders if item.get("status") in {"pending", "approving"}),
            "open_tickets": sum(1 for item in tickets if item.get("status") == "open"),
            "signal_choices": len(choices) if isinstance(choices, dict) else 0,
            "active_signals": len(active_signals),
            "active_forex_signals": sum(1 for item in active_signals if signal_market_category(item) == MARKET_FOREX),
            "active_crypto_signals": sum(1 for item in active_signals if signal_market_category(item) == MARKET_CRYPTO),
        },
        "market_intelligence": {
            "trust": build_trust_snapshot(db),
            "exposure": exposure_snapshot(db),
            "sessions": session_performance(db),
        },
        "risk_assistant": {
            "profile": dict(risk_profile(db, uid)),
            "exposure": personal_exposure(db, uid),
            "prop_firm": prop_firm_snapshot(db, uid),
        },
        "notification_preferences": notification_preferences(db, uid),
        "portfolio": {
            "watchlist": watchlist_for_user(db, uid),
            "journal": journal_entries(db, uid, limit=50),
            "journal_stats": journal_stats(db, uid),
        },
        "tickets": [
            {
                "id": int(item.get("id", 0) or 0),
                "subject": str(item.get("subject") or ""),
                "status": str(item.get("status") or ""),
                "category": str(item.get("category") or "general"),
                "priority": str(item.get("priority") or "normal"),
                "waiting_for": str(item.get("waiting_for") or "admin"),
                "sla_due_at": item.get("sla_due_at"),
                "updated_at": item.get("updated_at"),
                "created_at": item.get("created_at"),
                "closed_at": item.get("closed_at"),
                "satisfaction": dict(item.get("satisfaction") or {}) if isinstance(item.get("satisfaction"), dict) else None,
                "messages": [
                    {
                        "sender": str(message.get("sender") or "user"),
                        "text": str(message.get("text") or ""),
                        "created_at": message.get("created_at"),
                    }
                    for message in item.get("messages", [])
                    if isinstance(message, dict)
                ][-50:],
            }
            for item in sorted(tickets, key=lambda row: str(row.get("updated_at") or ""), reverse=True)[:20]
        ],
        "signals": [_signal_payload(db, uid, item) for item in visible_signals[:100]],
        "recent_signals": [_signal_payload(db, uid, item) for item in visible_signals[:12]],
        "signal_stats": signal_portal_stats(db, uid, vip=vip_active),
        "market_center": {
            "snapshot": latest_snapshot(db),
        },
        "calendar": {
            "preferences": dict(user_calendar_preferences(db, uid)),
            "events": cached_calendar_events(db, uid, period="week")[:80],
            "updated_at": db.get("economic_calendar", {}).get("cached_events_updated_at"),
        },
        "commerce": vip_catalog(db, uid, vip_active=vip_active),
        "recent_orders": [
            {
                "order_id": str(item.get("order_id") or ""),
                "plan_name": str(item.get("plan_name") or "VIP"),
                "status": str(item.get("status") or ""),
                "price": int(item.get("price", 0) or 0),
                "created_at": item.get("created_at"),
            }
            for item in recent_orders
        ],
        "generated_at": utc_iso(),
        "admin_available": is_any_admin(db, uid),
        "scope": clean_scope,
        "features": enabled_feature_payload(db),
        "rules": {
            **current_rules(db, language),
            "language": language,
            "accepted": user_has_accepted_rules(db, uid, language),
        },
    }
    if is_any_admin(db, uid) and clean_scope in {"admin", "full"} and (
        has_permission(db, uid, PERMISSION_KPI_TRADER_VIEW)
        or has_permission(db, uid, PERMISSION_KPI_TRADER_MANAGE)
    ):
        payload["kpi_trader"] = {
            "dashboard": kpi_trader_dashboard(db, uid),
            "tasks": [
                {
                    **dict(task),
                    "latest_submission": trader_task_submission(
                        db, str(task.get("id") or ""), uid
                    ),
                }
                for task in list_tasks_for_trader(db, uid)[:30]
            ],
        }
    if is_any_admin(db, uid) and clean_scope in {"admin", "full"}:
        admin_payload: dict[str, Any] = {}
        if is_admin_on_shift(db, uid) and has_permission(db, uid, PERMISSION_MISSION_CONTROL):
            admin_payload["mission_control"] = mission_control_snapshot(db)
            inbox = action_inbox_snapshot(db)
            inbox["items"] = [
                item
                for item in inbox["items"]
                if str(item.get("kind") or "") != "incident"
                and has_permission(db, uid, str(item.get("permission") or ""))
            ]
            inbox["visible_total"] = len(inbox["items"])
            inbox["critical"] = sum(
                1
                for item in inbox["items"]
                if str(item.get("severity") or item.get("priority") or "").lower() == "critical"
            )
            admin_payload["action_inbox"] = inbox
        if is_admin_on_shift(db, uid) and has_permission(db, uid, PERMISSION_RISK_BOARDS):
            admin_payload["risk_boards"] = professional_exposure_boards(db)
        if is_admin_on_shift(db, uid) and has_permission(db, uid, PERMISSION_DASHBOARD):
            admin_payload["business_dashboard"] = commercial_dashboard(db)
        if is_admin_on_shift(db, uid) and has_permission(
            db, uid, PERMISSION_KPI_TRADER_MANAGE
        ):
            admin_payload["kpi_trader"] = kpi_team_dashboard(db)
        if is_primary_admin(uid):
            admin_payload["kpi_owner_governance"] = {
                "settings": dict(kpi_settings(db)),
                "monthly_points_used": monthly_points_awarded(db),
            }
            managed_admin_ids = [
                int(value)
                for value in {
                    *[str(item) for item in db.get("delegated_admins", {})],
                }
                if str(value).isdigit() and str(value) != uid
            ]
            admin_payload["team_performance"] = team_performance_dashboard(
                db, managed_admin_ids
            )
            admin_payload["team_calendar"] = team_operations_calendar(
                db, admin_ids=managed_admin_ids
            )
            admin_payload["subscription_growth"] = subscription_growth_center(db)
            admin_payload["notification_intelligence"] = notification_intelligence(db)
        if is_admin_on_shift(db, uid) and has_permission(db, uid, PERMISSION_CRM):
            admin_payload["crm_profile"] = build_user_profile(db, uid)
        campaigns_enabled = is_module_enabled(db, "campaigns")
        if campaigns_enabled and is_admin_on_shift(db, uid) and has_permission(db, uid, PERMISSION_CAMPAIGNS):
            admin_payload["campaigns"] = campaign_studio_summary(db)
        if campaigns_enabled and is_admin_on_shift(db, uid) and has_permission(db, uid, PERMISSION_CHANNEL_ATTRIBUTION):
            admin_payload["channel_attribution"] = public_channel_attribution_summary(db)
            admin_payload["growth_link_lab"] = growth_link_lab(db)
        if admin_payload:
            payload["admin"] = admin_payload
    return payload
