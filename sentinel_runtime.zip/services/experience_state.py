"""Read-through access to normalized commerce; never copy orders into legacy storage."""
from core.db import snapshot, with_db
from repositories.v2.commerce import CommerceRepository
from repositories.v2.support import SupportRepository
from modules.admin_work_queue import reconcile_work_queue


def _pages(fetch):
    """Fail explicitly rather than reconciling an incomplete snapshot."""
    cursor = None
    seen = set()
    for _ in range(100):
        page = fetch(cursor)
        yield page['items']
        cursor = page.get('next_cursor')
        if not cursor:
            return
        key = str(cursor)
        if key in seen:
            raise RuntimeError('PAGINATION_CURSOR_REPEATED')
        seen.add(key)
    raise RuntimeError('PAGINATION_LIMIT_EXCEEDED')


def pending_orders(db=None):
    db = db if db is not None else snapshot()
    repo = CommerceRepository()
    rows = {str(o['order_id']): dict(o) for o in db.get('vip_orders', []) if o.get('status') in {'pending','approving'}}
    for status in ('pending','approving'):
        for items in _pages(lambda cursor: repo.list_all_orders(status=status, cursor=cursor, limit=100)):
            for row in items:
                rows[str(row['id'])] = {**row,'order_id':str(row['id']),'price':row.get('amount_toman',0),'normalized_order':True}
    return sorted(rows.values(),key=lambda r:str(r.get('created_at') or ''),reverse=True)


def user_orders(user_id):
    db=snapshot();uid=str(user_id)
    rows={str(o['order_id']):dict(o) for o in db.get('vip_orders',[]) if str(o.get('user_id'))==uid}
    repo=CommerceRepository()
    for items in _pages(lambda cursor: repo.list_for_user(uid, cursor=cursor, limit=100)):
        for row in items:rows[str(row['id'])]={**row,'order_id':str(row['id'])}
    return sorted(rows.values(),key=lambda r:str(r.get('created_at') or ''),reverse=True)


def reconcile_experience_work():
    db=snapshot(); repo=CommerceRepository()
    orders = [o for o in pending_orders(db) if o.get('normalized_order')]
    active = {str(o['order_id']) for o in orders}
    for item in db.get('admin_work_queue',{}).values():
        if item['type']=='payment' and item.get('metadata',{}).get('normalized') and item['status'] not in {'completed','cancelled'} and item['reference_id'] not in active:
            row=repo.get(item['reference_id'])
            if row:orders.append({**row,'order_id':str(row['id']),'normalized_order':True})
    tickets=[]; support=SupportRepository()
    for items in _pages(lambda cursor: support.list_all(cursor=cursor)):
        tickets.extend({**row,'normalized_ticket':True,'waiting_for':'user' if row.get('status')=='answered' else 'admin'} for row in items)
    active={str(t['id']) for t in tickets}
    for item in db.get('admin_work_queue',{}).values():
        if item['type']=='ticket' and item.get('metadata',{}).get('normalized') and item['status'] not in {'completed','cancelled'} and item['reference_id'] not in active:
            row=support.get(item['reference_id'])
            if row:tickets.append({**row,'normalized_ticket':True})
    return with_db(lambda state: reconcile_work_queue(state,external_payments=orders,external_tickets=tickets))


def admin_entity(db,actor,kind,reference):
    from modules.admin_work_queue import read_entity, can_access
    if not can_access(db,actor,kind):raise PermissionError('مجوز مشاهده این بخش را ندارید.')
    if kind=='payment':
        from services.vip_order_projection import project_normalized_order_to_legacy
        row=project_normalized_order_to_legacy(reference)
        if row:return row
    if kind=='ticket':
        row=SupportRepository().get(reference)
        if row:return {**row,'normalized_ticket':True}
    return read_entity(db,actor,kind,reference)


def search_palette(actor, query):
    from modules.admin_work_queue import palette_search, can_access
    db = snapshot()
    hint, _, term = str(query).strip().partition(' ')
    if can_access(db, actor, 'payment') and (hint == 'payment' or hint not in __import__('modules.admin_work_queue', fromlist=['SOURCES']).SOURCES):
        page = CommerceRepository().list_all_orders(query=term if hint == 'payment' else str(query), limit=20)
        current = {str(row['order_id']): row for row in db.get('vip_orders', [])}
        for row in page['items']:
            current[str(row['id'])] = {**row, 'order_id': str(row['id'])}
        db['vip_orders'] = list(current.values())
    if can_access(db,actor,'ticket') and (hint=='ticket' or hint not in __import__('modules.admin_work_queue',fromlist=['SOURCES']).SOURCES):
        page=SupportRepository().list_all(query=term if hint=='ticket' else str(query),include_closed=True,limit=20)
        current={str(row['id']):row for row in db.get('tickets',[])}
        for row in page['items']:current[str(row['id'])]=row
        db['tickets']=list(current.values())
    return palette_search(db, actor, query)


def update_normalized_ticket(actor, reference, *, body=None, request_key='', close=False):
    from modules.admin_work_queue import can_access
    if not can_access(snapshot(),actor,'ticket'):raise PermissionError('مجوز تیکت لازم است.')
    repo=SupportRepository()
    if not repo.get(reference):raise ValueError('تیکت پیدا نشد.')
    if close:return repo.update_status(reference,status='closed')
    repo.append_message(reference,sender_type='admin',sender_id=actor,body=body,idempotency_key=request_key)
    return repo.update_status(reference,status='answered')
