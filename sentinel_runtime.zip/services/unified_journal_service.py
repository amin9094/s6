from __future__ import annotations

from typing import Any

from core.db import with_db, with_db_read
from modules.portfolio import (
    add_journal_entry,
    add_partial_close,
    delete_journal_entry,
    journal_entries,
    reconcile_signal_journal_duplicates,
    update_journal_result,
)
from repositories.v2.journal import JournalRepository


def _legacy_payload(row: dict[str, Any], user_id: int | str) -> dict[str, Any]:
    legacy_id = int(row.get("id") or 0)
    side = str(row.get("side") or "").upper()
    if side == "LONG":
        side = "BUY"
    elif side == "SHORT":
        side = "SELL"
    return {
        **row,
        "id": f"legacy-{user_id}-{legacy_id}",
        "legacy_journal_id": legacy_id,
        "side": side,
        "opened_at": row.get("created_at") or row.get("opened_at"),
        "source": row.get("source") or "telegram_bot",
    }


def _normalized_match_for_legacy(
    repo: JournalRepository,
    user_id: int | str,
    legacy: dict[str, Any],
) -> dict[str, Any] | None:
    """Resolve the single canonical normalized row for one legacy journal row.

    Normalized Mini App rows are mirrored into the legacy JSON store.  Older
    releases then imported that mirror back as ``legacy-<user>-<id>``, which
    made one signal appear twice and doubled totals/PnL.  The external id is
    the strongest link; position and channel-signal identity are safe fallbacks
    for records created before the external link existed.
    """
    external_id = str(legacy.get("external_id") or "").strip()
    if external_id:
        row = repo.get(user_id, external_id)
        if row:
            return row
    position_id = legacy.get("position_id")
    if position_id not in (None, ""):
        row = repo.get_by_position(user_id, position_id)
        if row:
            return row
    signal_id = legacy.get("signal_id")
    source = str(legacy.get("source") or "").strip().lower()
    if signal_id not in (None, "") and source in {"channel_signal", "signal_taken", "telegram_bot", "miniapp"}:
        for candidate_source in ("channel_signal", "signal_taken", "telegram_bot", "miniapp", ""):
            row = repo.get_by_signal(user_id, signal_id, source=candidate_source)
            if row and str(row.get("status") or "") != "archived":
                return row
    return None


def _canonical_payload_from_legacy(
    legacy: dict[str, Any],
    canonical: dict[str, Any],
    user_id: int | str,
) -> dict[str, Any]:
    payload = _legacy_payload(legacy, user_id)
    # Keep normalized identity/position fields.  Legacy mirrors may not be able
    # to represent string position ids and must never detach a real position.
    payload["id"] = canonical["id"]
    payload["legacy_journal_id"] = int(legacy.get("id") or 0)
    payload["external_id"] = str(canonical.get("external_id") or legacy.get("external_id") or canonical["id"])
    for key in ("user_id", "account_id", "position_id", "signal_id", "source", "opened_at"):
        if canonical.get(key) not in (None, ""):
            payload[key] = canonical.get(key)
    return {**canonical, **payload}


def sync_legacy_journal_to_normalized(user_id: int | str, *, limit: int = 500) -> int:
    """Synchronize legacy rows without creating a second logical trade.

    The operation is idempotent and also repairs duplicate rows produced by
    pre-8.14.2 releases by archiving the synthetic ``legacy-*`` copy whenever a
    canonical normalized row already represents the same signal/position.
    """
    # Repair duplicate legacy rows first so Telegram and Mini App read the same
    # one-signal/one-journal projection immediately after deployment.
    with_db(lambda db: reconcile_signal_journal_duplicates(db, user_id))
    rows = with_db_read(lambda db: [dict(row) for row in journal_entries(db, user_id, limit=limit, include_archived=True)])
    repo = JournalRepository()
    synced = 0
    for legacy in rows:
        payload = _legacy_payload(legacy, user_id)
        if not payload.get("symbol") or payload.get("side") not in {"BUY", "SELL"}:
            continue
        synthetic_id = str(payload["id"])
        canonical = _normalized_match_for_legacy(repo, user_id, legacy)
        if canonical:
            canonical = repo.update(
                user_id,
                canonical["id"],
                _canonical_payload_from_legacy(legacy, canonical, user_id),
            )
            duplicate = repo.get(user_id, synthetic_id)
            if duplicate and str(duplicate.get("id")) != str(canonical.get("id")) and duplicate.get("status") != "archived":
                repo.archive(user_id, synthetic_id)
        else:
            existing = repo.get(user_id, synthetic_id)
            if existing:
                repo.update(user_id, synthetic_id, payload)
            else:
                repo.add(user_id, payload)
        synced += 1
    return synced


def _legacy_id_for(user_id: int | str, row: dict[str, Any]) -> int:
    direct = row.get("legacy_journal_id")
    try:
        if direct not in (None, ""):
            return int(direct)
    except (TypeError, ValueError):
        pass
    external_id = str(row.get("id") or "")
    if not external_id:
        return 0
    found = with_db_read(lambda db: next(
        (item for item in journal_entries(db, user_id, limit=5000, include_archived=True)
         if str(item.get("external_id") or "") == external_id),
        None,
    ))
    return int(found.get("id") or 0) if isinstance(found, dict) else 0




def _legacy_numeric_id(value: Any) -> int | None:
    if value in (None, ""):
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None

def mirror_normalized_journal_create(user_id: int | str, row: dict[str, Any]) -> dict[str, Any]:
    """Compatibility shim; normalized journal is the only persisted copy."""
    return dict(row)

def mirror_normalized_journal_result(user_id: int | str, row: dict[str, Any]) -> None:
    return None

def mirror_normalized_journal_partial(user_id: int | str, row: dict[str, Any], *, volume: float, exit_price: float, pnl_amount: float) -> None:
    return None

def mirror_normalized_journal_archive(user_id: int | str, row: dict[str, Any]) -> None:
    return None
