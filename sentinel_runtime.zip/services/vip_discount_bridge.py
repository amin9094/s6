from __future__ import annotations

from typing import Any

from core.db import with_db
from core.domain import consume_discount, release_discount, reserve_discount, validate_discount


def _order_snapshot(order_id: str, user_id: int | str, data: dict[str, Any]) -> dict[str, Any]:
    return {
        **data,
        "id": str(order_id),
        "order_id": str(order_id),
        "user_id": int(user_id) if str(user_id).isdigit() else str(user_id),
        "price": int(data.get("amount_toman") or data.get("payable_toman") or data.get("price") or 0),
        "amount_toman": int(data.get("amount_toman") or data.get("payable_toman") or data.get("price") or 0),
        "coupon": str(data.get("coupon") or "").strip().upper(),
    }


def reserve_normalized_order_discount(order_id: str, user_id: int | str, data: dict[str, Any]) -> bool:
    order = _order_snapshot(order_id, user_id, data)
    code = str(order.get("coupon") or "")
    if not code:
        return False

    def mutate(db: dict[str, Any]) -> bool:
        item = db.setdefault("discount_codes", {}).get(code)
        if not isinstance(item, dict):
            raise ValueError("COUPON_NOT_FOUND")
        reservations = item.get("reservations") if isinstance(item.get("reservations"), dict) else {}
        if str(reservations.get(str(order_id)) or "") == str(user_id):
            return False
        valid, message, canonical = validate_discount(
            db,
            code,
            user_id,
            plan_id=order.get("plan_id"),
            product_type="vip",
            order_amount=int(order.get("base_price") or order.get("price") or 0),
            payment_method=str(order.get("payment_method") or ""),
        )
        if not valid or not canonical:
            raise ValueError(f"COUPON_INVALID:{message}")
        reserve_discount(canonical, str(order_id), user_id, db=db)
        return True

    return bool(with_db(mutate))


def release_normalized_order_discount(order: dict[str, Any]) -> None:
    if not str(order.get("coupon") or "").strip():
        return
    with_db(lambda db: release_discount(db, _order_snapshot(str(order.get("id") or order.get("order_id")), order.get("user_id"), order)))


def consume_normalized_order_discount(order: dict[str, Any]) -> None:
    if not str(order.get("coupon") or "").strip():
        return
    with_db(lambda db: consume_discount(db, _order_snapshot(str(order.get("id") or order.get("order_id")), order.get("user_id"), order)))
