from __future__ import annotations

import asyncio
import copy
from concurrent.futures import ThreadPoolExecutor
from datetime import timedelta
from types import SimpleNamespace

import pytest

from tests.test_master_upgrade import OWNER
from tests.test_master_upgrade import canonical_store as _canonical_fixture
from tests.test_master_upgrade import state as _state_fixture


@pytest.fixture
def state():
    return _state_fixture.__wrapped__()


@pytest.fixture
def canonical_store(state, tmp_path, monkeypatch):
    return _canonical_fixture.__wrapped__(state, tmp_path, monkeypatch)


def test_mission_prize_is_unique_per_user_and_duplicate_safe(state, canonical_store):
    from core.db import load_db, with_db
    from core.domain import complete_mission
    from modules.missions import create_mission, find_mission

    m = with_db(lambda db: create_mission(db, title="audit", reward=25, event="manual"))
    with_db(
        lambda db: find_mission(db, m["id"]).update(
            prize={"points": 25, "vip_days": 0, "coupon_percent": 0}, max_completions=20, completions_count=0
        )
    )

    def claim(uid):
        return with_db(lambda db: complete_mission(db, uid, find_mission(db, m["id"])))

    with ThreadPoolExecutor(max_workers=4) as pool:
        results = list(pool.map(claim, ["1", "2", "1", "2"]))
    assert sum(results) == 2 and load_db()["user_points"] == {"1": 25, "2": 25}


def test_interleaved_writer_never_publishes_stale_cache(state, canonical_store, monkeypatch):
    import core.db as storage
    from core.domain import add_points

    original = storage._commit_sections_optimistic
    done = False

    def commit(store, **kwargs):
        nonlocal done
        result = original(store, **kwargs)
        if not done:
            done = True
            before = store._read()
            after = copy.deepcopy(before)
            add_points(after, 2, 20, "B", source_event="B")
            original(store, before=before, after=after, changed=storage._changed_sections(before, after))
        return result

    monkeypatch.setattr(storage, "_commit_sections_optimistic", commit)
    storage.with_db(lambda db: add_points(db, 1, 10, "A", source_event="A"))
    assert storage.load_db()["user_points"] == canonical_store._read()["user_points"] == {"1": 10, "2": 20}


def test_loop_limiter_survives_switching_loops():
    from core import async_runtime as runtime

    a, b = asyncio.new_event_loop(), asyncio.new_event_loop()

    async def get():
        return runtime._semaphore()

    try:
        first = a.run_until_complete(get())
        b.run_until_complete(get())
        assert a.run_until_complete(get()) is first
    finally:
        a.close()
        b.close()


def test_mission_edit_and_clone_are_consistent(state):
    from core.domain import complete_mission
    from modules.missions import create_mission, duplicate_mission, mission_available, update_mission

    m = create_mission(state, title="test", reward=25, event="manual")
    m.update(prize={"points": 25, "vip_days": 0, "coupon_percent": 0}, max_completions=1, completions_count=0)
    update_mission(state, m["id"], reward=100)
    assert complete_mission(state, 1, m) and state["user_points"]["1"] == 100
    clone = duplicate_mission(state, m["id"], OWNER)
    clone["active"] = True
    assert mission_available(clone) and clone["completions_count"] == 0


@pytest.mark.parametrize("expiry", ["7", "30", "none"])
def test_assigned_coupon_honours_reviewed_expiry(state, expiry):
    from core.utils import parse_dt, utc_now
    from modules import admin_creation as c

    draft = c.create_draft(state, OWNER, "reward", mode="quick")
    v = draft["values"]
    v.update(reward_type="discount_coupon", value=20, claim="assign", users=["1"], expiry=expiry)
    state["admin_creation_drafts"][draft["id"]]["values"] = v
    c.review(state, OWNER, draft["id"])
    c.publish(state, OWNER, draft["id"], draft["revision"])
    coupon = next(x for x in state["discount_codes"].values() if x.get("assigned_to") == "1")
    if expiry == "none":
        assert coupon["expires_at"] is None
    else:
        assert abs((parse_dt(coupon["expires_at"]) - utc_now()).total_seconds() / 86400 - int(expiry)) < 0.01


def test_hub_omits_sold_out_and_exhausted_rewards(state, monkeypatch):
    from services import miniapp_read_service_v2 as s

    state["settings"]["rewardItems"] = [
        {"id": 9, "name": "out", "stock": 0, "enabled": True},
        {"id": 10, "name": "claimed", "stock": 10, "per_user_limit": 1, "enabled": True},
    ]
    state["reward_shop_claims"] = {"x": {"user_id": "1", "item_id": 10}}
    monkeypatch.setattr(s, "read_db_sections", lambda _: copy.deepcopy(state))
    assert s.user_hub(SimpleNamespace(user_id=1))["available"] == []


def test_wallet_reports_scheduled_and_reserved(state):
    from core.domain import create_discount
    from core.utils import utc_iso, utc_now
    from modules.reward_wallet import wallet_items

    c = create_discount(state, 20, assigned_to=1, code="FUTURE")
    c["starts_at"] = utc_iso(utc_now() + timedelta(days=7))
    assert wallet_items(state, 1)[0]["status"] == "scheduled"
    c["starts_at"] = None
    c["reserved_order_id"] = "x"
    assert wallet_items(state, 1)[0]["status"] == "reserved"


def test_shared_executor_has_global_admission_limit():
    import threading

    from core.async_runtime import BlockingCapacityExhausted, _DaemonExecutor

    unblock = threading.Event()
    executor = _DaemonExecutor(2)
    try:
        executor.submit(lambda: unblock.wait(1))
        executor.submit(lambda: unblock.wait(1))
        with pytest.raises(BlockingCapacityExhausted):
            executor.submit(lambda: None)
        assert executor.snapshot()["outstanding"] == 2
        executor.shutdown(wait=False, cancel_futures=True)
    finally:
        unblock.set()
        executor.join_bounded(2)


def test_reward_claim_start_limits_and_transactional_delivery(state, canonical_store, monkeypatch):
    from core.db import load_db, with_db
    from core.domain import add_points
    from core.utils import utc_iso, utc_now
    from services.reward_claims import available_rewards, claim_reward

    item = {
        "id": 987,
        "name": "test",
        "type": "vip_days",
        "value": 7,
        "points": 25,
        "stock": 1,
        "per_user_limit": 1,
        "starts_at": utc_iso(utc_now() + timedelta(days=1)),
    }
    with_db(lambda db: db["settings"].update(rewardItems=[item]))
    assert with_db(lambda db: claim_reward(db, 1, 987, "test"))[0] == "error"
    with_db(lambda db: next(r for r in db["settings"]["rewardItems"] if r["id"] == 987).pop("starts_at"))
    with_db(lambda db: add_points(db, 1, 100, "seed"))
    import services.reward_claims as svc

    with monkeypatch.context() as scoped:
        scoped.setattr(svc, "activate_vip", lambda *a, **k: (_ for _ in ()).throw(ValueError("provider")))
        with pytest.raises(ValueError):
            with_db(lambda db: claim_reward(db, 1, 987, "fail"))
    assert load_db()["user_points"]["1"] == 100 and not load_db()["reward_shop_claims"]
    assert with_db(lambda db: claim_reward(db, 1, 987, "ok"))[0] == "delivered"
    assert load_db()["user_points"]["1"] == 75
    assert 987 not in {r["id"] for r in available_rewards(load_db(), 1)} and 987 not in {
        r["id"] for r in available_rewards(load_db(), 2)
    }


def test_refund_reverses_only_purchase_and_preserves_independent_vip(state, canonical_store):
    from core.db import load_db, with_db
    from core.domain import activate_vip, add_points
    from core.utils import parse_dt, utc_now
    from modules.economic_refunds import outstanding_point_debt, record_order_refund

    with_db(lambda db: db["vip_orders"].append({"order_id": "p", "user_id": "1", "status": "approved"}))
    with_db(lambda db: activate_vip(db, 1, 30, source_order_id="p"))
    with_db(lambda db: activate_vip(db, 1, 7, source_order_id="manual-independent"))
    with_db(lambda db: add_points(db, 1, 100, "vip_purchase:p", source_event="vip_purchase:p"))
    with_db(lambda db: add_points(db, 1, -80, "spent"))
    with_db(lambda db: record_order_refund(db, "p", "full", OWNER))
    expiry = parse_dt(load_db()["vip_users"]["1"]["expires_at"])
    assert 6.99 < (expiry - utc_now()).total_seconds() / 86400 < 7.01
    assert load_db()["user_points"]["1"] == 0 and outstanding_point_debt(load_db(), 1) == 80
    with_db(lambda db: record_order_refund(db, "p", "full", OWNER))
    with_db(lambda db: add_points(db, 1, 100, "future", source_event="future"))
    with_db(lambda db: add_points(db, 1, 100, "future", source_event="future"))
    assert load_db()["user_points"]["1"] == 20 and outstanding_point_debt(load_db(), 1) == 0
    assert not load_db()["vip_orders"][0]["refund_review_required"]


def test_refund_missing_evidence_is_reviewed_without_guessing(state, canonical_store):
    from core.db import load_db, with_db
    from core.utils import utc_iso, utc_now
    from modules.economic_refunds import record_order_refund

    expiry = utc_iso(utc_now() + timedelta(days=60))
    with_db(lambda db: db["vip_users"].update({"1": {"status": "active", "expires_at": expiry}}))
    with_db(lambda db: db["vip_orders"].append({"order_id": "old", "user_id": "1", "status": "approved"}))
    with_db(lambda db: record_order_refund(db, "old", "full", OWNER))
    assert load_db()["vip_users"]["1"]["expires_at"] == expiry
    assert load_db()["vip_orders"][0]["refund_review_required"]


def test_normalized_refund_commits_order_membership_and_ledger_together(state, canonical_store, monkeypatch):
    import json

    from core.db import load_db, with_db
    from core.domain import record_vip_purchase_rewards
    from core.storage.engine import DatabaseEngine
    from core.utils import utc_iso, utc_now
    from modules.economic_refunds import record_order_refund
    from repositories.v2.commerce import CommerceRepository

    engine = DatabaseEngine(database_url="", sqlite_path=canonical_store.path)
    engine.ensure_schema()
    repo = CommerceRepository(engine)
    original_get = CommerceRepository.get
    monkeypatch.setattr(CommerceRepository, "get", lambda self, oid: original_get(repo, oid))
    start = utc_now()
    end = start + timedelta(days=30)
    order = repo.create_order(
        1,
        {
            "id": "normalized",
            "status": "approved",
            "amount_toman": 150000,
            "vip_grant": {
                "starts_at": utc_iso(start),
                "expires_at": utc_iso(end),
                "seconds": 30 * 86400,
                "source_order_id": "normalized",
            },
        },
    )
    with engine.transaction() as cursor:
        cursor.execute(
            "INSERT INTO v8_vip_entitlements(user_id,order_id,status,starts_at,expires_at,updated_at,payload) VALUES(?,?,?,?,?,?,?)",
            (
                "1",
                "normalized",
                "active",
                utc_iso(start),
                utc_iso(end),
                utc_iso(start),
                json.dumps({"status": "active", "expires_at": utc_iso(end)}),
            ),
        )
    with_db(lambda db: record_vip_purchase_rewards(db, order))
    with_db(lambda db: record_order_refund(db, "normalized", "full", OWNER))
    assert original_get(repo, "normalized")["refund_status"] == "full"
    assert load_db()["user_points"]["1"] == 0 and not load_db()["vip_orders"]
    with engine.transaction(read_only=True) as cursor:
        assert (
            cursor.execute("SELECT status FROM v8_vip_entitlements WHERE user_id=?", ("1",)).fetchone()["status"]
            == "expired"
        )
    engine.close()


def test_coupon_partial_then_full_restores_only_one_use(state):
    from core.domain import create_discount
    from modules.discount_campaigns import settle_discount_for_order

    item = create_discount(state, 10, code="TWOREFUND")
    item.update(
        scope="public",
        used_count=2,
        used_by=["1", "2"],
        consumed_order_ids=["p", "other"],
        restore_on_full_refund=True,
        restore_on_partial_refund=True,
    )
    order = {"order_id": "p", "user_id": "1", "coupon": "TWOREFUND"}
    settle_discount_for_order(state, order, "refunded", refund_type="partial")
    settle_discount_for_order(state, order, "refunded", refund_type="full")
    assert item["used_count"] == 1 and item["used_by"] == ["2"]


def test_mission_random_bonus_is_delivered_and_edit_failure_is_atomic(state, monkeypatch):
    import core.domain as d
    from core.domain import complete_mission
    from modules.missions import create_mission, update_mission

    m = create_mission(state, title="bonus", reward=25, event="manual", random_bonus_max=5)
    m["prize"] = {"points": 25, "vip_days": 0, "coupon_percent": 0}
    monkeypatch.setattr(d.secrets, "randbelow", lambda size: 5)
    assert complete_mission(state, 1, m) and state["user_points"]["1"] == 30
    original = copy.deepcopy(m)
    with pytest.raises(ValueError):
        update_mission(state, m["id"], title="changed", reward=-1)
    assert m == original


def test_unrelated_writer_before_commit_invalidates_cache(state, canonical_store, monkeypatch):
    import core.db as storage
    from core.domain import add_points

    original = storage._commit_sections_optimistic
    done = False

    def commit(store, **kwargs):
        nonlocal done
        if not done:
            done = True
            before = store._read()
            after = copy.deepcopy(before)
            after["admin_logs"].append({"action": "external"})
            original(store, before=before, after=after, changed=storage._changed_sections(before, after))
        return original(store, **kwargs)

    monkeypatch.setattr(storage, "_commit_sections_optimistic", commit)
    storage.with_db(lambda db: add_points(db, 1, 10, "A"))
    assert storage.load_db()["admin_logs"] == [{"action": "external"}]


def test_native_reward_action_ignores_forged_user_cost_and_value(state, canonical_store):
    from core.db import load_db, with_db
    from core.domain import add_points
    from services.actions_v2.rewards import reward_claim

    with_db(
        lambda db: db["settings"].update(
            rewardItems=[{"id": 888, "type": "points", "name": "server", "value": 5, "points": 25, "stock": 1}]
        )
    )
    with_db(lambda db: add_points(db, 1, 100, "seed"))
    ctx = SimpleNamespace(
        user_id="1",
        request_id="safe-request",
        payload={"reward_id": 888, "user_id": "2", "cost": 0, "value": 1000000, "vip_days": 3650},
    )
    reward_claim(ctx)
    assert load_db()["user_points"]["1"] == 80 and load_db()["user_points"].get("2", 0) == 0
    with pytest.raises(ValueError):
        reward_claim(SimpleNamespace(user_id="2", request_id="other-request", payload={"reward_id": 888}))


def test_parallel_refund_is_idempotent_and_failed_commit_rolls_back(state, canonical_store, monkeypatch):
    import core.db as storage
    from core.domain import activate_vip, add_points
    from modules.economic_refunds import record_order_refund

    storage.with_db(lambda db: db["vip_orders"].append({"order_id": "race", "user_id": "1", "status": "approved"}))
    storage.with_db(lambda db: activate_vip(db, 1, 30, source_order_id="race"))
    storage.with_db(lambda db: add_points(db, 1, 100, "vip_purchase:race", source_event="vip_purchase:race"))
    with monkeypatch.context() as scoped:
        scoped.setattr(
            storage, "_commit_sections_optimistic", lambda *a, **k: (_ for _ in ()).throw(ValueError("fail"))
        )
        with pytest.raises(ValueError):
            storage.with_db(lambda db: record_order_refund(db, "race", "full", OWNER))
    assert storage.load_db()["user_points"]["1"] == 100 and not storage.load_db()["vip_orders"][0].get("refund_status")
    with ThreadPoolExecutor(max_workers=4) as pool:
        list(pool.map(lambda _: storage.with_db(lambda db: record_order_refund(db, "race", "full", OWNER)), range(4)))
    assert storage.load_db()["user_points"]["1"] == 0
    assert sum(e["kind"] == "order_refund" for e in storage.load_db()["economic_events"].values()) == 1


def test_actual_two_event_loops_share_global_executor_capacity(monkeypatch):
    import threading

    from core import async_runtime as runtime

    executor = runtime._DaemonExecutor(1)
    entered = threading.Event()
    release = threading.Event()
    monkeypatch.setattr(runtime, "_EXECUTOR", executor)

    def work():
        entered.set()
        release.wait(2)
        return "A"

    def first_loop():
        return asyncio.run(runtime.run_blocking(work, timeout=3, acquire_timeout=0.3))

    thread = threading.Thread(target=first_loop)
    thread.start()
    try:
        assert entered.wait(1)

        async def other():
            return await runtime.run_blocking(lambda: "B", timeout=1, acquire_timeout=0.06)

        with pytest.raises(TimeoutError):
            asyncio.run(other())
        assert executor.snapshot()["outstanding"] == 1
    finally:
        release.set()
        thread.join(3)
        executor.shutdown(wait=False, cancel_futures=True)
        executor.join_bounded(2)


def test_real_hub_navigation_claim_and_clipboard_fallback():
    import os
    import shutil
    import subprocess
    from pathlib import Path

    node = os.environ.get("CODEX_PRIMARY_RUNTIME_NODE") or shutil.which("node")
    assert node
    result = subprocess.run(
        [node, str(Path(__file__).with_name("miniapp_hub.mjs"))], capture_output=True, text=True, timeout=30
    )
    assert result.returncode == 0, result.stderr
    assert "9 scenarios passed" in result.stdout


@pytest.mark.parametrize("buyer_count", [2, 3])
def test_refund_uses_remaining_referral_eligibility_not_just_last_payment(state, canonical_store, buyer_count):
    from core.db import load_db, with_db
    from core.domain import activate_vip, record_referral_purchase
    from core.utils import parse_dt, utc_now
    from modules.economic_refunds import record_order_refund
    from modules.referral_milestones import claim_milestone, save_milestone

    def setup(db):
        for n in range(2, 2 + buyer_count):
            db["users"][str(n)] = {"id": n, "referred_by": "1"}
            db["vip_orders"].append({"order_id": f"p{n}", "user_id": str(n), "status": "approved", "price": 150000})
            activate_vip(db, n, 30, source_order_id=f"p{n}")
            record_referral_purchase(db, n, f"p{n}")
        save_milestone(
            db,
            OWNER,
            {
                "title": "2 buyers",
                "trigger_type": "referrals_purchased",
                "required_count": 2,
                "reward_type": "points",
                "reward_value": 50,
            },
        )
        mid = next(iter(db["referral_milestones"]))
        claim_milestone(db, 1, mid)
        activate_vip(db, 1, 7, source_order_id="independent")

    with_db(setup)
    before = load_db()["vip_users"]["1"]["expires_at"]
    with_db(lambda db: record_order_refund(db, "p3", "full", OWNER))
    if buyer_count == 2:
        assert load_db()["user_points"]["1"] == 0
        assert 6.99 < (parse_dt(load_db()["vip_users"]["1"]["expires_at"]) - utc_now()).total_seconds() / 86400 < 7.01
    else:
        assert load_db()["user_points"]["1"] == 50 and load_db()["vip_users"]["1"]["expires_at"] == before


@pytest.mark.asyncio
async def test_english_point_screen_has_localized_history_and_navigation(state, monkeypatch):
    from unittest.mock import AsyncMock

    import bot_runtime.account_support as account
    from core.domain import add_points

    add_points(state, 1, 10, "vip_purchase:p", source_event="p")
    monkeypatch.setattr(account, "async_snapshot", AsyncMock(return_value=state))
    monkeypatch.setattr(account, "_language_for_user", lambda uid: "en")
    edit = AsyncMock()
    monkeypatch.setattr(account, "edit", edit, raising=False)
    query = SimpleNamespace(data="u_score:0", from_user=SimpleNamespace(id=1), answer=AsyncMock())
    await account.u_score(SimpleNamespace(callback_query=query), SimpleNamespace())
    text = edit.await_args.args[1]
    assert "Recorded earnings" in text and "Balance" in text and "VIP purchase" in text
    assert "برنز" not in text and "مصرف" not in text


@pytest.mark.parametrize("redeemed", [False, True])
def test_refunded_gift_cannot_be_redeemed_or_retain_sourced_vip(state, canonical_store, redeemed):
    from core.db import load_db, with_db
    from modules.economic_refunds import record_order_refund
    from modules.vip_gifts import create_gift, redeem_gift

    def setup(db):
        gift = create_gift(db, 1, 1, recipient=2)
        row = db["vip_gifts"][gift["gift_id"]]
        row.update(status="paid", order_id="gift-order")
        db["vip_orders"].append(
            {"order_id": "gift-order", "user_id": "1", "status": "approved", "gift_id": gift["gift_id"]}
        )
        if redeemed:
            redeem_gift(db, 2, gift["gift_token"])
        return gift

    gift = with_db(setup)
    with_db(lambda db: record_order_refund(db, "gift-order", "full", OWNER))
    with pytest.raises(ValueError):
        with_db(lambda db: redeem_gift(db, 2, gift["gift_token"]))
    if redeemed:
        assert load_db()["vip_users"]["2"]["status"] == "expired"
    assert not load_db()["vip_orders"][0]["refund_review_required"]
