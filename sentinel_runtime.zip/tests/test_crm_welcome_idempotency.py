from __future__ import annotations

import copy
from datetime import timedelta

from core.db import DEFAULT_DB
from core.utils import utc_iso, utc_now
from modules.crm_automation import (
    claim_crm_automation_events,
    claim_first_entry_welcome,
    mark_crm_automation_event,
)


def _database() -> dict:
    db = copy.deepcopy(DEFAULT_DB)
    db["automation_settings"].update(
        {
            "enabled": True,
            "crm_enabled": True,
            "crm_auto_stage_enabled": False,
            "crm_welcome_enabled": True,
            "crm_quiet_hours_enabled": False,
            "crm_abandoned_checkout_enabled": False,
            "crm_churn_risk_enabled": False,
            "crm_high_value_enabled": False,
            "crm_lead_alert_enabled": False,
        }
    )
    db["users"]["123"] = {
        "id": 123,
        "first_name": "Test",
        "created_at": utc_iso(utc_now() - timedelta(minutes=5)),
        "last_seen_at": utc_iso(utc_now()),
    }
    return db


def test_hourly_crm_job_never_creates_welcome_events() -> None:
    db = _database()

    assert claim_crm_automation_events(db) == []
    assert claim_crm_automation_events(db) == []
    assert "welcome:123" not in db["crm_automation_log"]


def test_first_entry_welcome_is_claimed_only_once() -> None:
    db = _database()

    first = claim_first_entry_welcome(db, "123", is_new_user=True)
    second = claim_first_entry_welcome(db, "123", is_new_user=True)

    assert first is True
    assert second is False
    assert db["automation_contact_log"]["crm_welcome:123"]["status"] == "claimed"
    assert db["users"]["123"]["welcome_status"] == "claimed"
    assert db["users"]["123"]["entered_bot_at"]


def test_successful_first_entry_welcome_is_stored_on_user_and_contact_log() -> None:
    db = _database()
    assert claim_first_entry_welcome(db, "123", is_new_user=True) is True

    mark_crm_automation_event(db, "welcome:123", success=True)

    assert claim_first_entry_welcome(db, "123", is_new_user=True) is False
    assert claim_crm_automation_events(db) == []
    assert db["crm_automation_log"]["welcome:123"]["status"] == "sent"
    assert db["automation_contact_log"]["crm_welcome:123"]["status"] == "sent"
    assert db["users"]["123"]["welcome_sent_at"]


def test_failed_first_entry_welcome_is_never_retried_by_scheduler() -> None:
    db = _database()
    assert claim_first_entry_welcome(db, "123", is_new_user=True) is True

    mark_crm_automation_event(db, "welcome:123", success=False, detail="Forbidden")

    assert claim_first_entry_welcome(db, "123", is_new_user=True) is False
    assert claim_crm_automation_events(db) == []
    assert db["crm_automation_log"]["welcome:123"]["status"] == "dead_letter"
    marker = db["automation_contact_log"]["crm_welcome:123"]
    assert marker["status"] == "failed_no_retry"
    assert marker["automatic_retry"] is False


def test_existing_users_are_suppressed_during_upgrade() -> None:
    db = _database()

    assert claim_first_entry_welcome(db, "123", is_new_user=False) is False
    assert claim_crm_automation_events(db) == []
    marker = db["automation_contact_log"]["crm_welcome:123"]
    assert marker["status"] == "suppressed_existing_user"
    assert db["users"]["123"]["welcome_status"] == "suppressed_existing_user"


def test_legacy_welcome_log_is_backfilled_and_suppressed() -> None:
    db = _database()
    db["crm_automation_log"]["welcome:123"] = {
        "type": "welcome",
        "user_id": "123",
        "status": "retry",
        "claimed_at": utc_iso(utc_now() - timedelta(minutes=2)),
        "attempts": 4,
    }

    assert claim_first_entry_welcome(db, "123", is_new_user=False) is False
    assert claim_crm_automation_events(db) == []
    marker = db["automation_contact_log"]["crm_welcome:123"]
    assert marker["source"] == "legacy_crm_log_backfill"
    assert marker["legacy_status"] == "retry"


def test_disabled_welcome_is_consumed_on_first_entry() -> None:
    db = _database()
    db["automation_settings"]["crm_welcome_enabled"] = False

    assert claim_first_entry_welcome(db, "123", is_new_user=True) is False
    assert claim_first_entry_welcome(db, "123", is_new_user=True) is False
    assert db["automation_contact_log"]["crm_welcome:123"]["status"] == "suppressed_disabled"
