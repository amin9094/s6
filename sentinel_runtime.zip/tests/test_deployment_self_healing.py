from __future__ import annotations

import base64
import json
from datetime import UTC, datetime, timedelta
from pathlib import Path

from core import google_sheets_backup
from core.runtime_watchdog import _heartbeat_age_seconds
from core.storage.engine import DatabaseEngine
from scripts.predeploy_migrate import _retryable_predeploy_error

ROOT = Path(__file__).resolve().parents[1]


def test_railway_start_command_cannot_bypass_secure_entrypoint():
    text = (ROOT / "railway.toml").read_text(encoding="utf-8")
    assert 'startCommand = "/app/scripts/docker-entrypoint.sh python main.py"' in text
    assert 'healthcheckPath = "/readyz"' in text
    assert 'restartPolicyType = "ON_FAILURE"' in text


def test_runtime_readiness_bootstrap_and_watchdog_wiring_ship():
    text = (ROOT / "bot_runtime/runtime_jobs.py").read_text(encoding="utf-8")
    assert 'set_readiness_state("bootstrap_complete", False)' in text
    assert 'register_readiness_check("telegram_application_running"' in text
    assert 'google-sheets-delayed-bootstrap' in text
    assert 'start_runtime_watchdog(' in text
    assert 'stop_runtime_watchdog()' in text


def test_google_bootstrap_is_not_awaited_on_primary_startup():
    text = (ROOT / "bot_runtime/runtime_jobs.py").read_text(encoding="utf-8")
    post_init = text.split("async def post_init", 1)[1].split("async def error_handler", 1)[0]
    assert "await _bootstrap_google_sheets_secondary(startup_db)" not in post_init
    assert 'run_once(' in post_init and 'google_sheets_bootstrap_job' in post_init


def test_predeploy_retry_only_classifies_connectivity_failures():
    assert _retryable_predeploy_error(ConnectionError("connection refused")) is True
    assert _retryable_predeploy_error(TimeoutError("timeout")) is True
    assert _retryable_predeploy_error(RuntimeError("migration marker was not committed")) is False
    assert _retryable_predeploy_error(RuntimeError("backup checksum mismatch")) is False


def test_watchdog_reads_fresh_and_stale_heartbeat(tmp_path: Path):
    heartbeat = tmp_path / "heartbeat.json"
    heartbeat.write_text(
        json.dumps({"status": "running", "updated_at": datetime.now(UTC).isoformat()}),
        encoding="utf-8",
    )
    fresh = _heartbeat_age_seconds(heartbeat)
    assert fresh is not None and fresh < 5
    heartbeat.write_text(
        json.dumps({"status": "running", "updated_at": (datetime.now(UTC) - timedelta(minutes=10)).isoformat()}),
        encoding="utf-8",
    )
    stale = _heartbeat_age_seconds(heartbeat)
    assert stale is not None and stale > 500


def test_service_account_base64_variable_is_supported(monkeypatch):
    payload = {
        "type": "service_account",
        "project_id": "sentinelpip",
        "client_email": "sentinel-sheets@sentinelpip.iam.gserviceaccount.com",
        ("private" + "_key"): "test-only-placeholder",
    }
    encoded = base64.b64encode(json.dumps(payload).encode()).decode()
    monkeypatch.delenv("GOOGLE_SHEETS_SERVICE_ACCOUNT_JSON", raising=False)
    monkeypatch.setenv("GOOGLE_SHEETS_SERVICE_ACCOUNT_JSON_B64", encoded)
    loaded = google_sheets_backup._load_service_account()
    assert loaded and loaded["project_id"] == "sentinelpip"
    assert loaded["client_email"] == payload["client_email"]


def test_normalized_snapshot_round_trip_to_emergency_sqlite(tmp_path: Path):
    target = tmp_path / "failover.sqlite3"
    snapshot = {name: [] for name in google_sheets_backup.NORMALIZED_TABLES}
    restored = google_sheets_backup.restore_normalized_snapshot_to_sqlite(snapshot, target)
    engine = DatabaseEngine(database_url="", sqlite_path=restored)
    exported = google_sheets_backup.export_normalized_tables(engine, google_sheets_backup.NORMALIZED_TABLES)
    assert set(exported) == set(google_sheets_backup.NORMALIZED_TABLES)
    assert exported["v8_schema_migrations"] and exported["v8_schema_migrations"][0]["revision"] == __import__("core.storage.schema",fromlist=["SCHEMA_REVISION"]).SCHEMA_REVISION
    assert all(rows == [] for table, rows in exported.items() if table != "v8_schema_migrations")
    engine.close()


def test_normalized_failover_has_guarded_reconcile_path():
    engine_text = (ROOT / "core/storage/engine.py").read_text(encoding="utf-8")
    backup_text = (ROOT / "core/google_sheets_backup.py").read_text(encoding="utf-8")
    assert "def reconcile_google_failover" in engine_text
    assert 'status": "conflict"' in engine_text
    assert "restore_normalized_snapshot_to_engine" in engine_text
    assert "def restore_normalized_snapshot_to_engine" in backup_text
    assert "TRUNCATE TABLE" in backup_text and "RESTART IDENTITY CASCADE" in backup_text


def test_normalized_google_outbox_is_thread_safe_and_generation_aware(tmp_path: Path, monkeypatch):
    import concurrent.futures

    outbox = tmp_path / "normalized-outbox.json"
    monkeypatch.setattr(google_sheets_backup, "_normalized_pending_path", lambda: outbox)
    table = "v8_signals"
    writes = 80
    with concurrent.futures.ThreadPoolExecutor(max_workers=12) as executor:
        list(executor.map(lambda _: google_sheets_backup.mark_normalized_dirty([table]), range(writes)))
    state = google_sheets_backup._read_normalized_pending_state()
    assert state[table] == writes
    assert google_sheets_backup.normalized_pending_tables() == {table}

    captured = google_sheets_backup._capture_normalized_generations([table])
    google_sheets_backup.mark_normalized_dirty([table])
    google_sheets_backup._ack_normalized_pending([table], captured)
    # The newer write must survive acknowledgement of the older snapshot.
    assert google_sheets_backup._read_normalized_pending_state()[table] == writes + 1


def test_legacy_google_outbox_is_thread_safe_and_generation_aware(tmp_path: Path, monkeypatch):
    import concurrent.futures

    outbox = tmp_path / "legacy-outbox.json"
    monkeypatch.setattr(google_sheets_backup, "_pending_path", lambda: outbox)
    section = "users"
    writes = 80
    with concurrent.futures.ThreadPoolExecutor(max_workers=12) as executor:
        list(executor.map(lambda _: google_sheets_backup.mark_pending_sections([section]), range(writes)))
    state = google_sheets_backup._read_pending_state()
    assert state[section] == writes

    captured = google_sheets_backup._capture_pending_generations([section])
    google_sheets_backup.mark_pending_sections([section])
    google_sheets_backup._ack_pending_generations(captured)
    assert google_sheets_backup._read_pending_state()[section] == writes + 1


def test_google_mirror_without_credentials_merges_existing_pending_sections(tmp_path: Path, monkeypatch):
    outbox = tmp_path / "legacy-outbox.json"
    monkeypatch.setattr(google_sheets_backup, "_pending_path", lambda: outbox)

    class Config:
        enabled = True
        service_account = None

    monkeypatch.setattr(google_sheets_backup, "config", lambda: Config())
    google_sheets_backup.mark_pending_sections(["users"])

    result = google_sheets_backup.mirror_database_change(
        {"users": {}, "vip_users": {}},
        ["vip_users"],
    )

    assert result["configured"] is False
    assert google_sheets_backup.pending_sections() == {"users", "vip_users"}
    state = google_sheets_backup._read_pending_state()
    assert state["users"] == 1
    assert state["vip_users"] == 1

    # Repeated worker retries while credentials are absent must not fabricate
    # extra mutation generations.
    google_sheets_backup.mirror_database_change(
        {"users": {}, "vip_users": {}},
        ["users", "vip_users"],
    )
    assert google_sheets_backup._read_pending_state() == state


def test_primary_google_mirror_only_queues_and_never_calls_network(monkeypatch):
    from core import db as db_module

    calls: list[tuple[str, ...]] = []

    class Config:
        enabled = True

    class Backup:
        @staticmethod
        def config():
            return Config()

        @staticmethod
        def mark_pending_sections(sections):
            calls.append(tuple(sections))

        @staticmethod
        def mirror_database_change(*args, **kwargs):
            raise AssertionError("primary request path must not call Google Sheets")

    monkeypatch.setattr(db_module, "_google_backup_module", lambda: Backup())
    db_module._mirror_primary_to_google({"users": {}}, ["users"])
    assert calls == [("users",)]


def test_google_401_invalidates_cached_token_before_retry(monkeypatch):
    cfg = google_sheets_backup.GoogleSheetsBackupConfig(
        enabled=True,
        spreadsheet_id="sheet-id",
        service_account={"client_email": "test@example.com", "private_key": "unused"},
        write_failover=True,
        auto_reconcile=True,
        projection_enabled=True,
        timeout_seconds=2.0,
        max_retries=1,
    )
    client = google_sheets_backup._GoogleSheetsClient(cfg)
    token_calls: list[bool] = []
    invalidations: list[bool] = []

    def fake_token(*, force=False):
        token_calls.append(force)
        return "fresh" if force else "stale"

    monkeypatch.setattr(client, "_access_token", fake_token)
    monkeypatch.setattr(client, "_invalidate_token", lambda: invalidations.append(True))

    class Response:
        def __init__(self, status_code, payload):
            self.status_code = status_code
            self._payload = payload
            self.content = b"{}"
            self.text = "{}"

        def json(self):
            return self._payload

    responses = iter([Response(401, {"error": {"message": "expired"}}), Response(200, {"values": [["ok"]]})])

    class FakeHTTPClient:
        def __init__(self, *args, **kwargs):
            pass

        def __enter__(self):
            return self

        def __exit__(self, *args):
            return False

        def request(self, *args, **kwargs):
            return next(responses)

    monkeypatch.setattr(google_sheets_backup.httpx, "Client", FakeHTTPClient)
    payload = client.request("GET", "/values/test")
    assert payload == {"values": [["ok"]]}
    assert invalidations == [True]
    assert token_calls == [False, True]
