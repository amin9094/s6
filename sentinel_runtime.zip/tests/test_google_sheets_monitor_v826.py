from modules.google_sheets_monitor import build_google_sheets_monitor


def test_google_monitor_healthy():
    result = build_google_sheets_monitor(
        {"enabled": True, "configured": True, "pending_sections": [], "service_account_email": "bot@example.iam.gserviceaccount.com"},
        {"jobs": {"google_sheets_secondary": {"status": "ok", "last_success_at": "2026-09-25T10:00:00+00:00"}}},
    )
    assert result["health"] == "healthy"
    assert result["total_pending"] == 0


def test_google_monitor_degraded_on_queue_or_job_failure():
    result = build_google_sheets_monitor(
        {"enabled": True, "configured": True, "pending_sections": [str(i) for i in range(15)]},
        {"jobs": {"google_sheets_secondary": {"status": "failed", "consecutive_failures": 3}}},
        normalized_pending=8,
    )
    assert result["health"] == "degraded"
    assert result["total_pending"] == 23
    assert result["sync"]["consecutive_failures"] == 3


def test_google_monitor_disabled_is_not_false_alarm():
    result = build_google_sheets_monitor({"enabled": False, "configured": False}, {})
    assert result["health"] == "disabled"
