from __future__ import annotations

import itertools

import pytest

from modules.vip_order_state import (
    MANUAL_PAYMENT_METHODS,
    ORDER_APPROVED,
    ORDER_APPROVING,
    ORDER_CANCELLED,
    ORDER_EXPIRED,
    ORDER_NEEDS_RECEIPT,
    ORDER_PENDING,
    ORDER_REJECTED,
    ORDER_STATES,
    assert_manual_payment_evidence,
    assert_reviewable,
    assert_transition,
    manual_payment_evidence,
    zero_value_order_is_valid,
)

ALLOWED = {
    (ORDER_PENDING, ORDER_APPROVING),
    (ORDER_PENDING, ORDER_REJECTED),
    (ORDER_PENDING, ORDER_CANCELLED),
    (ORDER_PENDING, ORDER_NEEDS_RECEIPT),
    (ORDER_PENDING, ORDER_EXPIRED),
    (ORDER_APPROVING, ORDER_APPROVED),
    (ORDER_APPROVING, ORDER_PENDING),
    (ORDER_REJECTED, ORDER_PENDING),
    (ORDER_CANCELLED, ORDER_PENDING),
    (ORDER_NEEDS_RECEIPT, ORDER_PENDING),
    (ORDER_NEEDS_RECEIPT, ORDER_CANCELLED),
    (ORDER_EXPIRED, ORDER_PENDING),
}


@pytest.mark.parametrize("source,target", list(itertools.product(sorted(ORDER_STATES), repeat=2)))
def test_transition_matrix_is_strict(source: str, target: str):
    if (source, target) in ALLOWED:
        assert_transition(source, target)
    else:
        with pytest.raises(ValueError, match="ORDER_TRANSITION_INVALID"):
            assert_transition(source, target)


@pytest.mark.parametrize("method", sorted(MANUAL_PAYMENT_METHODS))
@pytest.mark.parametrize("amount", [1, 10, 999_999, 10_000_000])
def test_every_payable_manual_method_requires_receipt(method: str, amount: int):
    order = {"payment_method": method, "amount_toman": amount, "receipt_id": ""}
    evidence = manual_payment_evidence(order)
    assert evidence.receipt_required is True
    assert evidence.valid is False
    with pytest.raises(ValueError, match="RECEIPT_REQUIRED"):
        assert_manual_payment_evidence(order)
    order["receipt_id"] = "R-1"
    assert assert_manual_payment_evidence(order).valid is True


@pytest.mark.parametrize("method", ["", "crypto", "cash", "bank", "USDC"])
def test_unknown_payment_methods_fail_closed(method: str):
    with pytest.raises(ValueError, match="PAYMENT_METHOD_INVALID"):
        assert_manual_payment_evidence({"payment_method": method, "amount_toman": 1, "receipt_id": "R"})


@pytest.mark.parametrize(
    "order,expected",
    [
        ({"payment_method": "card", "amount_toman": 0, "base_price": 0}, True),
        ({"payment_method": "usdt", "amount_toman": 0, "base_price": 0}, True),
        ({"payment_method": "card", "amount_toman": 0, "base_price": 100, "discount_amount": 100, "coupon": "FREE"}, True),
        ({"payment_method": "card", "amount_toman": 0, "base_price": 100, "discount_amount": 99, "coupon": "FREE"}, False),
        ({"payment_method": "card", "amount_toman": 0, "base_price": 100, "discount_amount": 100, "coupon": ""}, False),
        ({"payment_method": "card", "amount_toman": 0, "base_price": 100}, False),
    ],
)
def test_zero_value_orders_are_not_arbitrarily_approvable(order, expected):
    assert zero_value_order_is_valid(order) is expected
    if expected:
        assert assert_manual_payment_evidence(order).valid
    else:
        with pytest.raises(ValueError, match="ZERO_VALUE_ORDER_INVALID"):
            assert_manual_payment_evidence(order)


@pytest.mark.parametrize("status", sorted(ORDER_STATES))
def test_only_pending_orders_are_reviewable(status: str):
    order = {"status": status, "payment_method": "card", "amount_toman": 100, "receipt_id": "R"}
    if status == ORDER_PENDING:
        assert assert_reviewable(order).valid
    else:
        with pytest.raises(ValueError, match="ORDER_NOT_PENDING"):
            assert_reviewable(order)
