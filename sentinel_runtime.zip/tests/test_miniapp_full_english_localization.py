from __future__ import annotations

import re
from pathlib import Path

from services.admin_action_catalog import ADMIN_ACTION_CATALOG

ROOT = Path(__file__).resolve().parents[1]
WEB = ROOT / "webapp"
SRC = WEB / "src"
PERSIAN_RE = re.compile(r"[\u0600-\u06ff]")


def _core_text() -> str:
    return (SRC / "core.js").read_text(encoding="utf-8")


def _known_fa_ui_strings() -> set[str]:
    core = _core_text()
    prefix = core[: core.index("const UI_EN_DYNAMIC_PATTERNS")]
    mapped = set(
        re.findall(r"['\"]([^'\"]*[\u0600-\u06ff][^'\"]*)['\"]\s*:", prefix)
    )
    fa_block = core[core.index("fa: {") : core.index("},\n    en: {")]
    mapped.update(
        re.findall(r":\s*'([^']*[\u0600-\u06ff][^']*)'", fa_block)
    )
    return mapped


def test_language_preference_is_persistent_and_server_refresh_cannot_reset_it() -> None:
    core = _core_text()
    shell = (SRC / "shell-events.js").read_text(encoding="utf-8")
    assert "localStorage.getItem('sentinelLanguage')" in core
    assert "localStorage.setItem('sentinelLanguage', state.lang)" in shell
    assert "const savedLanguage = localStorage.getItem('sentinelLanguage')" in core
    assert "savedLanguage" in core and "data.user?.language" in core
    assert "document.documentElement.dir = state.lang === 'fa' ? 'rtl' : 'ltr'" in shell


def test_runtime_localizer_is_exact_not_unsafe_substring_replacement() -> None:
    core = _core_text()
    assert "UI_EN_DYNAMIC_PATTERNS" in core
    assert "UI_EN_REPLACEMENTS" not in core
    assert "translated.split(fa).join(en)" not in core
    assert "localizeUiTree(document)" in core or "localizeUiTree(document)" in (SRC / "signals-home.js").read_text(encoding="utf-8")


def test_all_plain_hardcoded_persian_ui_literals_have_an_english_mapping() -> None:
    mapped = _known_fa_ui_strings()
    missing: set[str] = set()
    literal_re = re.compile(r"(['\"`])((?:\\.|(?!\1).)*?)\1", re.S)
    for path in SRC.glob("*.js"):
        text = path.read_text(encoding="utf-8")
        for match in literal_re.finditer(text):
            value = match.group(2).replace("\\n", " ").strip()
            if not PERSIAN_RE.search(value):
                continue
            # Template markup and interpolated strings are localized after render;
            # plain literals must have an exact dictionary/I18N entry.
            if "${" in value or "<" in value or len(value) > 180:
                continue
            if value not in mapped:
                missing.add(value)
    assert not missing, f"Unmapped Persian Mini App literals: {sorted(missing)}"


def test_static_shell_accessibility_labels_are_bilingual() -> None:
    chrome = (SRC / "signals-home.js").read_text(encoding="utf-8")
    for label in (
        "User account",
        "Important signal revisions",
        "Refresh",
        "Change language",
        "Main navigation",
        "Trading journal",
        "More tools",
    ):
        assert label in chrome
    assert "state.lang === 'fa' ? 'EN' : 'FA'" in chrome


def test_admin_catalog_has_complete_english_metadata() -> None:
    assert ADMIN_ACTION_CATALOG
    fields_checked = 0
    for action_name, item in ADMIN_ACTION_CATALOG.items():
        for key in ("label_en", "description_en", "group_en", "confirmation_en"):
            value = str(item.get(key) or "")
            assert not PERSIAN_RE.search(value), f"{action_name}.{key} remains Persian: {value}"
        for field in item.get("fields") or []:
            fields_checked += 1
            label = str(field.get("label_en") or "")
            assert label and not PERSIAN_RE.search(label), f"{action_name} field label is not English"
            help_en = str(field.get("help_en") or "")
            assert not PERSIAN_RE.search(help_en), f"{action_name} field help is not English"
            placeholder_en = str(field.get("placeholder_en") or "")
            assert not PERSIAN_RE.search(placeholder_en), f"{action_name} placeholder is not English"
            for option in field.get("options") or []:
                option_en = str(option.get("label_en") or "")
                assert option_en and not PERSIAN_RE.search(option_en), (
                    f"{action_name} option is not English: {option_en}"
                )
    assert fields_checked > 20


def test_built_bundle_contains_full_english_localization_contract() -> None:
    index = (WEB / "index.html").read_text(encoding="utf-8")
    match = re.search(r'assets/(app\.[0-9a-f]{12}\.js)', index)
    assert match, "Hashed Mini App bundle is missing from index.html"
    bundle = (WEB / "assets" / match.group(1)).read_text(encoding="utf-8")
    for marker in (
        "Only tools authorized for this administrator",
        "Your subscription is active",
        "Trading and decisions",
        "Close current period and start a new one",
        "localStorage.getItem('sentinelLanguage')",
        "UI_EN_DYNAMIC_PATTERNS",
    ):
        assert marker in bundle
