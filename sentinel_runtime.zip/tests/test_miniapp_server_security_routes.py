from __future__ import annotations

import json
import os
import time
from pathlib import Path
from types import SimpleNamespace

import pytest
from fastapi.testclient import TestClient

from tests.telegram_test_stub import install as install_telegram_test_stub
install_telegram_test_stub()

from core.webapp_auth import TelegramWebAppIdentity
from core import miniapp_server as server


@pytest.fixture
def secure_settings(monkeypatch):
    object.__setattr__(server.SETTINGS, "webapp_session_secret", "A" * 64)
    object.__setattr__(server.SETTINGS, "session_key_version", "v2")
    object.__setattr__(server.SETTINGS, "session_previous_keys", ())
    object.__setattr__(server.SETTINGS, "bot_token", "123456789:" + "B" * 24)
    object.__setattr__(server.SETTINGS, "webapp_url", "https://sentinel.example/app")
    object.__setattr__(server.SETTINGS, "webapp_api_enabled", True)
    object.__setattr__(server.SETTINGS, "run_mode", "polling")
    object.__setattr__(server.SETTINGS, "webhook_path", "telegram")
    server._SESSION_SECRET_CACHE = None
    monkeypatch.delenv("RAILWAY_PROJECT_ID", raising=False)
    monkeypatch.delenv("RAILWAY_ENVIRONMENT", raising=False)
    monkeypatch.delenv("SENTINEL_ENV", raising=False)
    return server.SETTINGS


def _identity(uid: int = 42) -> TelegramWebAppIdentity:
    return TelegramWebAppIdentity(user_id=uid, username="trader", first_name="A", last_name="B", auth_date=int(time.time()), query_id="q")


def test_session_roundtrip_tamper_and_expiry(secure_settings, monkeypatch) -> None:
    token, csrf = server._session_token(_identity())
    identity, payload = server._identity_from_session(token)
    assert identity.user_id == 42
    assert payload["csrf"] == csrf
    with pytest.raises(Exception):
        server._identity_from_session(token[:-1] + ("A" if token[-1] != "A" else "B"))

    encoded, signature = token.split(".", 1)
    decoded = json.loads(server._unb64(encoded))
    decoded["exp"] = int(time.time()) - 1
    expired_encoded = server._b64(json.dumps(decoded, separators=(",", ":")).encode())
    key = server._session_secret()
    import hashlib, hmac
    expired_signature = server._b64(hmac.new(key, expired_encoded.encode(), hashlib.sha256).digest())
    with pytest.raises(Exception):
        server._identity_from_session(f"{expired_encoded}.{expired_signature}")


def test_keyring_rejects_weak_reused_and_production_missing(secure_settings, monkeypatch) -> None:
    object.__setattr__(server.SETTINGS, "webapp_session_secret", "short")
    server._SESSION_SECRET_CACHE = None
    with pytest.raises(RuntimeError):
        server._session_keyring()
    object.__setattr__(server.SETTINGS, "webapp_session_secret", server.SETTINGS.bot_token)
    with pytest.raises(RuntimeError):
        server._session_keyring()
    object.__setattr__(server.SETTINGS, "webapp_session_secret", "")
    monkeypatch.setenv("RAILWAY_PROJECT_ID", "project")
    with pytest.raises(RuntimeError):
        server._session_keyring()


def test_static_path_blocks_traversal_and_serves_spa(secure_settings, tmp_path, monkeypatch) -> None:
    root = tmp_path / "webapp"
    root.mkdir()
    (root / "index.html").write_text("ok")
    (root / "app.js").write_text("js")
    monkeypatch.setattr(server, "_WEBAPP_ROOT", root.resolve())
    assert server._static_path("").name == "index.html"
    assert server._static_path("dashboard").name == "index.html"
    assert server._static_path("app.js").name == "app.js"
    assert server._static_path("../secret") is None
    assert server._static_path("%252e%252e/secret") is None
    assert server._static_path("missing.js") is None


def test_origins_request_id_error_payload_and_json(secure_settings, monkeypatch) -> None:
    monkeypatch.setenv("WEBAPP_ALLOWED_ORIGINS", "https://admin.example,invalid")
    assert "https://sentinel.example" in server._canonical_origins()
    assert "https://admin.example" in server._canonical_origins()
    payload = server._error_payload("UNAUTHORIZED", request_id="r1", language="en")
    assert payload["error"]["code"] == "UNAUTHORIZED"
    assert payload["error"]["request_id"] == "r1"
    response = server._json({"value": 1}, request_id="r2")
    assert response.headers["X-Request-ID"] == "r2"
    assert response.headers["Cache-Control"] == "no-store"


@pytest.fixture
def app_client(secure_settings, monkeypatch, tmp_path):
    class Engine:
        def ensure_schema(self):
            return None

    import core.storage.engine as engine_module
    import core.storage.migration as migration_module
    monkeypatch.setattr(engine_module, "normalized_engine", lambda: Engine())
    monkeypatch.setattr(migration_module, "migrate_legacy_state", lambda _engine: None)
    monkeypatch.setattr(server, "_miniapp_access_allowed", lambda _uid: True)

    async def direct_run(func, *args, **kwargs):
        kwargs.pop("timeout", None)
        return func(*args, **kwargs)

    monkeypatch.setattr(server, "run_blocking", direct_run)
    monkeypatch.setattr(server, "rate_limit_allow", lambda *_a, **_k: True)
    monkeypatch.setattr(server.v2, "overview", lambda identity: {"user_id": identity.user_id, "screen": "overview"})
    monkeypatch.setattr(server.v2, "signals", lambda identity, **kwargs: {"items": [], "user_id": identity.user_id, **kwargs})
    monkeypatch.setattr(server.v2, "signal_detail", lambda identity, signal_id, **kwargs: {"id": signal_id, "user_id": identity.user_id, **kwargs})
    monkeypatch.setattr(server.v2, "risk", lambda identity, **kwargs: {"risk": True, "user_id": identity.user_id, **kwargs})
    monkeypatch.setattr(server.v2, "journal", lambda identity, **kwargs: {"items": [], **kwargs})
    monkeypatch.setattr(server.v2, "market", lambda identity, **kwargs: {"quotes": [], **kwargs})
    monkeypatch.setattr(server.v2, "orders", lambda identity, **kwargs: {"items": [], **kwargs})
    monkeypatch.setattr(server.v2, "tickets", lambda identity, **kwargs: {"items": [], **kwargs})
    monkeypatch.setattr(server.v2, "access_context", lambda identity: {"user_id": identity.user_id})
    generic_names = (
        "signal_replay_detail", "signal_share_card_detail", "feed", "expansion", "calendar",
        "order", "ticket", "track_record", "revisions", "global_search", "admin_operations",
        "admin_platform", "admin_capabilities", "admin_integration", "admin_audit_logs",
        "admin_experiments", "admin_experiment_detail", "admin_campaigns", "admin_campaign_detail",
        "admin_orders", "admin_order", "admin_tickets", "admin_ticket", "admin_signal_jobs",
        "admin_signal_job", "admin_signal_templates", "admin_store_signal_template",
        "admin_reset_signal_template",
    )
    for name in generic_names:
        monkeypatch.setattr(
            server.v2,
            name,
            lambda identity, *args, _name=name, **kwargs: {
                "route": _name, "user_id": identity.user_id, "args": list(args), "kwargs": kwargs
            },
        )
    monkeypatch.setattr(server.v2, "admin_store_signal_template", lambda identity, side, payload, **kwargs: {"route": "admin_store_signal_template", "side": side, "size": len(payload)})
    monkeypatch.setattr(server.v2, "admin_reset_signal_template", lambda identity, side: {"route": "admin_reset_signal_template", "side": side})
    monkeypatch.setattr(server, "handle_miniapp_action_for_identity", lambda identity, payload: {"action": payload["action"], "data": payload.get("payload", {}), "request_id": payload.get("request_id", "")})

    async def no_sync(*_args, **_kwargs):
        return None
    monkeypatch.setattr(server, "_after_action_telegram_sync", no_sync)

    app = server.create_app()
    token, csrf = server._session_token(_identity())
    with TestClient(app) as client:
        client.cookies.set(server._SESSION_COOKIE, token)
        yield client, csrf


def test_health_security_headers_and_auth_session(app_client, monkeypatch) -> None:
    client, csrf = app_client
    import core.observability as obs
    monkeypatch.setattr(obs, "liveness_snapshot", lambda: {"alive": True})
    monkeypatch.setattr(obs, "readiness_snapshot", lambda: {"ready": True})
    response = client.get("/healthz", headers={"X-Request-ID": "valid-request_1"})
    assert response.status_code == 200
    assert response.json()["alive"] is True
    assert response.headers["X-Content-Type-Options"] == "nosniff"
    assert response.headers["X-Request-ID"] == "valid-request_1"
    ready = client.get("/readyz")
    assert ready.status_code == 200
    session = client.get("/api/v1/auth/session")
    assert session.status_code == 200
    assert session.json()["data"]["user_id"] == 42
    token = client.cookies.get(server._SESSION_COOKIE)
    client.cookies.delete(server._SESSION_COOKIE)
    unauthorized = client.get("/api/v1/auth/session")
    assert unauthorized.status_code == 401
    if token:
        client.cookies.set(server._SESSION_COOKIE, token)


def test_authenticated_read_routes_and_query_contracts(app_client) -> None:
    client, _csrf = app_client
    assert client.get("/api/v1/overview").json()["data"]["screen"] == "overview"
    signals = client.get("/api/v1/signals?limit=10&market=crypto&live=true")
    assert signals.status_code == 200
    assert signals.json()["data"]["market"] == "crypto"
    detail = client.get("/api/v1/signals/sig-1?live=true")
    assert detail.json()["data"]["id"] == "sig-1"
    assert client.get("/api/v1/risk").status_code == 200
    assert client.get("/api/v1/journal?limit=5").status_code == 200
    assert client.get("/api/v1/market?live=true").status_code == 200
    assert client.get("/api/v1/orders?status=pending").status_code == 200
    assert client.get("/api/v1/tickets?status=open").status_code == 200


def test_csrf_same_origin_and_action_idempotency(app_client) -> None:
    client, csrf = app_client
    missing = client.post("/api/v1/actions/watchlist_toggle", json={"payload": {"symbol": "BTCUSD"}, "request_id": "req-1"})
    assert missing.status_code == 403
    bad_origin = client.post(
        "/api/v1/actions/watchlist_toggle",
        json={"payload": {"symbol": "BTCUSD"}, "request_id": "req-1"},
        headers={"X-CSRF-Token": csrf, "Origin": "https://evil.example"},
    )
    assert bad_origin.status_code == 403
    ok = client.post(
        "/api/v1/actions/watchlist_toggle",
        json={"payload": {"symbol": "BTCUSD"}},
        headers={"X-CSRF-Token": csrf, "Idempotency-Key": "req-1", "Origin": "https://sentinel.example"},
    )
    assert ok.status_code == 200
    assert ok.json()["data"]["action"] == "watchlist_toggle"
    assert ok.json()["data"]["request_id"] == "req-1"


def test_metrics_auth_kill_switch_and_unknown_routes(app_client, monkeypatch) -> None:
    client, _csrf = app_client
    monkeypatch.setenv("METRICS_TOKEN", "metrics-secret")
    import core.observability as obs
    monkeypatch.setattr(obs, "prometheus_text", lambda: "metric 1\n")
    assert client.get("/metrics").status_code == 403
    metrics = client.get("/metrics", headers={"Authorization": "Bearer metrics-secret"})
    assert metrics.status_code == 200 and "metric 1" in metrics.text
    assert client.get("/api/v1/not-real").status_code == 404
    object.__setattr__(server.SETTINGS, "webapp_api_enabled", False)
    assert client.get("/api/v1/overview").status_code == 404
    assert client.get("/health").status_code == 200


def test_complete_user_and_admin_read_route_matrix(app_client, monkeypatch) -> None:
    client, _csrf = app_client
    import services.live_market_service as live_market
    monkeypatch.setattr(live_market, "live_quote_snapshot", lambda symbol, force=True: {"symbol": symbol, "price": 1.2, "force": force})
    routes = [
        "/api/v1/signals/s1/replay", "/api/v1/signals/s1/share-card", "/api/v1/market/quote?symbol=EURUSD",
        "/api/v1/feed?limit=12", "/api/v1/expansion", "/api/v1/calendar?limit=5&currency=USD&impact=high&q=cpi",
        "/api/v1/orders/o1", "/api/v1/tickets/t1", "/api/v1/track-record?symbol=XAUUSD&market=forex",
        "/api/v1/revisions?signal_id=s1", "/api/v1/search?q=gold",
        "/api/v1/admin/operations", "/api/v1/admin/platform", "/api/v1/admin/capabilities",
        "/api/v1/admin/integration", "/api/v1/admin/audit?q=approve&action=payment",
        "/api/v1/admin/experiments", "/api/v1/admin/experiments/3", "/api/v1/admin/campaigns",
        "/api/v1/admin/campaigns/c1", "/api/v1/admin/orders?status=pending", "/api/v1/admin/orders/o1",
        "/api/v1/admin/tickets?priority=high&overdue_only=true", "/api/v1/admin/tickets/t1",
        "/api/v1/admin/signal-jobs?status=queued", "/api/v1/admin/signal-jobs/j1",
        "/api/v1/admin/signal-templates",
    ]
    for route in routes:
        response = client.get(route)
        assert response.status_code == 200, (route, response.text)
    quote = client.get("/api/v1/market/quote?symbol=EURUSD").json()["data"]
    assert quote["symbol"] == "EURUSD"


def test_template_upload_reset_logout_and_removed_apis(app_client) -> None:
    client, csrf = app_client
    headers = {"X-CSRF-Token": csrf, "Origin": "https://sentinel.example"}
    upload = client.post(
        "/api/v1/admin/signal-templates/background?side=buy",
        headers=headers,
        files={"file": ("buy.png", b"png-data", "image/png")},
    )
    assert upload.status_code == 200
    assert upload.json()["data"]["route"] == "admin_store_signal_template"
    reset = client.delete("/api/v1/admin/signal-templates/background?side=buy", headers=headers)
    assert reset.status_code == 200
    assert client.get("/api/dashboard").status_code == 410
    assert client.post("/api/action").status_code == 410
    assert client.get("/api/no-such-route").status_code == 404
    logout = client.post("/api/v1/auth/logout")
    assert logout.status_code == 200 and logout.json()["data"]["logged_out"] is True


def test_exception_mapping_request_ids_and_rate_limits(app_client, monkeypatch) -> None:
    client, csrf = app_client
    headers = {"X-CSRF-Token": csrf, "Origin": "https://sentinel.example", "Idempotency-Key": "err-1"}

    def raise_value(*_args, **_kwargs):
        raise ValueError("SIGNAL_NOT_FOUND")
    monkeypatch.setattr(server.v2, "overview", raise_value)
    response = client.get("/api/v1/overview")
    assert response.status_code == 400
    assert response.json()["error"]["code"] == "SIGNAL_NOT_FOUND"

    def raise_permission(*_args, **_kwargs):
        raise PermissionError("SYSTEM_READ_ONLY")
    monkeypatch.setattr(server, "handle_miniapp_action_for_identity", raise_permission)
    blocked = client.post("/api/v1/actions/watchlist_toggle", json={"payload": {}}, headers=headers)
    assert blocked.status_code == 403
    assert blocked.json()["error"]["code"] == "SYSTEM_READ_ONLY"

    monkeypatch.setattr(server, "rate_limit_allow", lambda *_a, **_k: False)
    limited = client.get("/api/v1/market/quote?symbol=BTCUSD")
    assert limited.status_code == 429


def test_bootstrap_resume_and_fresh_session(app_client, monkeypatch) -> None:
    client, _csrf = app_client
    monkeypatch.setattr(server, "validate_init_data", lambda *_a, **_k: _identity())
    # Existing signed cookie for the same user resumes without consuming initData again.
    resumed = client.post("/api/v1/auth/bootstrap", headers={"X-Telegram-Init-Data": "signed"})
    assert resumed.status_code == 200
    assert resumed.json()["data"]["resumed"] is True

    client.cookies.delete(server._SESSION_COOKIE)
    import core.initdata_replay as replay
    monkeypatch.setattr(replay, "consume", lambda *_a, **_k: True)
    monkeypatch.setattr(server, "rate_limit_allow", lambda *_a, **_k: True)
    fresh = client.post("/api/v1/auth/bootstrap", headers={"X-Telegram-Init-Data": "signed-new"})
    assert fresh.status_code == 200
    assert fresh.json()["data"]["user_id"] == 42
    assert fresh.cookies.get(server._SESSION_COOKIE)


def test_bootstrap_replay_rate_limit_and_disabled(app_client, monkeypatch) -> None:
    client, _csrf = app_client
    client.cookies.delete(server._SESSION_COOKIE)
    monkeypatch.setattr(server, "validate_init_data", lambda *_a, **_k: _identity())
    import core.initdata_replay as replay
    monkeypatch.setattr(replay, "consume", lambda *_a, **_k: False)
    monkeypatch.setattr(server, "rate_limit_allow", lambda *_a, **_k: True)
    replayed = client.post("/api/v1/auth/bootstrap", headers={"X-Telegram-Init-Data": "replay"})
    assert replayed.status_code == 409
    assert replayed.json()["error"]["code"] == "INIT_DATA_REPLAYED"

    monkeypatch.setattr(server, "rate_limit_allow", lambda *_a, **_k: False)
    limited = client.post("/api/v1/auth/bootstrap", headers={"X-Telegram-Init-Data": "limited"})
    assert limited.status_code == 429

    monkeypatch.setattr(server, "_miniapp_access_allowed", lambda _uid: False)
    disabled = client.post("/api/v1/auth/bootstrap", headers={"X-Telegram-Init-Data": "disabled"})
    assert disabled.status_code == 503


def test_journal_pdf_checkout_quote_and_static_assets(app_client, monkeypatch) -> None:
    client, csrf = app_client
    import services.journal_pdf_service as pdf_service
    monkeypatch.setattr(pdf_service, "build_journal_pdf", lambda *_a, **_k: b"%PDF-test")
    monkeypatch.setattr(server, "rate_limit_allow", lambda *_a, **_k: True)
    pdf = client.get("/api/v1/journal/export.pdf?lang=en&account_id=a1&status=closed")
    assert pdf.status_code == 200
    assert pdf.content.startswith(b"%PDF")
    assert "sentinel-journal-42.pdf" in pdf.headers["content-disposition"]

    quote = client.post(
        "/api/v1/checkout/quote",
        json={"plan_id": 1, "payment_method": "card"},
        headers={
            "X-CSRF-Token": csrf,
            "Origin": "https://sentinel.example",
            "Idempotency-Key": "quote-1",
        },
    )
    assert quote.status_code == 200
    assert quote.json()["data"]["action"] == "checkout_quote_create"

    no_key = client.post(
        "/api/v1/checkout/quote",
        json={"plan_id": 1},
        headers={"X-CSRF-Token": csrf, "Origin": "https://sentinel.example"},
    )
    assert no_key.status_code == 400
    root = client.get("/")
    assert root.status_code == 200
    assert "no-cache" in root.headers["cache-control"]
    asset_name = next(path.name for path in server._WEBAPP_ROOT.joinpath("assets").glob("app.*.js"))
    asset = client.get(f"/assets/{asset_name}")
    assert asset.status_code == 200
    assert "immutable" in asset.headers["cache-control"]


def test_support_attachment_upload_download_and_guards(app_client, monkeypatch) -> None:
    client, csrf = app_client
    headers = {"X-CSRF-Token": csrf, "Origin": "https://sentinel.example"}
    import core.db as db_module
    import modules.support_attachment_storage as storage
    import modules.admin_access as access

    monkeypatch.setattr(db_module, "with_db", lambda func: func({}))
    monkeypatch.setattr(
        storage,
        "store_support_attachment",
        lambda db, owner_id, payload, **kwargs: {
            "storage_id": "att-1", "owner_id": str(owner_id), "size_bytes": len(payload),
            "file_name": kwargs["file_name"], "mime_type": kwargs["mime_type"],
        },
    )
    upload = client.post(
        "/api/v1/support/attachments",
        headers=headers,
        files={"file": ("proof.png", b"image-bytes", "image/png")},
    )
    assert upload.status_code == 200
    assert upload.json()["data"]["storage_id"] == "att-1"

    row = {"storage_id": "att-1", "owner_id": "42", "file_name": "proof image.png", "mime_type": "image/png"}
    monkeypatch.setattr(db_module, "with_db_read", lambda func: func({"support_tickets": []}))
    monkeypatch.setattr(storage, "attachment_record", lambda _db, storage_id: row if storage_id == "att-1" else None)
    monkeypatch.setattr(storage, "read_support_attachment", lambda _row: b"downloaded")
    monkeypatch.setattr(access, "has_permission", lambda *_a, **_k: False)
    download = client.get("/api/v1/support/attachments/att-1")
    assert download.status_code == 200
    assert download.content == b"downloaded"
    assert "proof_image.png" in download.headers["content-disposition"]

    row["owner_id"] = "99"
    denied = client.get("/api/v1/support/attachments/att-1")
    assert denied.status_code == 404
    row["owner_id"] = "42"
    monkeypatch.setattr(storage, "read_support_attachment", lambda _row: None)
    gone = client.get("/api/v1/support/attachments/att-1")
    assert gone.status_code == 410


def test_receipt_upload_success_quota_and_cleanup(app_client, monkeypatch) -> None:
    client, csrf = app_client
    headers = {"X-CSRF-Token": csrf, "Origin": "https://sentinel.example"}
    monkeypatch.setattr(server, "rate_limit_allow", lambda *_a, **_k: True)

    deleted = []
    class Repo:
        def receipt_usage(self, user_id, since_iso=None):
            return {"count": 0, "bytes": 0, "available_bytes": 0}
        def create_receipt(self, user_id, payload):
            return {**payload, "status": "available", "created_at": "now"}
        def prune_available_receipts(self, user_id, *, keep, exclude_id):
            return [{"receipt_id": "old", "path": "/tmp/old"}]

    monkeypatch.setattr(server, "CommerceRepository", Repo)
    monkeypatch.setattr(
        server,
        "store_receipt_bytes",
        lambda db, **kwargs: {
            "receipt_id": "r1", "checksum": "abc", "mime": "image/webp",
            "size_bytes": len(kwargs["payload"]), "path": "/private/r1",
        },
    )
    monkeypatch.setattr(server, "delete_receipt_blob", lambda row: deleted.append(row.get("receipt_id")) or True)
    uploaded = client.post(
        "/api/v1/checkout/receipt",
        headers=headers,
        files={"file": ("receipt.png", b"receipt-image", "image/png")},
    )
    assert uploaded.status_code == 200
    data = uploaded.json()["data"]
    assert data["receipt_id"] == "r1"
    assert "path" not in data
    assert deleted == ["old"]

    class QuotaRepo(Repo):
        def receipt_usage(self, user_id, since_iso=None):
            return {"count": 999 if since_iso else 0, "bytes": 0, "available_bytes": 0}
    monkeypatch.setattr(server, "CommerceRepository", QuotaRepo)
    limited = client.post(
        "/api/v1/checkout/receipt",
        headers=headers,
        files={"file": ("receipt.png", b"receipt-image", "image/png")},
    )
    assert limited.status_code == 429


def test_webhook_validation_and_durable_persistence(app_client, monkeypatch) -> None:
    client, _csrf = app_client
    object.__setattr__(server.SETTINGS, "webhook_secret_token", "webhook-secret")
    object.__setattr__(server.SETTINGS, "run_mode", "webhook")
    fake_loop = SimpleNamespace(is_running=lambda: True)
    fake_app = SimpleNamespace(running=True)
    server.register_telegram_application(fake_app, fake_loop)
    import core.telegram_update_store as store
    monkeypatch.setattr(store, "persist", lambda update_id, payload: "stored")
    monkeypatch.setattr(store, "backlog", lambda: {"pending": 1})
    webhook_path = next(route.path for route in client.app.routes if getattr(route.endpoint, "__name__", "") == "telegram_webhook")
    try:
        forbidden = client.post(webhook_path, json={"update_id": 1})
        assert forbidden.status_code == 403
        invalid_type = client.post(
            webhook_path,
            content="x",
            headers={"X-Telegram-Bot-Api-Secret-Token": "webhook-secret", "Content-Type": "text/plain"},
        )
        assert invalid_type.status_code == 415
        ok = client.post(
            webhook_path,
            json={"update_id": 123, "message": {"text": "hello"}},
            headers={"X-Telegram-Bot-Api-Secret-Token": "webhook-secret"},
        )
        assert ok.status_code == 200
        assert ok.json()["duplicate"] is False
    finally:
        server.unregister_telegram_application(fake_app)


def test_signal_chart_route_streams_authorized_telegram_image(app_client, monkeypatch) -> None:
    client, _csrf = app_client
    import repositories.v2.signals as signal_repository_module

    monkeypatch.setattr(
        signal_repository_module.SignalRepository,
        "get",
        lambda self, signal_id: {
            "id": signal_id,
            "destination": "public",
            "chart_photo_file_id": "chart-file-id",
        },
    )
    monkeypatch.setattr(server.v2, "_safe_shell", lambda _identity: {"vip_active": False})
    monkeypatch.setattr(server.v2, "_visible_signal", lambda _signal, _vip: True)

    class TelegramFile:
        file_path = "charts/signal.png"

        async def download_as_bytearray(self):
            return bytearray(b"png-image-bytes")

    class Bot:
        async def get_file(self, file_id):
            assert file_id == "chart-file-id"
            return TelegramFile()

    application = SimpleNamespace(bot=Bot())
    monkeypatch.setattr(server, "_telegram_application", lambda: (application, None))

    async def direct_telegram(coro):
        return await coro

    monkeypatch.setattr(server, "_run_on_telegram_loop", direct_telegram)
    response = client.get("/api/v1/signals/sig-visual/chart")
    assert response.status_code == 200
    assert response.content == b"png-image-bytes"
    assert response.headers["content-type"].startswith("image/png")
    assert response.headers["cache-control"] == "private, max-age=120"
