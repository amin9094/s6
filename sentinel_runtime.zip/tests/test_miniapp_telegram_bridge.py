from __future__ import annotations

import asyncio
from types import SimpleNamespace

import pytest

from tests.telegram_test_stub import install as install_telegram_test_stub
install_telegram_test_stub()

from core.webapp_auth import TelegramWebAppIdentity
from core import miniapp_server as server


def _identity(uid: int = 42) -> TelegramWebAppIdentity:
    return TelegramWebAppIdentity(
        user_id=uid,
        username="tester",
        first_name="Test",
        last_name="User",
        auth_date=1,
        query_id="q",
    )


@pytest.fixture(autouse=True)
def clean_bridge():
    server.unregister_telegram_application()
    yield
    server.unregister_telegram_application()


@pytest.mark.asyncio
async def test_register_lookup_and_unregister_current_loop() -> None:
    app = SimpleNamespace(name="telegram")
    loop = asyncio.get_running_loop()
    server.register_telegram_application(app)
    assert server._telegram_application() == (app, loop)

    other = SimpleNamespace(name="other")
    server.unregister_telegram_application(other)
    assert server._telegram_application() == (app, loop)

    server.unregister_telegram_application(app)
    assert server._telegram_application() == (None, None)


@pytest.mark.asyncio
async def test_run_on_telegram_loop_executes_on_same_loop() -> None:
    app = SimpleNamespace()
    server.register_telegram_application(app, asyncio.get_running_loop())

    async def work() -> str:
        await asyncio.sleep(0)
        return "done"

    assert await server._run_on_telegram_loop(work()) == "done"


@pytest.mark.asyncio
async def test_run_on_telegram_loop_closes_when_runtime_missing() -> None:
    closed = False

    class Awaitable:
        def close(self) -> None:
            nonlocal closed
            closed = True

    assert await server._run_on_telegram_loop(Awaitable()) is None
    assert closed is True


def test_miniapp_access_allows_enabled_or_admin(monkeypatch) -> None:
    import core.db
    import modules.admin_access
    import modules.miniapp_runtime

    monkeypatch.setattr(core.db, "read_db_sections", lambda _sections: {"settings": {}})
    monkeypatch.setattr(modules.miniapp_runtime, "miniapp_enabled", lambda _db: True)
    monkeypatch.setattr(modules.admin_access, "is_any_admin", lambda _db, _uid: False)
    assert server._miniapp_access_allowed(10) is True

    monkeypatch.setattr(modules.miniapp_runtime, "miniapp_enabled", lambda _db: False)
    monkeypatch.setattr(modules.admin_access, "is_any_admin", lambda _db, uid: str(uid) == "99")
    assert server._miniapp_access_allowed(99) is True
    assert server._miniapp_access_allowed(10) is False


def test_admin_ids_merge_owner_and_delegated(monkeypatch) -> None:
    import core.db
    import modules.admin_access

    object.__setattr__(server.SETTINGS, "admin_ids", (11, 12))
    monkeypatch.setattr(core.db, "read_db_sections", lambda _sections: {})
    monkeypatch.setattr(
        modules.admin_access,
        "delegated_admins",
        lambda _db: {
            "13": {"active": True, "permissions": ["payments"]},
            "bad": {"active": True, "permissions": ["payments"]},
            "14": {"active": False, "permissions": ["payments"]},
            "15": {"active": True, "permissions": ["tickets"]},
        },
    )
    assert server._admin_ids_for("payments") == [11, 12, 13]


@pytest.mark.asyncio
async def test_after_action_without_runtime_is_noop_for_nonfinancial_action() -> None:
    await server._after_action_telegram_sync("preference_update", {"data": {}}, _identity())


@pytest.mark.asyncio
async def test_payment_approval_released_when_telegram_runtime_missing(monkeypatch) -> None:
    from repositories.v2.commerce import CommerceRepository

    calls: list[tuple[str, str, str]] = []

    def release(self, order_id, *, actor_id, error):
        calls.append((str(order_id), str(actor_id), str(error)))
        return True

    monkeypatch.setattr(CommerceRepository, "release_order_approval", release)
    result = {"data": {"result": {"order_id": "ORD-1"}}}
    with pytest.raises(RuntimeError, match="TELEGRAM_RUNTIME_UNAVAILABLE"):
        await server._after_action_telegram_sync("payment_approve", result, _identity(77))
    assert calls == [("ORD-1", "77", "telegram runtime unavailable")]
