from __future__ import annotations

import hashlib
import hmac
import json
from datetime import UTC, datetime
from pathlib import Path

import pytest

from repositories.v2.accounts import AccountRepository
from repositories.v2.mt5_connectors import MT5ConnectorRepository
from services.mt5_connector_service import ingest_snapshot, pair_connector, verify_connector_request
from services.prop_guardian_service import account_guardian_snapshot, prop_guardian_dashboard
from services.risk_coach_service import get_or_create_daily_plan, record_risk_checkin, update_daily_plan


def _account(engine):
    return AccountRepository(engine).upsert(
        "77",
        {
            "name": "Prop 10K",
            "type": "prop_challenge",
            "phase": "challenge",
            "currency": "USD",
            "balance": 10_000,
            "equity": 10_000,
            "starting_balance": 10_000,
            "rule_template_id": "prop-static-5-10",
            "default_risk_percent": 1.0,
            "max_daily_risk_percent": 2.0,
            "max_open_risk_percent": 5.0,
            "timezone": "UTC",
        },
        account_id="acct_prop",
    )


def _connected(engine):
    _account(engine)
    repo = MT5ConnectorRepository(engine)
    pairing = repo.create_pairing("77", "acct_prop")
    credentials = pair_connector(
        pairing["code"],
        {
            "platform": "MT5",
            "account_login": "12345678",
            "broker": "Demo Broker",
            "server_name": "Demo-Server",
            "account_name": "Challenge",
            "terminal_build": "5000",
            "connector_version": "1.00",
        },
        engine=engine,
    )
    connector = repo.authenticate(credentials["connector_id"], credentials["device_token"])
    return repo, credentials, connector


def test_pairing_is_one_time_and_credentials_are_not_exposed_in_public_rows(sqlite_engine):
    _account(sqlite_engine)
    repo = MT5ConnectorRepository(sqlite_engine)
    pairing = repo.create_pairing("77", "acct_prop", ttl_minutes=15)
    result = pair_connector(
        pairing["code"],
        {"platform": "MT5", "account_login": "12345678", "broker": "Broker", "server_name": "Server"},
        engine=sqlite_engine,
    )
    assert result["device_token"]
    assert result["connector_secret"]
    with pytest.raises(ValueError, match="PAIRING_CODE_INVALID"):
        pair_connector(
            pairing["code"],
            {"platform": "MT5", "account_login": "12345678", "broker": "Broker", "server_name": "Server"},
            engine=sqlite_engine,
        )
    public = repo.list_for_user("77")[0]
    assert public["account_login_masked"].startswith("12")
    assert "device_token" not in public
    assert "connector_secret" not in public
    assert public["readonly_mode"] is True


def test_hmac_request_verification_and_replay_rejection(sqlite_engine):
    repo, credentials, _connector = _connected(sqlite_engine)
    body = json.dumps({"hello": "world"}, separators=(",", ":")).encode()
    timestamp = str(int(datetime.now(UTC).timestamp()))
    nonce = "nonce-123456789012345"
    material = f"{timestamp}\n{nonce}\n{hashlib.sha256(body).hexdigest()}".encode()
    signature = hmac.new(credentials["connector_secret"].encode(), material, hashlib.sha256).hexdigest()
    verified = verify_connector_request(
        repo,
        connector_id=credentials["connector_id"],
        device_token=credentials["device_token"],
        timestamp=timestamp,
        nonce=nonce,
        signature=signature,
        body=body,
    )
    assert verified["id"] == credentials["connector_id"]
    with pytest.raises(PermissionError, match="CONNECTOR_REPLAY_DETECTED"):
        verify_connector_request(
            repo,
            connector_id=credentials["connector_id"],
            device_token=credentials["device_token"],
            timestamp=timestamp,
            nonce=nonce,
            signature=signature,
            body=body,
        )


def test_snapshot_sync_updates_account_positions_journal_and_guardian(sqlite_engine):
    repo, _credentials, connector = _connected(sqlite_engine)
    snapshot = {
        "observed_at": datetime.now(UTC).isoformat(),
        "account": {
            "login": "12345678",
            "server": "Demo-Server",
            "balance": 9900,
            "equity": 9850,
            "profit": -50,
            "currency": "USD",
            "leverage": 100,
            "margin": 250,
            "free_margin": 9600,
        },
        "positions": [
            {
                "ticket": "9001",
                "symbol": "XAUUSD",
                "side": "BUY",
                "volume": 0.10,
                "price_open": 2300,
                "price_current": 2297,
                "sl": 0,
                "tp": 2320,
                "profit": -30,
                "risk_money": 0,
            },
            {
                "ticket": "9002",
                "symbol": "EURUSD",
                "side": "SELL",
                "volume": 0.20,
                "price_open": 1.09,
                "price_current": 1.091,
                "sl": 1.095,
                "tp": 1.08,
                "profit": -20,
                "risk_money": 100,
            },
        ],
        "deals": [
            {
                "ticket": "8001",
                "position_id": "7001",
                "entry_kind": "out",
                "symbol": "GBPUSD",
                "side": "SELL",
                "volume": 0.10,
                "price": 1.275,
                "profit": 80,
                "commission": -2,
                "swap": 0,
                "fee": 0,
                "time": datetime.now(UTC).isoformat(),
            }
        ],
        "terminal": {"connector_version": "1.00", "build": "5000"},
    }
    result = ingest_snapshot(connector, snapshot, engine=sqlite_engine)
    assert result["positions"] == {"created": 2, "updated": 0, "closed": 0, "missing_stop": 1}
    assert result["deals"]["imported"] == 1
    assert result["guardian_status"] == "blocked"
    assert any(item["code"] == "OPEN_POSITION_WITHOUT_STOP" for item in result["new_alerts"])
    repeated = ingest_snapshot(connector, {**snapshot, "observed_at": datetime.now(UTC).isoformat()}, engine=sqlite_engine)
    assert repeated["new_alerts"] == []
    account = AccountRepository(sqlite_engine).get("77", "acct_prop")
    assert account["equity"] == 9850
    assert account["data_source"] == "mt5_connector"
    assert repo.latest_snapshot("acct_prop")["provider"] == "SentinelConnectorMT5"
    guardian = account_guardian_snapshot("77", "acct_prop", record=True, engine=sqlite_engine)
    assert guardian["connector"]["status"] == "online"
    assert guardian["broker_positions"]["open_count"] == 2
    assert guardian["broker_positions"]["missing_stop_count"] == 1
    assert guardian["status"] == "blocked"
    assert any(item["code"] == "OPEN_POSITION_WITHOUT_STOP" for item in guardian["alerts"])
    assert prop_guardian_dashboard("77", engine=sqlite_engine)["summary"]["connected_count"] == 1


def test_daily_plan_pretrade_gate_and_checkin(sqlite_engine):
    _account(sqlite_engine)
    plan = get_or_create_daily_plan("77", "acct_prop", engine=sqlite_engine)
    assert plan["status"] == "draft"
    plan = update_daily_plan(
        "77",
        "acct_prop",
        {"max_risk_per_trade_percent": 0.5, "minimum_rr": 2.0, "max_trades": 3},
        accept=True,
        engine=sqlite_engine,
    )
    assert plan["status"] == "accepted"
    decision = account_guardian_snapshot(
        "77",
        "acct_prop",
        candidate={"symbol": "XAUUSD", "side": "BUY", "entry": 2300, "stop": 2290, "take_profit": 2310, "risk_percent": 1.0},
        engine=sqlite_engine,
    )
    codes = {item["code"] for item in decision["hard_blocks"]}
    assert "DAILY_PLAN_TRADE_RISK_EXCEEDED" in codes
    assert "DAILY_PLAN_MINIMUM_RR_NOT_MET" in codes
    assert decision["pretrade"]["allowed"] is False
    row = record_risk_checkin(
        "77",
        {"account_id": "acct_prop", "checkin_type": "pretrade", "emotion": "calm", "confidence": 8, "followed_plan": True},
        engine=sqlite_engine,
    )
    assert row["emotion"] == "calm"


def test_connector_source_is_read_only_and_downloadable_contract():
    source = Path("webapp/downloads/SentinelConnector.mq5").read_text(encoding="utf-8")
    assert "WebRequest(" in source
    assert "OnTradeTransaction(" in source
    assert "OrderCalcProfit(" in source
    assert "QueueTradeEvent(trans);" in source
    handler = source.split("void OnTradeTransaction(", 1)[1]
    handler = handler.split("}", 1)[0]
    assert "WebRequest(" not in handler
    assert "HttpPost(" not in handler
    forbidden = ("OrderSend(", "PositionClose(", "PositionOpen(", "CTrade ", ".Buy(", ".Sell(")
    assert not any(token in source for token in forbidden)
    assert Path("webapp/downloads/Sentinel_MT5_Connector_Source.zip").is_file()
    assert Path("webapp/downloads/Sentinel_MT5_Installation_FA.txt").is_file()
