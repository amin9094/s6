from __future__ import annotations

from datetime import UTC, datetime, timedelta
from pathlib import Path

from modules import operations_governance as governance


def _status_map(result: dict) -> dict[str, str]:
    return {str(row["key"]): str(row["status"]) for row in result["checks"]}


def _details(result: dict, key: str) -> dict:
    return next(row["details"] for row in result["checks"] if row["key"] == key)


def test_empty_new_install_has_no_false_warning_or_unknown(monkeypatch) -> None:
    monkeypatch.setattr(
        governance,
        "observability_snapshot",
        lambda: {"jobs": {}, "uptime_seconds": 120},
    )
    result = governance.run_automation_checks({}, now=datetime.now(UTC))
    assert result["summary"]["warning"] == 0
    assert result["summary"]["critical"] == 0
    assert result["summary"]["unknown"] == 0
    statuses = _status_map(result)
    assert statuses["market_freshness"] == "healthy"
    assert statuses["market_outliers"] == "healthy"
    assert statuses["news_quality"] == "healthy"
    assert statuses["backup_freshness"] == "healthy"
    assert _details(result, "backup_freshness")["mode"] == "warming_up"


def test_provider_redundancy_stays_healthy_with_one_optional_offline(monkeypatch) -> None:
    now = datetime.now(UTC)
    rows = {}
    for index in range(3):
        rows[f"provider-{index}"] = {
            "provider": f"provider-{index}",
            "active": True,
            "status": "healthy",
            "last_checked_at": now.isoformat(),
            "last_symbol": "XAUUSD",
            "last_price": 2400 + index * 0.1,
        }
    rows["optional-offline"] = {
        "provider": "optional-offline",
        "active": True,
        "status": "offline",
        "last_checked_at": now.isoformat(),
        "last_symbol": "XAUUSD",
        "last_price": None,
    }
    db = {"provider_health": rows}
    monkeypatch.setattr(
        governance,
        "observability_snapshot",
        lambda: {"jobs": {}, "uptime_seconds": 3600},
    )
    result = governance.run_automation_checks(db, now=now)
    assert _status_map(result)["provider_health"] == "healthy"
    details = _details(result, "provider_health")
    assert details["offline"] == 1
    assert details["redundancy_ok"] is True
    assert _status_map(result)["market_outliers"] == "healthy"
    assert _details(result, "market_outliers")["symbols_checked"] == 1


def test_backup_freshness_uses_canonical_operational_timestamp(monkeypatch) -> None:
    now = datetime.now(UTC)
    db = {
        "operations": {"last_operational_backup_at": (now - timedelta(hours=2)).isoformat()},
    }
    monkeypatch.setattr(
        governance,
        "observability_snapshot",
        lambda: {"jobs": {}, "uptime_seconds": 3600},
    )
    result = governance.run_automation_checks(db, now=now)
    assert _status_map(result)["backup_freshness"] == "healthy"
    assert _details(result, "backup_freshness")["latest_age_hours"] == 2.0


def test_single_transient_job_failure_does_not_make_system_yellow(monkeypatch) -> None:
    now = datetime.now(UTC)
    monkeypatch.setattr(
        governance,
        "observability_snapshot",
        lambda: {
            "uptime_seconds": 3600,
            "jobs": {
                "provider_health": {
                    "status": "degraded",
                    "consecutive_failures": 1,
                    "finished_at": now.isoformat(),
                }
            },
        },
    )
    result = governance.run_automation_checks({}, now=now)
    assert _status_map(result)["job_freshness"] == "healthy"
    assert _details(result, "job_freshness")["recovering"] == 1


def test_truly_stale_job_remains_visible(monkeypatch) -> None:
    now = datetime.now(UTC)
    monkeypatch.setattr(
        governance,
        "observability_snapshot",
        lambda: {
            "uptime_seconds": 8 * 3600,
            "jobs": {
                "heartbeat": {
                    "status": "ok",
                    "consecutive_failures": 0,
                    "finished_at": (now - timedelta(minutes=20)).isoformat(),
                }
            },
        },
    )
    result = governance.run_automation_checks({}, now=now)
    assert _status_map(result)["job_freshness"] == "warning"
    assert "heartbeat" in _details(result, "job_freshness")["stale_jobs"]


def test_miniapp_loader_exact_four_seconds_and_channel_pulse_default() -> None:
    source = (Path(__file__).resolve().parents[1] / "webapp" / "src" / "core.js").read_text(encoding="utf-8")
    assert "const SPLASH_DURATION_MS = 250;" in source
    assert "splashDeadlineTimer = setTimeout(releaseAtFourSeconds, SPLASH_DURATION_MS)" in source
    assert "splashHardTimer" not in source
    assert "}, 10000)" not in source
    assert "await openMore('feed')" in source
    assert "state.resources.overview?.onboarding?.completed" in source
