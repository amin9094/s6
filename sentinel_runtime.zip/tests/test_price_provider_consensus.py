from __future__ import annotations

import asyncio
from datetime import UTC, datetime, timedelta

import pytest

from modules import prices


def quote(symbol: str, value: float, source: str, *, confidence: float = 0.8, bid=None, ask=None, stale=False, delayed=False):
    return prices.MarketQuote(
        symbol=symbol, title=symbol, price=value, source=source, updated_at=datetime.now(UTC),
        confidence=confidence, bid=bid, ask=ask, stale=stale, delayed=delayed,
    )


def test_numeric_helpers_and_provider_registry(monkeypatch) -> None:
    assert prices._valid_price("1.2") == 1.2
    for value in (0, -1, float("nan"), "bad"):
        with pytest.raises(RuntimeError):
            prices._valid_price(value)
    assert prices._optional_float("2.5") == 2.5
    assert prices._optional_float("bad") is None
    assert prices._optional_float(float("inf")) is None
    assert prices._change_percent(110, 100) == 10
    assert prices._change_percent(1, None) is None
    assert prices._change_percent(1, 0) is None
    names = prices.provider_names_for_symbols(["XAUUSD", "EURUSD", "BTCUSD", "AAPL", "?"])
    assert {"Gold-API", "Yahoo Finance", "Frankfurter/ECB", "Binance", "Coinbase Exchange"}.issubset(names)
    monkeypatch.setenv("TWELVE_DATA_API_KEY", "key")
    assert "Twelve Data" in {name for name, _ in prices._provider_attempts("EURUSD")}
    with pytest.raises(ValueError):
        prices._provider_attempts("BAD?SYMBOL")


def test_consensus_rejects_outlier_and_merges_bid_ask() -> None:
    rows = [
        quote("BTCUSD", 100.0, "a", confidence=0.7, bid=99.5, ask=100.5),
        quote("BTCUSD", 100.2, "b", confidence=0.9, bid=99.7, ask=100.7),
        quote("BTCUSD", 150.0, "outlier", confidence=1.0),
    ]
    result = prices._consensus_quote("BTCUSD", rows)
    assert result.consensus is True
    assert result.provider_count == 2
    assert result.price == pytest.approx(100.1)
    assert result.bid == pytest.approx(99.6)
    assert result.ask == pytest.approx(100.6)
    assert "outlier" not in result.source
    single = prices._consensus_quote("EURUSD", [quote("EURUSD", 1.1, "one", confidence=0.99)])
    assert single.provider_count == 1 and single.consensus is False and single.confidence == 0.82
    with pytest.raises(RuntimeError):
        prices._consensus_quote("EURUSD", [])


@pytest.mark.asyncio
async def test_provider_parsers(monkeypatch) -> None:
    async def yahoo_json(*_args, **_kwargs):
        return {"chart": {"result": [{"meta": {"regularMarketPrice": 101, "chartPreviousClose": 100, "regularMarketTime": 1_700_000_000, "marketState": "REGULAR", "bid": 100.9, "ask": 101.1}, "indicators": {"quote": [{"high": [100, 102], "low": [99, 100], "open": [100], "close": [100, 101]}]}}]}}
    monkeypatch.setattr(prices, "_get_json", yahoo_json)
    y = await prices._yahoo_quote("AAPL", "AAPL")
    assert y.price == 101 and y.high == 102 and y.low == 99 and y.market_open is True

    async def metal_json(*_args, **_kwargs): return {"price": "2400.5"}
    monkeypatch.setattr(prices, "_get_json", metal_json)
    assert (await prices._metal_quote("XAUUSD")).price == 2400.5

    async def forex_json(*_args, **_kwargs): return {"rates": {"USD": 1.08}, "date": "2026-01-02"}
    monkeypatch.setattr(prices, "_get_json", forex_json)
    fx = await prices._forex_quote("EURUSD")
    assert fx.price == 1.08 and fx.delayed

    async def binance_json(*_args, **_kwargs):
        return {"lastPrice": "60000", "closeTime": 1_700_000_000_000, "priceChangePercent": "2", "highPrice": "61000", "lowPrice": "59000", "openPrice": "59500", "bidPrice": "59999", "askPrice": "60001"}
    monkeypatch.setattr(prices, "_get_json", binance_json)
    b = await prices._binance_quote("BTCUSD")
    assert b.symbol == "BTCUSD" and b.price == 60000 and b.change_percent == 2

    async def coinbase_json(*_args, **_kwargs): return {"price": "3000", "time": "2026-01-02T01:00:00Z", "bid": "2999", "ask": "3001", "volume": "1"}
    monkeypatch.setattr(prices, "_get_json", coinbase_json)
    c = await prices._coinbase_quote("ETHUSD")
    assert c.price == 3000 and c.bid == 2999

    async def gecko_json(*_args, **_kwargs):
        return {"bitcoin": {"usd": 60000, "usd_24h_change": 1.5, "usd_24h_high": 61000, "usd_24h_low": 59000, "last_updated_at": 1_700_000_000}}
    monkeypatch.setattr(prices, "_get_json", gecko_json)
    g = await prices._coingecko_quote("BTCUSD")
    assert g.price == 60000 and g.source == "CoinGecko"

    monkeypatch.setenv("TWELVE_DATA_API_KEY", "key")
    async def twelve_json(*_args, **_kwargs): return {"price": "1.2"}
    monkeypatch.setattr(prices, "_get_json", twelve_json)
    assert (await prices._twelve_data_quote("EURUSD")).price == 1.2


@pytest.mark.asyncio
async def test_uncached_failover_consensus_and_last_known_good(monkeypatch) -> None:
    prices.clear_price_cache_for_tests()
    calls = []
    async def ok1(): calls.append("a"); return quote("EURUSD", 1.1, "a", confidence=0.8)
    async def ok2(): calls.append("b"); return quote("EURUSD", 1.1001, "b", confidence=0.9)
    async def bad(): calls.append("bad"); raise RuntimeError("down")
    monkeypatch.setattr(prices, "_provider_attempts", lambda _clean: [("a", ok1), ("bad", bad), ("b", ok2)])
    monkeypatch.setattr(prices, "load_db", lambda: {})
    monkeypatch.setattr(prices, "is_module_enabled", lambda *_a: True)
    monkeypatch.setattr(prices, "module_state", lambda *_a: {"multi_provider": True, "auto_failover": True})
    monkeypatch.setattr(prices, "select_healthy_provider", lambda _db, names: "b")
    recorded = []
    monkeypatch.setattr(prices, "with_db", lambda fn: fn({}))
    monkeypatch.setattr(prices, "record_provider_result", lambda db, provider, **kwargs: recorded.append((provider, kwargs["success"])))
    result = await prices._fetch_market_quote_uncached("EURUSD")
    assert result.consensus is True and result.provider_count == 2
    assert calls[0] == "b"
    assert ("bad", False) in recorded

    async def all_bad(): raise RuntimeError("no")
    monkeypatch.setattr(prices, "_provider_attempts", lambda _clean: [("x", all_bad)])
    prices._CACHE["EURUSD"] = (0, quote("EURUSD", 1.0, "cached", confidence=0.9))
    stale = await prices._fetch_market_quote_uncached("EURUSD")
    assert stale.stale and stale.delayed and stale.confidence <= 0.35
    prices._CACHE.clear()
    with pytest.raises(RuntimeError, match="همه منابع"):
        await prices._fetch_market_quote_uncached("EURUSD")


@pytest.mark.asyncio
async def test_public_fetch_cache_shared_and_inflight(monkeypatch) -> None:
    prices.clear_price_cache_for_tests()
    row = quote("BTCUSD", 60000, "provider", confidence=0.9)
    calls = 0
    async def uncached(_clean):
        nonlocal calls
        calls += 1
        await asyncio.sleep(0.01)
        return row
    monkeypatch.setattr(prices, "_fetch_market_quote_uncached", uncached)
    monkeypatch.setattr(prices, "cache_get", lambda *a, **k: asyncio.sleep(0, result=None))
    stored = []
    async def set_cache(*args, **kwargs): stored.append((args, kwargs))
    monkeypatch.setattr(prices, "cache_set", set_cache)
    first, second = await asyncio.gather(prices.fetch_market_quote("BTC/USDT"), prices.fetch_market_quote("BTCUSD"))
    assert first.price == second.price == 60000 and calls == 1
    assert stored
    assert (await prices.fetch_market_quote("BTCUSD")).price == 60000
    assert calls == 1
    assert await prices.fetch_price("BTCUSD") == 60000
    batch = await prices.fetch_prices(["BTCUSD", "BTC/USDT"])
    assert list(batch) == ["BTCUSD"]
    prices.clear_price_cache_for_tests()


def test_quote_from_dict_rejects_nonfinite_price() -> None:
    payload = {"symbol": "BTCUSD", "price": float("nan"), "updated_at": datetime.now(UTC).isoformat()}
    assert prices._quote_from_dict(payload) is None
