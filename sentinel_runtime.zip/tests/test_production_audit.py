from __future__ import annotations

import asyncio
import copy
import time
from datetime import timedelta
from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest

from tests.test_master_upgrade import state, canonical_store, OWNER  # noqa: F401


@pytest.mark.asyncio
async def test_pump_recovers_db_failure_and_reports_incident(monkeypatch):
    from core import telegram_bootstrap as bootstrap
    stop = asyncio.Event()
    app = SimpleNamespace(process_error=AsyncMock())
    attempts = []

    async def worker():
        attempts.append(1)
        if len(attempts) == 1:
            raise ConnectionError('database unavailable')
        stop.set()

    monkeypatch.setattr(bootstrap, '_pause', AsyncMock())
    await bootstrap.supervise_update_pump(app, stop, worker)
    assert len(attempts) == 2
    app.process_error.assert_awaited_once()


@pytest.mark.asyncio
async def test_pump_exhaustion_reaches_parent_instead_of_silent_death(monkeypatch):
    from core import telegram_bootstrap as bootstrap
    monkeypatch.setenv('TELEGRAM_PUMP_RESTART_ATTEMPTS', '2')
    monkeypatch.setattr(bootstrap, '_pause', AsyncMock())
    worker = AsyncMock(side_effect=ConnectionError('DB down'))
    with pytest.raises(RuntimeError, match='budget exhausted'):
        await bootstrap.supervise_update_pump(SimpleNamespace(process_error=AsyncMock()), asyncio.Event(), worker)
    assert worker.await_count == 2


@pytest.mark.asyncio
async def test_bootstrap_retries_are_bounded_and_bad_credentials_not_retried(monkeypatch):
    from core import telegram_bootstrap as bootstrap
    from telegram.error import NetworkError, InvalidToken
    monkeypatch.setenv('TELEGRAM_BOOTSTRAP_ATTEMPTS', '2')
    monkeypatch.setattr(bootstrap, '_pause', AsyncMock())
    action = AsyncMock(side_effect=NetworkError('down'))
    with pytest.raises(NetworkError):
        await bootstrap.telegram_startup_call(action, asyncio.Event(), name='test')
    assert action.await_count == 2
    action = AsyncMock(side_effect=InvalidToken())
    with pytest.raises(InvalidToken):
        await bootstrap.telegram_startup_call(action, asyncio.Event(), name='test')
    assert action.await_count == 1


@pytest.mark.asyncio
async def test_both_update_processor_interfaces_work():
    from core.update_processor import KeyedUpdateProcessor
    from telegram.ext import BaseUpdateProcessor
    processor = KeyedUpdateProcessor(2)
    assert processor.process_update.__func__ is BaseUpdateProcessor.process_update
    work = AsyncMock()
    await processor.process_update(object(), work())
    await processor.do_process_update(object(), work())
    assert work.await_count == 2
    assert processor.is_healthy()
    await processor.shutdown()


@pytest.mark.asyncio
async def test_ack_flood_limit_does_not_abort_business_handler(monkeypatch):
    from core.resilient_bot import ResilientBot
    from telegram.ext import ExtBot
    from telegram.error import RetryAfter
    monkeypatch.setattr(ExtBot, 'answer_callback_query', AsyncMock(side_effect=RetryAfter(10)))
    bot = ResilientBot('123456:TEST')
    assert await bot.answer_callback_query('expired') is False


def test_repeated_and_infinite_pagination_fail_explicitly():
    from services.experience_state import _pages
    with pytest.raises(RuntimeError, match='CURSOR_REPEATED'):
        list(_pages(lambda cursor: {'items': [], 'next_cursor': 'again'}))
    with pytest.raises(RuntimeError, match='LIMIT_EXCEEDED'):
        list(_pages(lambda cursor: {'items': [], 'next_cursor': int(cursor or 0) + 1}))


@pytest.mark.parametrize('tamper', ['edit_points', 'remove_points', 'remove_event'])
def test_immutable_ledger_changes_roll_back(state, canonical_store, tamper):
    from core.db import with_db
    from core.domain import add_points
    from core.economy_integrity import economic_event
    with_db(lambda db: (add_points(db, 1, 10, 'test', source_event='audit:points'),
                        economic_event(db, 'audit:event', 1, kind='test', value=1)))

    def mutate(db):
        if tamper == 'edit_points':
            db['point_history'][0]['amount'] = 100000
        elif tamper == 'remove_points':
            db['point_history'].clear()
        else:
            db['economic_events'].clear()
    with pytest.raises(ValueError, match='IMMUTABLE'):
        with_db(mutate)
    assert canonical_store._read()['user_points']['1'] == 10


def test_new_referral_has_delay_and_qualifies_once(state, monkeypatch):
    from core.domain import apply_referral, ensure_referral
    from modules.referral_review import settle_qualifications
    from core.economy_integrity import verified_referral_activity
    from core.utils import utc_iso, utc_now
    state['settings']['referralProgram'] = {'signup_batch_size': 1, 'signup_batch_points': 15}
    apply_referral(state, 2, ensure_referral(state, 1)['code'])
    assert not verified_referral_activity(state, 1)[0]
    assert settle_qualifications(state) == 0
    state['referral_qualification']['2']['eligible_at'] = utc_iso(utc_now() - timedelta(seconds=1))
    assert settle_qualifications(state) == 1
    assert settle_qualifications(state) == 0
    assert state['user_points']['1'] == 15
    assert verified_referral_activity(state, 1)[0] == {'2'}


def test_referral_burst_requires_authorized_review_and_preserves_attribution(state):
    from core.domain import apply_referral, ensure_referral
    from modules.referral_review import review_referral, settle_qualifications
    from core.utils import utc_iso, utc_now
    code = ensure_referral(state, 1)['code']
    for uid in range(2, 7):
        state['users'][str(uid)] = {'id': uid}
        assert apply_referral(state, uid, code)[0]
        state['referral_qualification'][str(uid)]['eligible_at'] = utc_iso(utc_now() - timedelta(days=1))
    assert all(r['status'] == 'review' for r in state['referral_qualification'].values())
    assert settle_qualifications(state) == 0
    with pytest.raises(PermissionError):
        review_referral(state, 2, 3, 'approved')
    review_referral(state, OWNER, 3, 'approved')
    review_referral(state, OWNER, 4, 'rejected')
    assert settle_qualifications(state) == 1
    assert state['users']['4']['referred_by'] == '1'
    assert not apply_referral(state, 4, ensure_referral(state, 99)['code'])[0]
    with pytest.raises(ValueError):
        review_referral(state, OWNER, 4, 'approved')


def _approved(repo):
    from tests.test_manual_payment_repository import quote
    q = quote(repo, '10', payable=0, base_price=0)
    order = repo.submit_order_from_quote('10', quote_id=q['quote_id'])
    repo.claim_order_for_approval(order['id'], actor_id='admin')
    return repo.finalize_order_approval(order['id'], actor_id='admin', invite_link='https://t.me/+test')


def test_finalization_backoff_is_durable_and_bounded(sqlite_engine):
    from repositories.v2.commerce import CommerceRepository
    from repositories.v2.common import json_dump
    repo = CommerceRepository(sqlite_engine)
    order = _approved(repo)
    assert repo.pending_finalizations()[0]['id'] == order['id']
    for _ in range(8):
        repo.mark_finalization(order['id'], success=False, error='TimeoutError')
    assert repo.pending_finalizations() == []
    assert repo.get(order['id'])['finalization_status'] == 'failed'
    repo.mark_finalization(order['id'], success=True)
    assert repo.get(order['id'])['finalization_status'] == 'done'
    assert repo.entitlement_for_user('10') is not None


def test_normalized_notifications_have_persistent_delivery_state(sqlite_engine):
    from repositories.v2.commerce import CommerceRepository
    repo = CommerceRepository(sqlite_engine)
    order = _approved(repo)
    assert repo.pending_user_notifications()
    repo.mark_notification(order['id'], audience='user', success=False)
    assert not repo.pending_user_notifications()
    repo.mark_notification(order['id'], audience='user', success=True)
    assert not repo.pending_user_notifications()
    assert repo.get(order['id'])['user_notified_at']


def test_payment_events_are_idempotent_in_sql(sqlite_engine):
    from repositories.v2.events import EventRepository
    repo = EventRepository(sqlite_engine)
    one = repo.append('10', 'order.status_changed', idempotency_key='order:1')
    two = repo.append('10', 'order.status_changed', idempotency_key='order:1')
    assert one['sequence'] == two['sequence']
    assert len(repo.since('10')) == 1


def test_pump_backpressure_counts_processing_not_only_memory_queue(sqlite_engine):
    from core.telegram_update_store import persist, claim_pending, worker_inflight, mark_done
    persist(1, {'update_id': 1}, sqlite_engine)
    assert claim_pending('worker', engine=sqlite_engine)
    assert worker_inflight('worker', stale_seconds=120, engine=sqlite_engine) == 1
    assert worker_inflight('other', stale_seconds=120, engine=sqlite_engine) == 0
    mark_done(1, engine=sqlite_engine)
    assert worker_inflight('worker', stale_seconds=120, engine=sqlite_engine) == 0


def test_critical_incidents_are_claimed_for_admin_notification(state):
    from modules.incident_center import record_incident, claim_critical_notifications
    record_incident(state, source='telegram_update', kind='Error', detail='internal', severity='critical')
    assert len(claim_critical_notifications(state)) == 1
    assert not claim_critical_notifications(state)


@pytest.mark.asyncio
async def test_session_expiration_resets_only_current_user(monkeypatch):
    from core.conversation_reset import reset_conversations_on_exit, ACTIVITY_KEY
    from telegram.ext import ConversationHandler, CommandHandler, ApplicationHandlerStop
    handler = ConversationHandler(entry_points=[CommandHandler('start', AsyncMock())], states={1: []}, fallbacks=[])
    handler._conversations[(1, 1)] = 1
    handler._conversations[(2, 2)] = 1
    monkeypatch.setattr(ConversationHandler, '_get_key', lambda self, update: (1, 1))
    message = SimpleNamespace(text='stale answer', reply_text=AsyncMock())
    update = SimpleNamespace(callback_query=None, effective_message=message)
    context = SimpleNamespace(user_data={ACTIVITY_KEY: time.time()-4000, 'payment': 'stale'},
                              application=SimpleNamespace(handlers={0: [handler]}))
    with pytest.raises(ApplicationHandlerStop):
        await reset_conversations_on_exit(update, context)
    assert (1, 1) not in handler._conversations
    assert handler._conversations[(2, 2)] == 1
    assert 'payment' not in context.user_data


@pytest.mark.asyncio
async def test_admin_monitoring_denies_regular_user(monkeypatch):
    import bot  # noqa: F401 -- performs runtime binding
    from bot_runtime import system_center
    denied = AsyncMock(return_value=False)
    monkeypatch.setattr(system_center, 'require_admin', denied)
    output = AsyncMock()
    monkeypatch.setattr(system_center, 'reply', output)
    await system_center.system_status_command(SimpleNamespace(effective_message=SimpleNamespace(text='/errors')), None)
    output.assert_not_awaited()

@pytest.mark.asyncio
async def test_owner_system_command_renders_real_metrics(monkeypatch):
    import bot  # noqa: F401
    from bot_runtime import system_center
    monkeypatch.setattr(system_center, 'require_admin', AsyncMock(return_value=True))
    monkeypatch.setattr(system_center, 'async_snapshot', AsyncMock(return_value={'users': {}}))
    output = AsyncMock()
    monkeypatch.setattr(system_center, 'reply', output)
    await system_center.system_status_command(SimpleNamespace(effective_message=SimpleNamespace(text='/system')), None)
    assert 'Active users (24h): 0' in output.call_args.args[1]
    assert 'Uptime:' in output.call_args.args[1]


def test_restart_does_not_restore_expired_conversation(tmp_path):
    import sqlite3
    from core.persistence import SafeSQLitePersistence
    persistence = SafeSQLitePersistence(tmp_path/'sessions.sqlite3')
    persistence._update_conversation_sync('buy', (1, 1), 10)
    persistence._update_conversation_sync('buy', (2, 2), 20)
    with sqlite3.connect(persistence.path) as connection:
        connection.execute("UPDATE conversations SET updated_at='2000-01-01 00:00:00' WHERE state_payload='10'")
    restored = persistence._get_conversations_sync('buy')
    assert (1, 1) not in restored
    assert restored[(2, 2)] == 20


def test_concurrent_same_admin_cannot_prepare_multiple_invites(sqlite_engine):
    from concurrent.futures import ThreadPoolExecutor
    from tests.test_manual_payment_repository import quote
    from repositories.v2.commerce import CommerceRepository
    repo = CommerceRepository(sqlite_engine)
    q = quote(repo, '10', payable=0, base_price=0)
    order = repo.submit_order_from_quote('10', quote_id=q['quote_id'])
    def attempt(_):
        try:
            repo.claim_order_for_approval(order['id'], actor_id='1')
            return True
        except ValueError as exc:
            assert str(exc) == 'ORDER_NOT_PENDING'
            return False
    with ThreadPoolExecutor(max_workers=8) as pool:
        assert sum(pool.map(attempt, range(20))) == 1


def test_fixed_coupon_wallet_shows_money_not_zero_percent(state):
    from modules.reward_wallet import wallet_items
    state['discount_codes']['FIX'] = {'assigned_to': '1', 'discount_type': 'fixed', 'fixed_amount': 50000}
    assert wallet_items(state, 1)[0]['detail'] == '50,000 تومان | FIX'

@pytest.mark.asyncio
async def test_failed_finalization_retries_once_without_duplicate_points_or_notification(state, canonical_store, sqlite_engine, monkeypatch):
    from repositories.v2.commerce import CommerceRepository
    from repositories.v2.events import EventRepository
    from services import vip_payment_orchestrator as service
    import repositories.v2.commerce as commerce_module
    import core.domain as domain
    from core.db import snapshot
    repo = CommerceRepository(sqlite_engine)
    approved = _approved(repo)
    monkeypatch.setattr(service, 'CommerceRepository', lambda: repo)
    monkeypatch.setattr(commerce_module, 'CommerceRepository', lambda: repo)
    monkeypatch.setattr(service, 'EventRepository', lambda: EventRepository(sqlite_engine))
    monkeypatch.setattr(service, 'consume_normalized_order_discount', lambda row: None)
    monkeypatch.setattr(service, 'project_normalized_entitlements_to_legacy', lambda uid: None)
    monkeypatch.setattr(service, 'project_normalized_order_to_legacy', lambda oid: repo.get(oid))
    monkeypatch.setattr(service, 'mark_projected_order_notification', lambda oid, **kw: repo.mark_notification(oid, **kw))
    notify = AsyncMock(return_value=True)
    monkeypatch.setattr(service, 'notify_manual_order_user', notify)
    real = domain.record_vip_purchase_rewards
    calls = []
    def flaky(db, order):
        calls.append(1)
        if len(calls) == 1:
            raise TimeoutError('injected reward projection failure')
        return real(db, order)
    monkeypatch.setattr(domain, 'record_vip_purchase_rewards', flaky)
    with pytest.raises(TimeoutError):
        await service._finish_approved_order(None, approved, 'admin')
    assert repo.get(approved['id'])['finalization_status'] == 'pending'
    assert snapshot()['user_points'].get('10', 0) == 0
    await service._finish_approved_order(None, approved, 'admin')
    await service._finish_approved_order(None, approved, 'admin')
    assert snapshot()['user_points']['10'] == 100
    assert len([r for r in snapshot()['point_history'] if r['user_id'] == '10']) == 1
    assert len(EventRepository(sqlite_engine).since('10')) == 1
    notify.assert_awaited_once()
    assert repo.get(approved['id'])['finalization_status'] == 'done'


def test_stale_incident_delivery_recovers_but_stops_after_budget(state):
    from modules.incident_center import record_incident, claim_critical_notifications, maintain_incidents
    from core.utils import utc_now, utc_iso
    row = record_incident(state, source='telegram', kind='Error', detail='test', severity='critical')
    claim_critical_notifications(state)
    row['notification_claimed_at'] = utc_iso(utc_now() - timedelta(minutes=6))
    maintain_incidents(state)
    assert row['notification_status'] == 'retry'
    assert claim_critical_notifications(state)
    row['notification_attempts'] = 5
    row['notification_claimed_at'] = utc_iso(utc_now() - timedelta(minutes=6))
    maintain_incidents(state)
    assert row['notification_status'] == 'failed'
    assert not claim_critical_notifications(state)


def test_missing_telegram_has_actionable_install_hint():
    from main import _startup_hint
    hint = _startup_hint(ModuleNotFoundError("No module named 'telegram'"))
    assert 'requirements.lock.txt' in hint and '22.8' in hint
