"""Regression coverage for the fourteen defects independently reproduced in 8.33."""
from __future__ import annotations
import asyncio
from datetime import UTC, datetime
from decimal import Decimal
from types import SimpleNamespace
import threading
import time
import pytest
from core.storage.engine import DatabaseEngine
from core.webapp_auth import TelegramWebAppIdentity
from repositories.v2.accounts import AccountRepository
from repositories.v2.positions import PositionRepository
from services.actions_v2.context import create_context
from services.actions_v2.trading import account_upsert
from modules.calculator import calculate_position_size
from modules.management_suite import set_admin_shift, is_admin_on_shift

@pytest.fixture
def engine(tmp_path):
    db=DatabaseEngine(database_url='',sqlite_path=tmp_path/'audit.sqlite3')
    db.ensure_schema()
    yield db
    db.close()

def context(engine, uid, payload):
    identity=TelegramWebAppIdentity(uid,'','Auditor','',int(time.time()),'')
    return create_context(identity,request_id='audit',action='account_upsert',payload=payload,engine=engine)

def action_boundary(engine,monkeypatch):
    import copy
    import core.storage.engine as storage
    from core.db import DEFAULT_DB
    import services.miniapp_action_service_v2 as api
    snapshot=copy.deepcopy(DEFAULT_DB)
    monkeypatch.setattr(storage,'_ENGINE',engine)
    monkeypatch.setattr(api,'read_db_sections',lambda *a,**k:copy.deepcopy(snapshot))
    monkeypatch.setattr(api,'rate_limit_allow',lambda *a,**k:True)
    return api.handle_miniapp_action_for_identity_v2

def test_account_action_rejects_another_users_account(engine,monkeypatch):
    repo=AccountRepository(engine)
    victim=repo.upsert(1,{'name':'Victim','balance':10000,'equity':10000})
    handle=action_boundary(engine,monkeypatch)
    with pytest.raises(ValueError,match='TRADING_ACCOUNT_NOT_FOUND'):
        handle(context(engine,2,{}).identity,{'action':'account_upsert','request_id':'audit-cross-owner','payload':{'account_id':victim['id'],'name':'Changed by other user'}})
    changed=repo.get(1,victim['id'])
    assert changed['name']=='Victim'
    assert changed['balance']==10000
    assert repo.get(2,victim['id']) is None

def test_account_payload_id_cannot_bypass_own_account_lookup(engine):
    repo=AccountRepository(engine)
    victim=repo.upsert(1,{'name':'Victim'})
    own=repo.upsert(2,{'name':'Own'})
    with pytest.raises(ValueError,match='ACCOUNT_ID_IMMUTABLE'):
        account_upsert(context(engine,2,{'account_id':own['id'],'id':victim['id'],'name':'Injected ID'}))
    assert repo.get(1,victim['id'])['name']=='Victim'
    assert repo.get(2,own['id'])['name']=='Own'

def test_account_action_error_leaves_no_account(engine,monkeypatch):
    handle=action_boundary(engine,monkeypatch)
    body={'action':'account_upsert','request_id':'same-retry-id','payload':{'balance':1000,'equity':1000,'data_observed_at':'invalid-date'}}
    for _ in range(2):
        with pytest.raises(ValueError):
            handle(context(engine,3,{}).identity,body)
    rows=AccountRepository(engine).list_for_user(3)
    assert rows==[]
    with engine.transaction(read_only=True) as cur:
        assert cur.execute('SELECT * FROM v8_idempotency WHERE user_id=? AND request_id=?',('3','same-retry-id')).fetchone() is None

def test_partial_close_reduces_open_risk(engine):
    account=AccountRepository(engine).upsert(1,{'balance':10000,'equity':10000})
    repo=PositionRepository(engine)
    position=repo.open({'user_id':'1','account_id':account['id'],'symbol':'EURUSD','side':'BUY','actual_entry':1.1,'actual_stop':1.09,'actual_volume':1,'risk_percent':4,'risk_money':400})
    repo.close(1,position['id'],close_volume=.9,realized_pnl=0,exit_price=1.1)
    remaining=repo.get(1,position['id'])['remaining_volume']
    exposure=repo.active_exposure(1,account['id'])
    assert remaining==pytest.approx(.1)
    assert exposure['risk_percent']==pytest.approx(.4) and exposure['risk_money']==pytest.approx(40)

def test_overnight_shift_uses_start_day():
    db={}
    set_admin_shift(db,99,[0],'22:00','06:00','UTC',1)
    assert is_admin_on_shift(db,99,now=datetime(2026,10,6,2,tzinfo=UTC))
    assert not is_admin_on_shift(db,99,now=datetime(2026,10,5,2,tzinfo=UTC))

def test_max_lot_produces_executable_step():
    row=calculate_position_size('EURUSD',10000,1,1.1,1.09,leverage=100,lot_step=.01,max_lot=.015)
    assert Decimal(str(row['lot'])) % Decimal('.01') == 0
    assert row['lot']==.01

def test_custom_contract_cannot_calculate_unlisted_symbol():
    with pytest.raises(ValueError,match='نماد پشتیبانی'):
        calculate_position_size('CUSTOM_IDX',10000,1,100,95,contract_size=1,leverage=100)

def test_handoff_rejects_non_admin_target():
    from modules.operations_handoff import create_shift_handoff
    db={'delegated_admins':{},'users':{'1':{'id':1}}}
    with pytest.raises(ValueError,match='HANDOFF_TARGET_INVALID'):
        create_shift_handoff(db,from_admin_id=354678485,to_admin_id='1',summary='Pending payment tasks')

def test_quotes_inflight_task_is_isolated_across_event_loops(monkeypatch):
    from modules import prices
    prices.clear_price_cache_for_tests()
    entered=threading.Event()
    release=threading.Event()
    failures=[]
    async def delayed(symbol):
        entered.set()
        while not release.is_set():
            await asyncio.sleep(.005)
        return prices.MarketQuote(symbol,symbol,1.1,'Audit mock',datetime.now(UTC))
    async def cache_set(*a,**kw): pass
    monkeypatch.setattr(prices,'_fetch_market_quote_uncached',delayed)
    monkeypatch.setattr(prices,'cache_set',cache_set)
    def owner():
        try: asyncio.run(prices.fetch_market_quote('EURUSD',force=True))
        except BaseException as e: failures.append(e)
    thread=threading.Thread(target=owner)
    thread.start()
    assert entered.wait(2)
    try:
        release.set()
        assert asyncio.run(prices.fetch_market_quote('EURUSD',force=True)).price==1.1
    finally:
        release.set()
        thread.join(2)
        prices.clear_price_cache_for_tests()
    assert not thread.is_alive() and not failures

def test_market_wrapper_closes_its_http_client(monkeypatch):
    import core.http_client as http
    import services.live_market_service as market
    from modules.prices import MarketQuote
    created=[]
    async def provider(symbol,**kwargs):
        client=await http.get_client()
        created.append((asyncio.get_running_loop(),client))
        return MarketQuote(symbol,symbol,1.1,'Audit mock',datetime.now(UTC))
    monkeypatch.setattr(market,'fetch_market_quote',provider)
    market.live_quote_snapshot('EURUSD')
    market.live_quote_snapshot('EURUSD')
    assert len(created)==2
    assert all(loop.is_closed() and client.is_closed for loop,client in created)
    async def cleanup():
        for _,client in created: await client.aclose()
    asyncio.run(cleanup())

def test_concurrent_preferences_patch_retains_both_fields(engine,monkeypatch):
    from repositories.v2.preferences import PreferenceRepository
    repo=PreferenceRepository(engine)
    repo.set(1,'prefs',{'base':True})
    barrier=threading.Barrier(2)
    errors=[]
    def write(data):
        try:
            barrier.wait(timeout=3)
            repo.patch(1,'prefs',data)
        except BaseException as e: errors.append(e)
    threads=[threading.Thread(target=write,args=({'language':'en'},)),threading.Thread(target=write,args=({'alerts':False},))]
    for thread in threads: thread.start()
    for thread in threads: thread.join(5)
    final=repo.get(1,'prefs')
    assert not errors and all(key in final for key in ('language','alerts'))

def test_miniapp_disabled_notifications_are_visible_to_bot(engine,monkeypatch):
    import copy
    from core.db import DEFAULT_DB
    from services.actions_v2.preferences import notification_preferences_update
    from modules.notification_router import notification_decision
    db=copy.deepcopy(DEFAULT_DB)
    db['users']={'1':{'id':1}}
    bind_preferences(engine,monkeypatch,db)
    notification_preferences_update(context(engine,1,{'signals':False,'quiet_enabled':False}))
    assert db['user_notification_preferences']['1']['signals'] is False
    assert not notification_decision(db,1,'signals',now=datetime(2026,10,5,10,tzinfo=UTC)).allowed

def test_miniapp_language_change_is_visible_to_bot(engine,monkeypatch):
    from services.actions_v2.preferences import language_update
    from modules.i18n import user_language
    db={'users':{'1':{'id':1,'language':'fa'}},'user_profiles':{'1':{'language':'fa'}}}
    bind_preferences(engine,monkeypatch,db)
    language_update(context(engine,1,{'language':'en'}))
    assert db['user_profiles']['1']['language']=='en'
    assert user_language(db,1)=='en'

def test_miniapp_rules_acceptance_is_visible_to_bot(engine,monkeypatch):
    import copy
    from core.db import DEFAULT_DB
    from services.actions_v2.preferences import rules_accept
    from modules.rules import publish_rules,user_has_accepted_rules
    db=copy.deepcopy(DEFAULT_DB)
    rule=publish_rules(db,'Published rules for audit',354678485,'fa')
    bind_preferences(engine,monkeypatch,db)
    rules_accept(context(engine,1,{'version':rule['version'],'content_hash':rule['content_hash'],'language':'fa'}))
    assert db['rules_acceptances']['1']['fa']['version']==rule['version']
    assert user_has_accepted_rules(db,1,'fa')

def test_work_handoff_included_in_daily_operations_count():
    from modules.admin_work_queue import reconcile_work_queue,handoff_work
    from modules.operations_handoff import daily_operations_brief
    from modules.admin_access import PERMISSION_PAYMENT_RECEIPTS_VIEW
    db={'vip_orders':[{'order_id':'audit-order','user_id':'1','status':'pending'}],
        'delegated_admins':{'99':{'user_id':'99','active':True,'approval_status':'approved','permissions':[PERMISSION_PAYMENT_RECEIPTS_VIEW]}},
        'next_ids':{}}
    queue=reconcile_work_queue(db)
    row=queue['payment:audit-order']
    handoff=handoff_work(db,354678485,row['id'],99,'Please review this payment','audit-handoff')
    assert handoff['status']=='pending'
    assert daily_operations_brief(db,persist=False)['counts']['open_handoffs']==1

def test_same_loop_quote_waiter_gets_same_stale_normalization(monkeypatch):
    from modules import prices
    from datetime import timedelta
    prices.clear_price_cache_for_tests()
    async def scenario():
        started=asyncio.Event()
        release=asyncio.Event()
        async def delayed(symbol):
            started.set()
            await release.wait()
            return prices.MarketQuote(symbol,symbol,1.1,'Audit mock',datetime.now(UTC)-timedelta(days=2),stale=False)
        async def cache_set(*a,**kw):pass
        monkeypatch.setattr(prices,'_fetch_market_quote_uncached',delayed)
        monkeypatch.setattr(prices,'cache_set',cache_set)
        first=asyncio.create_task(prices.fetch_market_quote('EURUSD',force=True))
        await started.wait()
        second=asyncio.create_task(prices.fetch_market_quote('EURUSD',force=True))
        await asyncio.sleep(.01)
        release.set()
        a,b=await asyncio.gather(first,second)
        assert a.stale is True
        assert b.stale is True and b.age_seconds>86400
    asyncio.run(scenario())
    prices.clear_price_cache_for_tests()


def bind_preferences(engine,monkeypatch,db):
    from services.actions_v2 import preferences
    from core.storage import engine as storage
    monkeypatch.setattr(storage,'_ENGINE',engine)
    monkeypatch.setattr(preferences,'with_db',lambda fn:fn(db))


def test_failure_after_equity_write_rolls_back_everything(engine,monkeypatch):
    ctx=context(engine,1,{'balance':1000,'equity':1000})
    def broken(*args,**kwargs):
        raise RuntimeError('provenance write failed')
    monkeypatch.setattr(ctx.confidence,'record',broken)
    with pytest.raises(RuntimeError,match='provenance'):
        account_upsert(ctx)
    with engine.transaction(read_only=True) as cursor:
        assert cursor.execute('SELECT COUNT(*) AS n FROM v8_trading_accounts').fetchone()['n']==0
        assert cursor.execute('SELECT COUNT(*) AS n FROM v8_equity_events').fetchone()['n']==0


def test_atomic_scope_cannot_commit_after_caught_nested_failure(engine):
    with pytest.raises(RuntimeError,match='ATOMIC_OPERATION_ABORTED'):
        with engine.atomic():
            AccountRepository(engine).upsert(1,{'name':'Should roll back'})
            try:
                with engine.transaction():
                    raise ValueError('nested write failed')
            except ValueError:
                pass
    assert AccountRepository(engine).list_for_user(1)==[]


def test_legacy_shared_preferences_migrate_once_then_bot_edits_win(engine,monkeypatch):
    import copy
    from core.db import DEFAULT_DB
    from modules.i18n import user_language,set_user_language
    from modules.admin_control_center import notification_preferences,toggle_notification
    from repositories.v2.preferences import PreferenceRepository
    db=copy.deepcopy(DEFAULT_DB)
    bind_preferences(engine,monkeypatch,db)
    repo=PreferenceRepository(engine)
    repo.set(1,'user_profiles',{'language':'en'})
    repo.set(1,'user_notification_preferences',{'signals':False})
    assert user_language(db,1)=='en'
    assert notification_preferences(db,1)['signals'] is False
    set_user_language(db,1,'fa')
    toggle_notification(db,1,'signals')
    assert user_language(db,1)=='fa'
    assert notification_preferences(db,1)['signals'] is True


def test_legacy_rules_migrate_but_new_publication_requires_acceptance(engine,monkeypatch):
    import copy
    from core.db import DEFAULT_DB
    from modules.rules import publish_rules,user_has_accepted_rules
    from repositories.v2.preferences import PreferenceRepository
    db=copy.deepcopy(DEFAULT_DB)
    bind_preferences(engine,monkeypatch,db)
    rule=publish_rules(db,'Terms version one',354678485,'fa')
    PreferenceRepository(engine).set(1,'rules_acceptances',{'fa':{'version':rule['version'],'content_hash':rule['content_hash']}})
    assert user_has_accepted_rules(db,1,'fa')
    publish_rules(db,'Terms version two',354678485,'fa')
    assert not user_has_accepted_rules(db,1,'fa')


def test_cancelled_quote_reader_keeps_one_shared_provider(monkeypatch):
    from modules import prices
    prices.clear_price_cache_for_tests()
    async def scenario():
        release=asyncio.Event()
        started=asyncio.Event()
        calls=[]
        async def provider(symbol):
            calls.append(symbol);started.set();await release.wait()
            return prices.MarketQuote(symbol,symbol,1.1,'Mock',datetime.now(UTC))
        async def cache_set(*a,**kw):pass
        monkeypatch.setattr(prices,'_fetch_market_quote_uncached',provider)
        monkeypatch.setattr(prices,'cache_set',cache_set)
        first=asyncio.create_task(prices.fetch_market_quote('EURUSD',force=True))
        await started.wait();first.cancel()
        with pytest.raises(asyncio.CancelledError):await first
        second=asyncio.create_task(prices.fetch_market_quote('EURUSD',force=True))
        await asyncio.sleep(.01);release.set()
        assert (await second).price==1.1 and len(calls)==1
        await asyncio.sleep(0)
        assert not prices._INFLIGHT
    asyncio.run(scenario())


def test_account_retry_is_idempotent_at_action_boundary(engine,monkeypatch):
    handle=action_boundary(engine,monkeypatch)
    body={'action':'account_upsert','request_id':'same-success-key','payload':{'name':'Main','balance':1000,'equity':1000}}
    first=handle(context(engine,1,{}).identity,body)
    second=handle(context(engine,1,{}).identity,body)
    assert first['data']['id']==second['data']['id']
    assert len(AccountRepository(engine).list_for_user(1))==1


def test_account_partial_edit_preserves_prop_template(engine):
    ctx=context(engine,1,{'type':'prop_challenge','balance':10000,'equity':10000})
    account=account_upsert(ctx)
    ctx.payload={'account_id':account['id'],'name':'Renamed'}
    updated=account_upsert(ctx)
    assert updated['type']=='prop_challenge'
    assert updated['rule_template_id']==account['rule_template_id']


def test_notification_payload_rejects_invalid_switch(engine,monkeypatch):
    from services.actions_v2.preferences import notification_preferences_update
    bind_preferences(engine,monkeypatch,{})
    with pytest.raises(ValueError,match='INVALID_NOTIFICATION_BOOLEAN'):
        notification_preferences_update(context(engine,1,{'signals':'false'}))


def test_rules_accept_rejects_forged_hash(engine,monkeypatch):
    import copy
    from core.db import DEFAULT_DB
    from modules.rules import publish_rules
    from services.actions_v2.preferences import rules_accept
    db=copy.deepcopy(DEFAULT_DB)
    bind_preferences(engine,monkeypatch,db)
    rule=publish_rules(db,'Current terms',354678485,'fa')
    with pytest.raises(ValueError,match='RULES_VERSION_CHANGED'):
        rules_accept(context(engine,1,{'language':'fa','version':rule['version'],'content_hash':'forged'}))
    assert not db['rules_acceptances'].get('1')


def test_local_keepalive_connections_are_closed_between_market_calls(monkeypatch):
    from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
    import core.http_client as http
    import services.live_market_service as market
    from modules.prices import MarketQuote
    class Handler(BaseHTTPRequestHandler):
        protocol_version='HTTP/1.1'
        def do_GET(self):
            data=b'{"price":1.1}'
            self.send_response(200)
            self.send_header('Content-Length',str(len(data)))
            self.end_headers();self.wfile.write(data)
        def log_message(self,*args):pass
    server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
    server.daemon_threads=True
    thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
    clients=[]
    async def provider(symbol,**kwargs):
        clients.append(await http.get_client())
        response=await http.request('GET',f'http://127.0.0.1:{server.server_port}/',retries=0)
        return MarketQuote(symbol,symbol,response.json()['price'],'Local keepalive',datetime.now(UTC))
    monkeypatch.setattr(market,'fetch_market_quote',provider)
    try:
        for _ in range(8):assert market.live_quote_snapshot('EURUSD')['price']==1.1
        assert len(clients)==8 and all(client.is_closed for client in clients)
        assert not http._CLIENTS
    finally:
        server.shutdown();server.server_close();thread.join(2)


def test_shared_redis_clients_are_loop_owned_and_closed(monkeypatch):
    from core import shared_cache as cache
    import redis.asyncio as redis
    clients=[]
    class Client:
        def __init__(self):self.loop=asyncio.get_running_loop();self.closed=False
        async def ping(self):assert asyncio.get_running_loop() is self.loop
        async def aclose(self):assert asyncio.get_running_loop() is self.loop;self.closed=True
    def create(*a,**kw):
        client=Client();clients.append(client);return client
    cache.reset_shared_cache_for_tests()
    monkeypatch.setattr(cache,'SETTINGS',SimpleNamespace(redis_url='redis://test'))
    monkeypatch.setattr(redis.Redis,'from_url',create)
    async def use():
        first,second=await asyncio.gather(cache._redis_client(),cache._redis_client())
        assert first is second
        await cache.close_shared_cache()
    asyncio.run(use());asyncio.run(use())
    assert len(clients)==2 and all(client.closed for client in clients)
    assert not cache._REDIS_CLIENTS
    cache.reset_shared_cache_for_tests()


def test_manual_account_update_cannot_forge_connector_provenance(engine):
    result=account_upsert(context(engine,1,{'balance':1000,'equity':1000,'data_source':'broker',
        'data_confidence':1,'provider':'Forged','mt5_connector_id':'other-device','mt5_server':'Forged'}))
    assert result['data_source']=='manual' and result['data_confidence']==.5
    assert not result.get('mt5_connector_id') and not result.get('mt5_server')
    assert not result.get('provider')
    with engine.transaction(read_only=True) as cursor:
        event=cursor.execute('SELECT source,confidence FROM v8_equity_events WHERE account_id=?',(result['id'],)).fetchone()
    assert event['source']=='manual' and event['confidence']==.5


def test_internal_account_repository_preserves_connector_metadata(engine):
    repo=AccountRepository(engine)
    result=repo.upsert(1,{'broker_account_reference':'12345','mt5_connector_id':'trusted-device',
                        'mt5_server':'Demo','data_source':'mt5_connector','data_confidence':.99})
    saved=repo.get(1,result['id'])
    assert saved['broker_account_reference']=='12345'
    assert saved['mt5_connector_id']=='trusted-device' and saved['mt5_server']=='Demo'


@pytest.mark.parametrize('value',['invalid-date',123,True,''])
def test_notification_pause_rejects_invalid_dates(engine,monkeypatch,value):
    from services.actions_v2.preferences import notification_preferences_update
    bind_preferences(engine,monkeypatch,{})
    with pytest.raises(ValueError,match='INVALID_NOTIFICATION_PAUSE'):
        notification_preferences_update(context(engine,1,{'paused_until':value}))


def test_notification_timezone_is_stored_normalized(engine,monkeypatch):
    from services.actions_v2.preferences import notification_preferences_update
    db={};bind_preferences(engine,monkeypatch,db)
    row=notification_preferences_update(context(engine,1,{'timezone':' UTC '}))
    assert row['timezone']=='UTC'


def test_market_runner_closes_clients_opened_during_provider_cancellation(monkeypatch):
    from core import http_client as http
    from services import live_market_service as market
    clients=[]
    async def provider():
        try:await asyncio.Future()
        finally:clients.append(await http.get_client())
    async def operation():
        asyncio.create_task(provider())
        await asyncio.sleep(0)
        return {'ok':True}
    assert asyncio.run(market._owned_loop_request(operation()))=={'ok':True}
    assert len(clients)==1 and clients[0].is_closed
