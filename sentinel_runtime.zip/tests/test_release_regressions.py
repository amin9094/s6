from pathlib import Path
import json
import re

ROOT = Path(__file__).resolve().parents[1]


def test_railway_uses_readiness():
    assert 'healthcheckPath = "/readyz"' in (ROOT / 'railway.toml').read_text(encoding="utf-8")


def test_container_healthcheck_uses_readiness():
    text = (ROOT / 'scripts/healthcheck.py').read_text(encoding="utf-8")
    assert '/readyz' in text and '/healthz' not in text


def test_reads_do_not_backfill_legacy_signals():
    text = (ROOT / 'services/miniapp_read_service_v2.py').read_text(encoding="utf-8")
    assert 'sync_legacy_signals_to_normalized' not in text


def test_no_duplicate_named_js_functions():
    names = {}
    for path in (ROOT / 'webapp/src').glob('*.js'):
        for name in re.findall(
            r'(?m)^\s*(?:async\s+)?function\s+([A-Za-z_$][\w$]*)\s*\(',
            path.read_text(encoding="utf-8"),
        ):
            key = (path.name, name)
            names[key] = names.get(key, 0) + 1
    assert {key: count for key, count in names.items() if count > 1} == {}


def test_quality_inputs_ship():
    for name in ('Dockerfile.quality','Dockerfile.quality.dockerignore','pytest.ini','requirements-dev.txt'):
        assert (ROOT / name).is_file()
    assert any((ROOT / 'tests').glob('test_*.py'))


def test_persistent_storage_support_and_templates():
    entry = (ROOT / 'scripts/docker-entrypoint.sh').read_text(encoding="utf-8")
    assert 'SUPPORT_ATTACHMENT_PATH' in entry
    assert 'SIGNAL_TEMPLATE_PATH' in entry


def test_cleanup_job_exists():
    assert (ROOT / 'jobs/support_attachment_cleanup.py').is_file()


def test_development_requirements_inherit_production_lock():
    first = next(
        line.strip()
        for line in (ROOT / 'requirements-dev.txt').read_text(encoding="utf-8").splitlines()
        if line.strip() and not line.lstrip().startswith('#')
    )
    assert first == '-r requirements.lock.txt'
    assert (ROOT / 'requirements-dev.lock.txt').is_file()


def test_quality_container_uses_node_for_javascript():
    text = (ROOT / 'Dockerfile.quality').read_text(encoding="utf-8")
    assert 'node scripts/check_miniapp_js.js' in text
    assert 'python scripts/check_miniapp_js.js' not in text


def test_quality_gate_generates_smoke_artifact():
    text = (ROOT / 'scripts/quality_gate.py').read_text(encoding="utf-8")
    assert 'run_load_smoke(operations=24, workers=8)' in text
    assert 'offline_contract()' in text


def test_quality_gate_uses_isolated_pytest_runner_without_early_junit_success():
    text = (ROOT / 'scripts/quality_gate.py').read_text(encoding="utf-8")
    assert '"pytest", "-q", *test_targets' not in text
    assert 'pytest_isolated_runner.py' in text
    assert 'completion_junit=junit_path' not in text


def test_quality_proof_does_not_claim_a_missing_telegram_shim():
    text = (ROOT / 'scripts/quality_gate.py').read_text(encoding="utf-8")
    assert 'offline_import_shim' not in text
    assert 'not_exercised' in text


def test_runtime_restore_dependency_ships():
    restore = ROOT / 'restore_runtime.py'
    if not restore.is_file():
        contract = json.loads((ROOT / 'RUNTIME_BUNDLE_CONTRACT.json').read_text(encoding="utf-8"))
        assert 'restore_runtime.py' in contract.get('outer_supplied_files', [])
        return
    text = restore.read_text(encoding="utf-8")
    assert 'runtime checksum mismatch' in text
    assert 'runtime member escapes destination' in text
    assert 'if target.exists()' in text


def test_quality_container_runs_the_real_quality_gate_before_release_packaging():
    text = (ROOT / 'Dockerfile.quality').read_text(encoding="utf-8")
    assert 'python scripts/quality_gate.py' in text
    assert text.index('python scripts/quality_gate.py') < text.index('python scripts/build_release.py')
    assert '--full-suite' in text


def test_project_quality_configuration_ships():
    assert (ROOT / 'pyproject.toml').is_file()
    assert (ROOT / 'requirements.in').is_file()
