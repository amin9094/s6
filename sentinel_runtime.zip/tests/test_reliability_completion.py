from __future__ import annotations

from pathlib import Path

import pytest


def test_google_failover_commit_is_not_reported_failed_after_mirror_outage(monkeypatch, tmp_path: Path):
    from core.storage.engine import DatabaseEngine
    from core import google_sheets_backup as sheets

    engine = DatabaseEngine(database_url="", sqlite_path=tmp_path / "failover.sqlite3")
    engine.ensure_schema()
    engine._google_failover_active = True

    monkeypatch.setattr(sheets, "_normalized_pending_path", lambda: tmp_path / "outbox.json")
    monkeypatch.setattr(sheets, "flush_normalized_pending", lambda *a, **k: (_ for _ in ()).throw(RuntimeError("google down")))

    with engine.transaction() as cursor:
        cursor.execute(
            "INSERT INTO v8_user_preferences(user_id, section, updated_at, payload) VALUES(?, ?, ?, ?)",
            ("828001", "reliability", "2026-09-26T00:00:00+00:00", "{}"),
        )

    with engine.transaction(read_only=True) as cursor:
        row = cursor.execute(
            "SELECT user_id FROM v8_user_preferences WHERE user_id=? AND section=?",
            ("828001", "reliability"),
        ).fetchone()
    assert row and row["user_id"] == "828001"
    assert "v8_user_preferences" in sheets.normalized_pending_tables()


def test_google_failover_rolls_back_when_outbox_cannot_be_persisted(monkeypatch, tmp_path: Path):
    from core.storage.engine import DatabaseEngine
    from core import google_sheets_backup as sheets

    engine = DatabaseEngine(database_url="", sqlite_path=tmp_path / "failover.sqlite3")
    engine.ensure_schema()
    engine._google_failover_active = True

    monkeypatch.setattr(sheets, "mark_normalized_dirty", lambda *_a, **_k: (_ for _ in ()).throw(OSError("disk full")))

    with pytest.raises(OSError, match="disk full"):
        with engine.transaction() as cursor:
            cursor.execute(
                "INSERT INTO v8_user_preferences(user_id, section, updated_at, payload) VALUES(?, ?, ?, ?)",
                ("828002", "rollback", "2026-09-26T00:00:00+00:00", "{}"),
            )

    with engine.transaction(read_only=True) as cursor:
        row = cursor.execute(
            "SELECT user_id FROM v8_user_preferences WHERE user_id=? AND section=?",
            ("828002", "rollback"),
        ).fetchone()
    assert row is None


def test_normalized_generation_recovery_skips_incomplete_newest(monkeypatch):
    from core import google_sheets_backup as sheets

    old_generation = "0001-old"
    new_generation = "0002-new"
    old_refs = {
        table: sheets._normalized_generation_table_key(old_generation, table)
        for table in sheets.NORMALIZED_TABLES
    }
    new_refs = dict(old_refs)
    changed = sheets.NORMALIZED_TABLES[0]
    new_refs[changed] = sheets._normalized_generation_table_key(new_generation, changed)
    manifests = [
        (new_generation, {"generation": new_generation, "tables": new_refs}),
        (old_generation, {"generation": old_generation, "tables": old_refs}),
    ]
    payloads = {key: [] for key in old_refs.values()}
    # Deliberately omit the newest generation's changed payload. Recovery must
    # fall back to the previous fully committed generation rather than mixing.
    monkeypatch.setattr(sheets, "_normalized_generation_manifests", lambda: manifests)
    monkeypatch.setattr(sheets, "_read_raw_named_sections", lambda prefix: payloads)

    recovered = sheets._recover_normalized_generation()
    assert set(recovered) == set(sheets.NORMALIZED_TABLES)
    assert all(value == [] for value in recovered.values())


def test_current_schema_validation_skips_legacy_migration(monkeypatch):
    import copy
    import core.db as dbmod

    payload = copy.deepcopy(dbmod.DEFAULT_DB)
    monkeypatch.setattr(dbmod, "migrate_db", lambda _raw: (_ for _ in ()).throw(AssertionError("legacy migration should not run")))
    validated = dbmod.validate_database_payload(payload)
    assert validated is payload
    assert validated["schema_version"] == dbmod.SCHEMA_VERSION


@pytest.mark.asyncio
async def test_blocking_executor_shutdown_does_not_wait_for_stuck_worker(monkeypatch):
    import asyncio
    import time
    import core.async_runtime as runtime

    started = asyncio.Event()

    def stuck() -> None:
        started_loop.call_soon_threadsafe(started.set)
        time.sleep(2.0)

    started_loop = asyncio.get_running_loop()
    task = asyncio.create_task(runtime.run_blocking(stuck, timeout=0.05))
    await started.wait()
    with pytest.raises(TimeoutError):
        await task

    began = time.monotonic()
    drained = runtime.shutdown_blocking_executor(wait_seconds=0.05)
    elapsed = time.monotonic() - began
    assert drained is False
    assert elapsed < 0.5

    # Executor is lazily recreated for subsequent work/tests.
    assert await runtime.run_blocking(lambda: 7, timeout=1) == 7
    runtime.shutdown_blocking_executor(wait_seconds=0.1)


def test_postgres_dump_backup_is_streamed_and_restore_drillable(monkeypatch, tmp_path: Path):
    import subprocess
    from core import backup_service as backups

    calls: list[list[str]] = []

    def fake_run(command, **kwargs):
        command = [str(item) for item in command]
        calls.append(command)
        if command[0] == "pg_dump":
            output_index = command.index("--file") + 1
            Path(command[output_index]).write_bytes(b"PGDMP" + b"x" * 4096)
        elif command[0] != "pg_restore":
            raise AssertionError(command)
        return subprocess.CompletedProcess(command, 0, stdout="", stderr="")

    monkeypatch.setattr(backups.subprocess, "run", fake_run)
    target = backups.create_postgres_dump_backup(
        "postgresql://user:secret@db.example:5432/sentinel?sslmode=require",
        tmp_path,
        encryption_key="backup-secret",
        key_version="test-v1",
    )
    assert target.name.startswith("sentinel-postgres-")
    assert target.name.endswith(".dump.enc")
    assert target.with_suffix(target.suffix + ".meta.json").is_file()

    drill = backups.run_postgres_dump_restore_drill(
        target,
        tmp_path,
        encryption_key="backup-secret",
    )
    assert drill["restore_drill"] == "passed"
    assert drill["format"] == "pg_dump_custom"
    assert drill["tested_at"]
    assert calls[0][0] == "pg_dump"
    assert calls[-1][0] == "pg_restore"
    # Credentials stay in the child environment instead of the process list.
    assert not any("secret" in token for command in calls for token in command)


def test_postgres_backups_participate_in_retention(monkeypatch, tmp_path: Path):
    from core import backup_service as backups

    paths = []
    for idx in range(3):
        path = tmp_path / f"sentinel-postgres-20260926T00000{idx}.dump"
        path.write_bytes(f"dump-{idx}".encode())
        paths.append(path)
        # Stable ordering independent of filesystem timestamp granularity.
        monkeypatch.setattr(path.__class__, "stat", path.__class__.stat, raising=False)
    # Explicit mtimes make the newest deterministic.
    import os
    for idx, path in enumerate(paths):
        os.utime(path, (100 + idx, 100 + idx))

    removed = backups.prune_operational_backups(tmp_path, keep=1)
    assert removed == 2
    assert paths[-1].exists()
    assert not paths[0].exists()
    assert not paths[1].exists()


def test_google_backup_attestation_requires_write_and_readback(monkeypatch):
    from core import google_sheets_backup as sheets

    written: dict[str, object] = {}
    monkeypatch.setattr(sheets, "is_configured", lambda: True)

    def fake_write(payloads, **_kwargs):
        written.update(payloads)
        return {"synced": len(payloads)}

    monkeypatch.setattr(sheets, "_write_raw_named_payloads", fake_write)
    monkeypatch.setattr(
        sheets,
        "_read_raw_named_sections",
        lambda prefix: {prefix: dict(written[prefix])},
    )
    result = sheets.attest_backup_read_write()
    assert result["status"] == "ok"
    assert result["verified_at"]
    assert sheets.backup_attestation_status()["status"] == "ok"


def test_google_backup_attestation_rejects_stale_readback(monkeypatch):
    from core import google_sheets_backup as sheets

    monkeypatch.setattr(sheets, "is_configured", lambda: True)
    monkeypatch.setattr(sheets, "_write_raw_named_payloads", lambda *_a, **_k: {"synced": 1})
    monkeypatch.setattr(
        sheets,
        "_read_raw_named_sections",
        lambda prefix: {prefix: {"nonce": "stale"}},
    )
    with pytest.raises(sheets.GoogleSheetsBackupError, match="read-back mismatch"):
        sheets.attest_backup_read_write()
    assert sheets.backup_attestation_status()["status"] == "failed"


def test_multi_section_mutation_does_not_materialize_full_database(monkeypatch, tmp_path: Path):
    import copy
    import core.db as dbmod

    store = dbmod.SQLiteStore(tmp_path / "bounded.sqlite3", tmp_path / "backups")
    store.write(copy.deepcopy(dbmod.DEFAULT_DB))
    monkeypatch.setattr(dbmod, "_STORE", store)
    monkeypatch.setattr(dbmod, "_CACHE", None)
    monkeypatch.setattr(dbmod, "_mirror_primary_to_google", lambda *_a, **_k: None)
    monkeypatch.setattr(store, "_read", lambda: (_ for _ in ()).throw(AssertionError("full DB read is forbidden")))

    result = dbmod.with_db_sections(
        ("user_points", "next_ids"),
        lambda db: (
            db["user_points"].__setitem__("42", 9),
            db["next_ids"].__setitem__("example", 3),
            "ok",
        )[-1],
    )
    assert result == "ok"
    assert dbmod.read_db_section("user_points")["42"] == 9
    assert dbmod.read_db_section("next_ids")["example"] == 3


def test_railway_missing_replica_count_fails_closed(monkeypatch):
    from core import runtime_topology

    monkeypatch.delenv("SENTINEL_REPLICA_COUNT", raising=False)
    monkeypatch.setenv("RAILWAY_PROJECT_ID", "project-test")
    assert runtime_topology.replica_count_is_explicit() is False
    assert runtime_topology.replica_count() == 2


def test_local_missing_replica_count_defaults_to_one(monkeypatch):
    from core import runtime_topology

    monkeypatch.delenv("SENTINEL_REPLICA_COUNT", raising=False)
    for name in ("RAILWAY_PROJECT_ID", "RAILWAY_SERVICE_ID", "RAILWAY_ENVIRONMENT_ID", "RAILWAY_REPLICA_ID"):
        monkeypatch.delenv(name, raising=False)
    assert runtime_topology.replica_count() == 1


def test_runtime_has_no_direct_heartbeat_file_io_in_async_jobs():
    import ast
    from pathlib import Path

    source = Path("bot_runtime/runtime_jobs.py").read_text(encoding="utf-8")
    tree = ast.parse(source)
    direct = [
        node.lineno
        for node in ast.walk(tree)
        if isinstance(node, ast.Call)
        and isinstance(node.func, ast.Name)
        and node.func.id == "write_heartbeat"
    ]
    assert direct == [], f"write_heartbeat must run through run_blocking, direct calls at {direct}"


@pytest.mark.asyncio
async def test_connection_limit_redis_client_is_reused(monkeypatch):
    import sys
    import types
    from types import SimpleNamespace
    import core.connection_limits as limits

    class FakeRedis:
        async def aclose(self):
            return None

    created: list[FakeRedis] = []

    class RedisFactory:
        @staticmethod
        def from_url(*_args, **_kwargs):
            client = FakeRedis()
            created.append(client)
            return client

    redis_package = types.ModuleType("redis")
    redis_async = types.ModuleType("redis.asyncio")
    redis_async.Redis = RedisFactory
    redis_package.asyncio = redis_async
    monkeypatch.setitem(sys.modules, "redis", redis_package)
    monkeypatch.setitem(sys.modules, "redis.asyncio", redis_async)

    await limits.close_connection_limit_client()
    monkeypatch.setattr(limits, "SETTINGS", SimpleNamespace(redis_url="redis://unit.test:6379/0"))
    first = await limits._redis()
    second = await limits._redis()
    assert first is second
    assert len(created) == 1
    await limits.close_connection_limit_client()


def test_contest_reward_reader_does_not_mutate_database_payload():
    import copy
    from bot_runtime.admin_operations import _contest_reward_settings

    db = {"settings": {}}
    before = copy.deepcopy(db)
    values = _contest_reward_settings(db)
    assert db == before
    assert values["price"] == 5


def test_legacy_with_db_reuses_version_checked_cache_after_commit(monkeypatch, tmp_path: Path):
    import copy
    import core.db as dbmod

    store = dbmod.SQLiteStore(tmp_path / "cache.sqlite3", tmp_path / "backups")
    payload = copy.deepcopy(dbmod.DEFAULT_DB)
    payload["user_points"]["42"] = 0
    store.write(payload)
    monkeypatch.setattr(dbmod, "_STORE", store)
    monkeypatch.setattr(dbmod, "_CACHE", None)
    monkeypatch.setattr(dbmod, "_CACHE_VERSION", None)
    monkeypatch.setattr(dbmod, "_GOOGLE_FAILOVER_ACTIVE", False)
    monkeypatch.setattr(dbmod, "_mirror_primary_to_google", lambda *_a, **_k: None)

    dbmod.load_db()  # Warm and version the canonical cache.
    monkeypatch.setattr(store, "_read", lambda: (_ for _ in ()).throw(AssertionError("full store read should not recur")))

    for value in (1, 2):
        dbmod.with_db(lambda db, value=value: db["user_points"].__setitem__("42", value))
    assert dbmod.read_db_section("user_points")["42"] == 2


def test_quality_proof_is_bound_to_source_present_before_tests():
    quality = Path("scripts/quality_gate.py").read_text(encoding="utf-8")
    finalizer = Path("scripts/finalize_quality_proof.py").read_text(encoding="utf-8")
    assert "source_sha256_before = source_fingerprint(ROOT)" in quality
    assert '"source_sha256_before": source_sha256_before' in quality
    assert "current_source_sha256 != expected_source_sha256" in finalizer
    assert "release source changed during quality validation" in finalizer


def test_section_commit_advances_cache_version_for_other_writers(monkeypatch, tmp_path: Path):
    import copy
    import core.db as dbmod

    store = dbmod.SQLiteStore(tmp_path / "version.sqlite3", tmp_path / "backups")
    payload = copy.deepcopy(dbmod.DEFAULT_DB)
    payload["user_points"]["42"] = 0
    store.write(payload)
    before_version = store.version()
    before = {"user_points": dbmod._read_db_section_primary("user_points")} if dbmod._STORE is store else None

    monkeypatch.setattr(dbmod, "_STORE", store)
    monkeypatch.setattr(dbmod, "_CACHE", None)
    monkeypatch.setattr(dbmod, "_CACHE_VERSION", None)
    monkeypatch.setattr(dbmod, "_GOOGLE_FAILOVER_ACTIVE", False)
    monkeypatch.setattr(dbmod, "_mirror_primary_to_google", lambda *_a, **_k: None)

    current = dbmod._read_db_section_primary("user_points")
    updated = copy.deepcopy(current)
    updated["42"] = 1
    dbmod._commit_sections_optimistic(
        store,
        before={"user_points": current},
        after={"user_points": updated},
        changed=("user_points",),
    )
    assert store.version() > before_version


def test_quality_finalizer_never_converts_failed_coverage_tests_into_success():
    source = Path("scripts/finalize_quality_proof.py").read_text(encoding="utf-8")
    assert "coverage test worker failed with exit code" in source
    assert "if reusable_coverage or not coverage_result_path.is_file():" in source
