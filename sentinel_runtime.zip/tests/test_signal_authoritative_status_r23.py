from __future__ import annotations

import asyncio

from bot_runtime import growth_campaigns
from modules.channel_management import signal_board_page, smart_pin_text


def _base_signal(**overrides):
    row = {
        "id": 42,
        "display_number": 42,
        "symbol": "XAUUSD",
        "side": "buy",
        "status": "open",
        "entry": "100",
        "entries": ["100"],
        "stop": "90",
        "targets": ["110", "120"],
        "risk": "1",
        "target": "public",
        "delivered_channels": ["public"],
        "created_at": "2026-07-31T12:00:00+00:00",
        "updated_at": "2026-07-31T13:00:00+00:00",
        "lifecycle_history": [],
        "highest_target_hit": 0,
        "deliveries": [],
    }
    row.update(overrides)
    return row


def test_original_signal_caption_shows_only_net_r_for_tp1():
    row = _base_signal(
        status="tp1",
        highest_target_hit=1,
        lifecycle_history=[{"event": "tp1", "at": "2026-07-31T13:20:00+00:00"}],
    )
    text = growth_campaigns._signal_current_text(row)
    assert "📐 برآیند: <b>+0.50R</b>" in text
    assert "سود/زیان:" not in text
    assert "R/R:" not in text
    assert "وضعیت:" in text


def test_original_signal_caption_shows_net_loss_after_stop():
    row = _base_signal(
        status="stop",
        lifecycle_history=[{"event": "stop", "at": "2026-07-31T14:10:00+00:00"}],
    )
    text = growth_campaigns._signal_current_text(row)
    assert "📐 برآیند: <b>-1.00R</b>" in text
    assert "حد ضرر" in text or "استاپ" in text


def test_signal_board_keeps_closed_signals():
    active = _base_signal(id=1, display_number=1)
    closed = _base_signal(
        id=2,
        display_number=2,
        status="stop",
        lifecycle_history=[{"event": "stop", "at": "2026-07-31T14:10:00+00:00"}],
    )
    rows, page, pages = signal_board_page({"signals": [active, closed]}, channel="all", page=0, page_size=8)
    assert page == 0
    assert pages == 1
    assert {row["id"] for row in rows} == {1, 2}


def test_smart_pin_marks_closed_final_state_and_r():
    closed = _base_signal(
        id=2,
        display_number=2,
        status="manual_close",
        highest_target_hit=1,
        lifecycle_history=[{"event": "manual_close", "at": "2026-07-31T14:10:00+00:00"}],
    )
    text = smart_pin_text({"signals": [closed]}, "public")
    assert "بسته‌شده" in text
    assert "روی TP1 بسته شد" in text
    assert "R" in text


class _FakeBot:
    def __init__(self):
        self.deleted = []
        self.sent = []

    async def delete_message(self, **kwargs):
        self.deleted.append(kwargs)

    async def send_message(self, *args, **kwargs):
        self.sent.append((args, kwargs))
        raise AssertionError("A separate status reply must not be sent")


def test_publish_update_does_not_send_separate_reply(monkeypatch):
    row = _base_signal(
        deliveries=[{
            "chat_id": -100123,
            "message_id": 77,
            "status_message_id": 88,
        }],
    )
    bot = _FakeBot()

    async def no_pin(_bot):
        return 0

    monkeypatch.setattr(growth_campaigns, "_sync_smart_pin", no_pin)
    monkeypatch.setattr(growth_campaigns, "with_db", lambda fn: fn({"signals": [row]}))
    errors = asyncio.run(growth_campaigns._publish_signal_update(bot, row, "ignored"))
    assert errors == 0
    assert bot.sent == []
    assert bot.deleted == [{"chat_id": -100123, "message_id": 88}]
    assert "status_message_id" not in row["deliveries"][0]
