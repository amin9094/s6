from __future__ import annotations

import asyncio
from pathlib import Path
from types import SimpleNamespace

from modules.signal import send_signal_with_receipts


class _MediaGroupBot:
    def __init__(self) -> None:
        self.media_group_calls: list[dict] = []
        self.photo_calls: list[tuple] = []
        self.message_calls: list[tuple] = []

    async def send_media_group(self, *, chat_id, media):
        self.media_group_calls.append({"chat_id": chat_id, "media": media})
        return [
            SimpleNamespace(message_id=101 + index, media_group_id="album-9001")
            for index, _item in enumerate(media)
        ]

    async def send_photo(self, *args, **kwargs):
        self.photo_calls.append((args, kwargs))
        return SimpleNamespace(message_id=201)

    async def send_message(self, *args, **kwargs):
        self.message_calls.append((args, kwargs))
        return SimpleNamespace(message_id=301)


def test_signal_with_admin_chart_is_sent_as_swipeable_album(tmp_path: Path) -> None:
    poster = tmp_path / "poster.png"
    poster.write_bytes(b"fake-image")
    bot = _MediaGroupBot()

    errors, deliveries = asyncio.run(
        send_signal_with_receipts(
            bot,
            {
                "text": "<b>BUY</b>",
                "image_path": str(poster),
                "chart_photo_file_id": "telegram-chart-file-id",
            },
            "both",
            public_channel_id=-100123,
            private_channel_id=-100123,
        )
    )

    assert errors == []
    assert len(bot.media_group_calls) == 1
    assert bot.photo_calls == []
    assert bot.message_calls == []
    media = bot.media_group_calls[0]["media"]
    assert len(media) == 2
    assert media[0].caption == "<b>BUY</b>"
    assert media[1].media == "telegram-chart-file-id"
    assert len(deliveries) == 2  # logical public/private receipts remain intact
    assert {row["channel"] for row in deliveries} == {"public", "private"}
    assert all(row["message_type"] == "media_group" for row in deliveries)
    assert all(row["message_id"] == 101 for row in deliveries)
    assert all(row["message_ids"] == [101, 102] for row in deliveries)
    assert all(row["chart_message_id"] == 102 for row in deliveries)
    assert all(row["chart_message_ids"] == [102] for row in deliveries)
    assert all(row["media_group_id"] == "album-9001" for row in deliveries)
    assert not poster.exists(), "generated poster must be cleaned after delivery"


def test_signal_without_chart_keeps_single_photo_behavior(tmp_path: Path) -> None:
    poster = tmp_path / "poster.png"
    poster.write_bytes(b"fake-image")
    bot = _MediaGroupBot()

    errors, deliveries = asyncio.run(
        send_signal_with_receipts(
            bot,
            {"text": "caption", "image_path": str(poster)},
            "public",
            public_channel_id=-100456,
            private_channel_id=0,
        )
    )

    assert errors == []
    assert bot.media_group_calls == []
    assert len(bot.photo_calls) == 1
    assert deliveries[0]["message_type"] == "photo"
    assert deliveries[0]["message_ids"] == [201]
    assert deliveries[0]["chart_message_id"] is None


def test_signal_wizard_and_runtime_register_chart_photo_step() -> None:
    growth = Path("bot_runtime/growth_campaigns.py").read_text(encoding="utf-8")
    runtime = Path("bot_runtime/runtime_jobs.py").read_text(encoding="utf-8")
    shared = Path("bot_runtime/shared.py").read_text(encoding="utf-8")

    assert "SIG_CHART_IMAGE = 98301" in shared
    assert 'data["chart_photo_file_id"] = str(photo.file_id)' in growth
    assert "return SIG_CHART_IMAGE" in growth
    assert "MessageHandler(filters.PHOTO, signal_chart_image)" in runtime
    assert 'CallbackQueryHandler(signal_chart_skip, pattern=r"^sig_chart_skip$")' in runtime
    assert 'CallbackQueryHandler(signal_chart_change, pattern=r"^sig_chart_change$")' in runtime
    assert 'signal["chart_photo_file_id"]' in growth
    assert 'item.get("message_type") in {"photo", "media_group", "slideshow"}' in growth
    assert 'for key in ("status_message_id", "message_id", "chart_message_id")' in growth


def test_signal_album_supports_multiple_charts_with_single_caption(tmp_path: Path) -> None:
    poster = tmp_path / "poster.png"
    poster.write_bytes(b"fake-image")
    bot = _MediaGroupBot()
    chart_ids = [f"chart-{index}" for index in range(1, 13)]

    errors, deliveries = asyncio.run(
        send_signal_with_receipts(
            bot,
            {
                "text": "<b>SELL</b>",
                "image_path": str(poster),
                "chart_photo_file_ids": chart_ids,
            },
            "public",
            public_channel_id=-100999,
            private_channel_id=0,
        )
    )

    assert errors == []
    media = bot.media_group_calls[0]["media"]
    assert len(media) == 10  # Telegram album hard limit
    assert media[0].caption == "<b>SELL</b>"
    assert all(getattr(item, "caption", None) in {None, ""} for item in media[1:])
    assert [item.media for item in media[1:]] == chart_ids[:9]
    assert deliveries[0]["message_ids"] == list(range(101, 111))
    assert deliveries[0]["chart_message_ids"] == list(range(102, 111))
    assert deliveries[0]["message_type"] == "media_group"
