from __future__ import annotations

import json
from dataclasses import replace
from datetime import UTC, datetime, timedelta
from pathlib import Path

import pytest

from modules import gemini_ai
from modules.admin_access import AI_SCOPE_PERMISSIONS

ROOT = Path(__file__).resolve().parents[1]


@pytest.mark.parametrize(
    "module",
    [
        "payment_gateway", "vip_settings", "wallet_config", "discount_rules",
        "subscription_settings", "receipt_storage", "plan_catalog", "commerce",
        "PaymentGateway", "vip-settings", "wallet.config",
    ],
)
def test_ai_module_change_financial_aliases_are_denied(module: str) -> None:
    with pytest.raises(PermissionError, match="AI_CONTROL_TARGET_BLOCKED"):
        gemini_ai.normalize_ai_control_target(module, "enabled")
    assert gemini_ai._sanitize_proposals([
        {
            "type": "module_change_proposal",
            "title": "unsafe",
            "payload": {"module": module, "field": "enabled", "value": True},
        }
    ]) == []


def test_ai_module_change_accepts_only_canonical_safe_targets() -> None:
    rows = gemini_ai._sanitize_proposals([
        {
            "type": "module_change_proposal",
            "title": "safe",
            "payload": {"module": "riskCoach", "field": "daily-review", "value": True},
        }
    ])
    assert rows[0]["payload"] == {"module": "risk_coach", "field": "daily_review", "value": True}


def test_telegram_and_action_service_share_exact_ai_scope_permissions() -> None:
    platform = (ROOT / "bot_runtime" / "platform_expansion.py").read_text(encoding="utf-8")
    actions = (ROOT / "services" / "actions_v2" / "ai.py").read_text(encoding="utf-8")
    assert "from modules.admin_access import AI_SCOPE_PERMISSIONS" in platform
    assert "require_admin(update, AI_SCOPE_PERMISSIONS[scope])" in platform
    assert "_SCOPE_PERMISSION = AI_SCOPE_PERMISSIONS" in actions
    assert set(AI_SCOPE_PERMISSIONS) == {
        "management", "crm", "user_behavior", "channel", "tickets", "signals", "risk", "system", "knowledge"
    }


def test_human_payment_and_plan_permissions_are_not_collapsed() -> None:
    actions = (ROOT / "services" / "actions_v2" / "commerce.py").read_text(encoding="utf-8")
    telegram = (ROOT / "bot_runtime" / "commerce_calculator.py").read_text(encoding="utf-8")
    assert "_require_all_human_permissions(ctx, PERMISSION_PAYMENT_RECEIPT_APPROVE, PERMISSION_PAYMENT_VIP_ACTIVATE)" in actions
    assert "_require_human_permission(ctx, PERMISSION_PAYMENT_RECEIPT_REJECT)" in actions
    assert "PERMISSION_PAYMENT_MANUAL_REVIEW" not in actions[actions.index('def payment_approve'):actions.index('@action("admin_vip_plan_create"')]
    assert "require_admin_all(update, (PERMISSION_PAYMENT_RECEIPT_APPROVE, PERMISSION_PAYMENT_VIP_ACTIVATE))" in telegram
    assert "require_admin(update, PERMISSION_PAYMENT_RECEIPT_REJECT)" in telegram
    toggle = actions[actions.index('def admin_vip_plan_toggle_action'):actions.index('@action("admin_vip_plan_delete"')]
    assert '"archive": PERMISSION_VIP_PLAN_ARCHIVE' in toggle
    assert '"activate": PERMISSION_VIP_PLAN_ACTIVATE' in toggle


def test_identifier_pseudonymization_removes_raw_ids_and_usernames(monkeypatch: pytest.MonkeyPatch) -> None:
    db: dict = {}
    monkeypatch.setattr(gemini_ai, "with_db", lambda fn: fn(db))
    monkeypatch.setattr(gemini_ai, "read_db_sections", lambda _sections: db)
    payload = {
        "user_id": "123456789",
        "username": "private_user",
        "nested": {"actor_id": "987654321", "trader_id": "trader-42"},
    }
    safe = gemini_ai._pseudonymize_identifiers(payload)
    encoded = json.dumps(safe, ensure_ascii=False)
    assert "123456789" not in encoded
    assert "987654321" not in encoded
    assert "trader-42" not in encoded
    assert "private_user" not in encoded
    assert safe["user_id"].startswith("user_")
    assert safe["username"].startswith("username_")


def test_reversible_ticket_alias_is_resolved_only_from_server_store(monkeypatch: pytest.MonkeyPatch) -> None:
    db: dict = {}
    monkeypatch.setattr(gemini_ai, "with_db", lambda fn: fn(db))
    monkeypatch.setattr(gemini_ai, "read_db_sections", lambda _sections: db)
    alias = gemini_ai._pseudonym("ticket", "ticket-real-123", reversible=True)
    assert alias != "ticket-real-123"
    assert gemini_ai.resolve_ai_identifier(alias, "ticket") == "ticket-real-123"
    with pytest.raises(ValueError, match="AI_IDENTIFIER_ALIAS_INVALID"):
        gemini_ai.resolve_ai_identifier("ticket_deadbeefdeadbeef", "ticket")


def test_context_budget_preserves_priority_and_valid_json(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(gemini_ai, "SETTINGS", replace(gemini_ai.SETTINGS, gemini_context_max_chars=900))
    context = {
        "question": "چرا حساب من در خطر است؟",
        "prop_guardian": {"warnings": ["drawdown"] * 40, "status": "danger"},
        "module_counts": {str(i): i for i in range(200)},
        "users": [{"user_id": str(i), "noise": "x" * 80} for i in range(200)],
    }
    encoded = gemini_ai._bounded_json(context)
    parsed = json.loads(encoded)
    assert len(encoded) <= 900
    assert "question" in parsed
    assert "prop_guardian" in parsed


def test_atomic_quota_reserves_tokens_before_provider(monkeypatch: pytest.MonkeyPatch) -> None:
    db: dict = {}
    monkeypatch.setattr(gemini_ai, "with_db", lambda fn: fn(db))
    monkeypatch.setattr(gemini_ai, "SETTINGS", replace(
        gemini_ai.SETTINGS,
        gemini_user_daily_request_limit=10,
        gemini_daily_token_limit=1000,
        gemini_monthly_token_limit=2000,
    ))
    first = gemini_ai._reserve_request("u1", "user", "risk", 700)
    assert first in db["ai_usage_metrics"]["reservations"]
    with pytest.raises(PermissionError, match="AI_DAILY_TOKEN_LIMIT_REACHED"):
        gemini_ai._reserve_request("u2", "user", "risk", 400)


def test_retention_prunes_expired_ai_data() -> None:
    old = (datetime.now(UTC) - timedelta(days=500)).isoformat()
    expired = (datetime.now(UTC) - timedelta(minutes=1)).isoformat()
    db = {
        "ai_command_center": {"conversations": [{"created_at": old}]},
        "ai_audit_log": [{"created_at": old}],
        "ai_pending_proposals": [{"created_at": old, "status": "approved"}],
        "ai_response_cache": {"x": {"expires_at": expired}},
        "ai_context_snapshots": {"x": {"expires_at": expired}},
        "ai_identifier_aliases": {"x": {"kind": "ticket", "value": "1", "updated_at": old}},
        "ai_usage_metrics": {"reservations": {"x": {"expires_at": expired}}},
    }
    removed = gemini_ai._cleanup_ai_retention(db)
    assert sum(removed.values()) >= 6
    assert db["ai_command_center"]["conversations"] == []
    assert db["ai_response_cache"] == {}
    assert db["ai_identifier_aliases"] == {}


def test_knowledge_index_has_stable_citations(monkeypatch: pytest.MonkeyPatch) -> None:
    db: dict = {"knowledge_base": [{"id": "risk", "title": "Risk", "text": "مدیریت ریسک و حد ضرر روزانه"}]}
    monkeypatch.setattr(gemini_ai, "read_db_sections", lambda _sections: db)
    monkeypatch.setattr(gemini_ai, "with_db", lambda fn: fn(db))
    result = gemini_ai.knowledge_search("حد ضرر روزانه")
    assert result["index_version"] >= 2
    assert result["source_set_hash"]
    assert result["items"]
    assert all(str(row["citation"]).startswith("KB:") for row in result["items"])


def test_docker_and_release_packaging_enforce_quality_and_clean_archives() -> None:
    docker = (ROOT / "Dockerfile").read_text(encoding="utf-8")
    quality = (ROOT / "Dockerfile.quality").read_text(encoding="utf-8")
    builder = (ROOT / "scripts" / "build_release.py").read_text(encoding="utf-8")
    assert "AS quality" in docker and "COPY --from=quality /app /app" in docker
    assert "python scripts/quality_gate.py" in docker
    assert quality.index("python scripts/quality_gate.py") < quality.index("python scripts/build_release.py")
    assert 'path.name.startswith(".coverage")' in builder
    assert "HISTORICAL_DOC_RE" in builder
    assert "--evidence" in builder


def test_external_production_acceptance_is_explicit_and_cannot_silently_pass() -> None:
    script = (ROOT / "scripts" / "production_acceptance.py").read_text(encoding="utf-8")
    assert "live_staging_attestation.py" in script
    assert "gemini_live_health(force=True, generation_test=True)" in script
    assert "miniapp_playwright_smoke.mjs" in script
    assert "SentinelConnector.ex5" in script
    assert '"status": "PASSED" if not failures else "FAILED"' in script
