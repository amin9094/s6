from __future__ import annotations

from dataclasses import replace
from pathlib import Path

import pytest

from config import SETTINGS, is_admin, is_primary_admin
from modules import gemini_admin_control
from services import ai_control_service

ROOT = Path(__file__).resolve().parents[1]


def test_numeric_primary_admin_is_the_only_configured_owner() -> None:
    assert SETTINGS.primary_admin_id == 354678485
    assert is_primary_admin(354678485)
    assert is_admin(354678485)
    for user_id in SETTINGS.admin_ids:
        assert is_admin(user_id) is (int(user_id) == SETTINGS.primary_admin_id)


def test_ai_operational_catalog_is_registered_and_includes_commerce() -> None:
    from services.actions_v2 import action_specs

    specs = action_specs()
    assert set(gemini_admin_control.AI_OPERATIONAL_TOOLS) <= set(specs)
    assert {"ai_lesson_create", "ai_mission_create", "ai_contest_start"} <= set(specs)
    assert {"payment_approve", "payment_reject", "admin_vip_plan_create", "admin_vip_plan_update", "admin_vip_plan_toggle", "admin_vip_plan_delete"} <= set(gemini_admin_control.AI_OPERATIONAL_TOOLS)
    assert not any(name.startswith(("webhook_",)) for name in gemini_admin_control.AI_OPERATIONAL_TOOLS)


def test_full_access_primary_commands_queue_privilege_changes(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(ai_control_service, "is_primary_admin", lambda actor: str(actor) == "354678485")
    monkeypatch.setattr(ai_control_service, "ai_execution_settings", lambda: {
        "execution_enabled": True,
        "autonomous_primary_admin": True,
        "delegated_admin_approval_required": True,
        "primary_admin_full_bot_access": True,
    })
    executed: list[str] = []
    queued: list[dict] = []
    monkeypatch.setattr(ai_control_service, "execute_registered_admin_action", lambda actor, action, payload, source="", request_id="": executed.append(action) or {"ok": True})
    monkeypatch.setattr(ai_control_service, "queue_ai_admin_commands", lambda actor, calls, **kwargs: queued.extend(calls) or [{"id": i + 1, **call} for i, call in enumerate(calls)])
    monkeypatch.setattr(ai_control_service, "sanitize_tool_calls", lambda raw, **_kwargs: list(raw))

    result = ai_control_service.execute_or_queue_ai_tool_calls(354678485, [
        {"action": "control_change", "payload": {"module": "news", "field": "enabled", "value": False}},
        {"action": "delegated_admin_upsert", "payload": {"user_id": "123", "permissions": ["tickets"]}},
    ])
    assert executed == ["control_change"]
    assert [row["action"] for row in queued] == ["delegated_admin_upsert"]
    assert result["mode"] == "primary_autonomous_with_admin_approval"


def test_delegated_commands_are_never_executed_before_primary_approval(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(ai_control_service, "is_primary_admin", lambda _actor: False)
    monkeypatch.setattr(ai_control_service, "ai_execution_settings", lambda: {
        "execution_enabled": True,
        "autonomous_primary_admin": True,
        "delegated_admin_approval_required": True,
    })
    monkeypatch.setattr(ai_control_service, "sanitize_tool_calls", lambda raw, **_kwargs: list(raw))
    monkeypatch.setattr(ai_control_service, "requester_may_request_action", lambda *_args: True)
    monkeypatch.setattr(ai_control_service, "queue_ai_admin_commands", lambda actor, calls, **kwargs: [{"id": 99, **call} for call in calls])
    monkeypatch.setattr(ai_control_service, "execute_registered_admin_action", lambda *_args, **_kwargs: pytest.fail("delegated command executed without approval"))

    result = ai_control_service.execute_or_queue_ai_tool_calls(777, [
        {"action": "ticket_admin_reply", "payload": {"ticket_id": "t1", "text": "ok"}},
    ])
    assert result["mode"] == "primary_approval_required"
    assert result["queued"][0]["id"] == 99


def test_signal_template_size_editor_uses_supported_bundled_font_contract() -> None:
    from modules.admin_ai_assets import update_signal_template_layout

    db: dict = {}
    row = update_signal_template_layout(db, 354678485, {"side": "buy", "field": "symbol", "size": 60})
    assert row["font"]["font_size"] == 60
    with pytest.raises(ValueError, match="CUSTOM_FONT_UNSUPPORTED"):
        update_signal_template_layout(db, 354678485, {"side": "buy", "field": "symbol", "font": "unknown.ttf"})


def test_miniapp_exposes_primary_queue_and_emergency_execution_controls() -> None:
    source = (ROOT / "webapp" / "src" / "admin-parity.js").read_text(encoding="utf-8")
    read_service = (ROOT / "services" / "miniapp_read_service_v2.py").read_text(encoding="utf-8")
    for marker in (
        "data-ai-command-approve", "data-ai-command-reject",
        "data-delegated-admin-approve", "data-delegated-admin-reject",
        "data-admin-ai-execution-toggle",
    ):
        assert marker in source
    assert 'payload["pending_commands"]' in read_service
    assert 'payload["pending_admins"]' in read_service
    assert 'payload["is_primary_admin"]' in read_service


def test_primary_approval_telegram_routes_exist() -> None:
    routes = (ROOT / "handlers" / "callback_routes.py").read_text(encoding="utf-8")
    jobs = (ROOT / "bot_runtime" / "runtime_jobs.py").read_text(encoding="utf-8")
    assert "delegated_admin_approve" in routes and "delegated_admin_reject" in routes
    assert "pending_primary_approval" in jobs
    assert "درخواست افزودن ادمین جدید" in jobs


def test_admin_ai_center_read_contract_includes_primary_queues(monkeypatch: pytest.MonkeyPatch) -> None:
    from core.webapp_auth import TelegramWebAppIdentity
    from services import miniapp_read_service_v2 as read
    import modules.admin_access as access
    import modules.gemini_ai as gemini_ai

    identity = TelegramWebAppIdentity(354678485, "owner", "Owner", "", 1, "q")
    monkeypatch.setattr(read, "_require_admin_permission", lambda *_args: {"admin": {"role": "owner", "permissions": []}})
    monkeypatch.setattr(read, "is_primary_admin", lambda uid: int(uid) == 354678485)
    monkeypatch.setattr(read, "read_db_sections", lambda _sections: {"delegated_admins": {"77": {"user_id": 77, "approval_status": "pending"}}})
    monkeypatch.setattr(access, "pending_delegated_admins", lambda _db: [{"user_id": 77, "approval_status": "pending"}])
    monkeypatch.setattr(gemini_ai, "ai_history", lambda *_args, **_kwargs: {
        "items": [], "proposals": [], "commands": [
            {"id": 1, "status": "pending_primary_approval", "action": "ticket_admin_reply"},
            {"id": 2, "status": "executed", "action": "control_change"},
        ],
        "execution_settings": {"execution_enabled": True, "autonomous_primary_admin": True},
    })
    payload = read.admin_ai_center(identity)
    assert payload["is_primary_admin"] is True
    assert payload["primary_admin_id"] == 354678485
    assert [row["id"] for row in payload["pending_commands"]] == [1]
    assert payload["pending_admins"][0]["user_id"] == 77
    assert all(scope["enabled"] for scope in payload["scopes"])


def test_delegated_admin_ai_center_never_receives_owner_approval_queue(monkeypatch: pytest.MonkeyPatch) -> None:
    from core.webapp_auth import TelegramWebAppIdentity
    from services import miniapp_read_service_v2 as read
    import modules.gemini_ai as gemini_ai

    identity = TelegramWebAppIdentity(88, "admin", "Admin", "", 1, "q")
    monkeypatch.setattr(read, "_require_admin_permission", lambda *_args: {"admin": {"role": "admin", "permissions": ["ai_management_reports"]}})
    monkeypatch.setattr(read, "is_primary_admin", lambda _uid: False)
    monkeypatch.setattr(gemini_ai, "ai_history", lambda *_args, **_kwargs: {
        "items": [], "proposals": [], "commands": [{"id": 1, "status": "pending_primary_approval"}],
        "execution_settings": {"execution_enabled": True},
    })
    payload = read.admin_ai_center(identity)
    assert payload["pending_commands"] == []
    assert payload["pending_admins"] == []
    assert payload["is_primary_admin"] is False
