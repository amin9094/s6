from __future__ import annotations

from datetime import timedelta
from pathlib import Path
from types import SimpleNamespace

import pytest

from bot_runtime import commerce_calculator, navigation
from core.domain import ensure_referral, record_referral_purchase
from core.utils import parse_dt, utc_iso, utc_now
from modules.contest import (
    add_candle_guess,
    add_news_direction_answer,
    end_candle_contest,
    end_news_direction_contest,
    start_candle_contest,
    start_news_direction_contest,
)
from modules.signal_portal import delete_signal_cycle

ROOT = Path(__file__).resolve().parents[1]


def test_exact_discount_command_has_executable_local_plan() -> None:
    from modules.gemini_command_router import deterministic_local_plan, infer_admin_scope

    command = "کد تخفیف ۱۵ درصدی عمومی با انقضا ۷ روزه و کد welcome15 درست کن"
    plan = deterministic_local_plan(command)
    assert infer_admin_scope(command) == "crm"
    assert plan.missing_fields == []
    assert plan.calls == [{
        "action": "public_discount_create",
        "payload": {
            "code": "WELCOME15",
            "percent": 15,
            "days": 7,
            "max_uses": 0,
            "one_per_user": True,
        },
        "reason": "فرمان صریح ادمین برای ساخت کد تخفیف عمومی",
    }]


def test_user_gemini_is_restricted_to_own_account_topics() -> None:
    from modules.gemini_ai import user_ai_question_allowed

    assert user_ai_question_allowed("عملکرد حسابم را بگو")
    assert user_ai_question_allowed("ریسک معاملات خودم را بررسی کن")
    assert user_ai_question_allowed("سیگنال های فعال من را خلاصه کن")
    assert not user_ai_question_allowed("کاربر دیگر را بن کن")
    assert not user_ai_question_allowed("کد تخفیف بساز")


def test_forward_menu_replaces_message_but_back_does_not() -> None:
    def query(data: str, text: str):
        button = SimpleNamespace(callback_data=data, text=text)
        markup = SimpleNamespace(inline_keyboard=[[button]])
        message = SimpleNamespace(reply_markup=markup)
        return SimpleNamespace(data=data, message=message)

    assert navigation._should_replace_navigation_message(query("u_vip", "💎 خرید اشتراک")) is True
    assert navigation._should_replace_navigation_message(query("vip_plan:1", "پلن یک")) is True
    assert navigation._should_replace_navigation_message(query("u_edu", "🎓 آموزش")) is False
    assert navigation._should_replace_navigation_message(query("lesson:1", "📖 درس")) is False
    assert navigation._should_replace_navigation_message(query("home", "⬅️ برگشت")) is False
    assert navigation._should_replace_navigation_message(query("u_edu", "🔙 بازگشت")) is False


def test_education_menu_contains_only_admin_library() -> None:
    source = (ROOT / "bot_runtime" / "account_support.py").read_text(encoding="utf-8")
    block = source[source.index("async def u_edu"):source.index("async def edu_type")]
    assert 'callback_data="u_bot_guide"' not in block
    assert 'callback_data="edu_type:trading"' in block
    assert "آموزش کار با ربات" not in block
    assert "کتابخانه آموزش" in block
    assert "edu_type:free" not in block
    assert "edu_type:paid" not in block
    assert "protect_content=True" in source


def test_miniapp_checkout_coupon_is_optional_and_idempotent() -> None:
    source = (ROOT / "webapp" / "src" / "commerce-support.js").read_text(encoding="utf-8")
    assert 'id="hasCoupon" type="checkbox"' in source
    assert "coupon = $('#hasCoupon')?.checked" in source
    assert "'Idempotency-Key': requestId" in source
    assert "request_id: requestId" in source
    assert "if (!free && !file)" in source
    server = (ROOT / "core" / "miniapp_server.py").read_text(encoding="utf-8")
    assert '@app.post("/api/v1/checkout/quote")' in server
    assert '@app.get("/api/v1/orders/{order_id}/receipt")' in server
    assert '@app.get("/api/v1/admin/orders/{order_id}/receipt")' in server


def test_candle_contest_collects_question_and_scores_top_ten() -> None:
    db: dict = {}
    contest = start_candle_contest(db, duration_minutes=60, question="قیمت XAUUSD در پایان کندل؟")
    assert contest["question"] == "قیمت XAUUSD در پایان کندل؟"
    for uid, guess in enumerate((100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110), start=1):
        assert add_candle_guess(db, uid, guess) == "OK"
    _closed, results = end_candle_contest(db, 100)
    points = [row["points"] for row in results]
    assert points[:10] == [10, 7, 5, 3, 3, 3, 3, 3, 3, 3]
    assert points[10] == 0


def test_news_direction_contest_awards_five_points_to_correct_users() -> None:
    db: dict = {}
    contest = start_news_direction_contest(db, "US CPI", duration_minutes=30, reward_points=5)
    assert contest["news_name"] == "US CPI"
    assert add_news_direction_answer(db, 11, "UP") == "OK"
    assert add_news_direction_answer(db, 12, "DOWN") == "OK"
    assert add_news_direction_answer(db, 11, "UP") == "ALREADY"
    _closed, winners = end_news_direction_contest(db, "UP")
    assert winners == ["11"]
    assert db["user_points"]["11"] == 5
    assert db["user_points"].get("12", 0) == 0


def test_referral_two_distinct_buyers_extend_existing_vip_and_are_idempotent() -> None:
    now = utc_now()
    db: dict = {
        "users": {
            "1": {"id": "1"},
            "2": {"id": "2", "referred_by": "1"},
            "3": {"id": "3", "referred_by": "1"},
        },
        "vip_users": {"1": {"status": "active", "expires_at": utc_iso(now + timedelta(days=20))}},
    }
    db["vip_orders"] = [{"order_id":f"order-{u}","user_id":u,"price":150000,"status":"approved" if u == "2" else "pending"} for u in ("2","3")]
    ensure_referral(db, "1")
    first = record_referral_purchase(db, "2", "order-2")
    assert first["vip_days_awarded"] == 0
    duplicate = record_referral_purchase(db, "2", "order-2")
    assert duplicate["reason"] == "ALREADY_RECORDED"
    db["vip_orders"][1]["status"] = "approved"
    second = record_referral_purchase(db, "3", "order-3")
    assert second["vip_days_awarded"] == 30
    expiry = parse_dt(db["vip_users"]["1"]["expires_at"])
    assert expiry is not None
    assert expiry > now + timedelta(days=49)
    assert len(db["user_referrals"]["1"]["purchasers"]) == 2


def test_calculator_profile_persists_capital_and_two_leverages() -> None:
    db: dict = {}
    commerce_calculator._calculator_profile_set(db, "42", "capital", 5000)
    commerce_calculator._calculator_profile_set(db, "42", "forex_leverage", 100)
    commerce_calculator._calculator_profile_set(db, "42", "crypto_leverage", 10)
    profile = commerce_calculator._calculator_profile(db, "42")
    assert profile == {"capital": 5000.0, "forex_leverage": 100.0, "crypto_leverage": 10.0}


def test_closed_signal_cycle_can_be_deleted_without_touching_other_cycles() -> None:
    db: dict = {
        "signal_cycle": {
            "current_id": 2,
            "status": "active",
            "periods": [
                {"id": 1, "name": "قدیمی", "status": "closed"},
                {"id": 2, "name": "فعال", "status": "active"},
            ],
        },
        "signals": [{"id": 20, "cycle_id": 2}],
        "signal_archive": [{"id": 10, "cycle_id": 1}, {"id": 21, "cycle_id": 2}],
        "user_signal_choices": {"7": {"10": {"cycle_id": 1}, "20": {"cycle_id": 2}}},
        "journal": [{"signal_id": 10, "cycle_id": 1}, {"signal_id": 20, "cycle_id": 2}],
    }
    result = delete_signal_cycle(db, 1, 354678485)
    assert result["deleted_archive"] == 1
    assert [row["id"] for row in db["signal_archive"]] == [21]
    assert [row["id"] for row in db["signals"]] == [20]
    assert [row["cycle_id"] for row in db["journal"]] == [2]
    assert [row["id"] for row in db["signal_cycle"]["periods"]] == [2]
    with pytest.raises(ValueError):
        delete_signal_cycle(db, 2, 354678485)


def test_crm_pipeline_and_direct_customer_actions_are_registered() -> None:
    runtime = (ROOT / "bot_runtime" / "runtime_jobs.py").read_text(encoding="utf-8")
    routes = (ROOT / "handlers" / "callback_routes.py").read_text(encoding="utf-8")
    admin = (ROOT / "bot_runtime" / "admin_operations.py").read_text(encoding="utf-8")
    analytics = (ROOT / "bot_runtime" / "analytics_governance.py").read_text(encoding="utf-8")
    assert "crm_pipeline_stage_members" in admin
    assert "await async_with_db(crm_pipeline_snapshot)" in admin
    assert "crm_pipeline_stage:" in routes
    assert "crm_message_start" in runtime
    assert "crm_discount_send" in routes
    assert "crm_message_input" in analytics


def test_signal_album_uses_two_photo_media_group() -> None:
    source = (ROOT / "modules" / "signal.py").read_text(encoding="utf-8")
    assert "send_media_group" in source
    assert "InputMediaPhoto" in source
    assert "chart_image" in source or "chart" in source


def test_user_menu_has_support_language_and_direct_referral() -> None:
    source = (ROOT / "bot_runtime" / "navigation.py").read_text(encoding="utf-8")
    block = source[source.index("def main_menu("):source.index("def user_category_menu")]
    assert 'callback_data="u_support"' in block
    assert 'callback_data="account_rewards"' not in block
    assert 'callback_data="language_menu"' in block
    assert '"u_ai_chat_start"' not in block
    assert 'callback_data="u_referral"' in block
    assert 'callback_data="u_rewards"' in block
