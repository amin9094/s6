from __future__ import annotations

from types import SimpleNamespace

import pytest

from services import live_market_service as service


class _Quote:
    def __init__(self, symbol: str, price: float = 100.0) -> None:
        self.symbol = symbol
        self.price = price

    def as_dict(self) -> dict:
        return {
            "symbol": self.symbol,
            "price": self.price,
            "source": "unit-test",
            "confidence": 0.91,
            "provider_count": 2,
            "age_seconds": 1.5,
            "stale": False,
            "delayed": False,
            "updated_at": "2026-07-31T00:00:00+00:00",
        }


class _PreferenceRepo:
    def get(self, user_id, namespace, default):
        assert namespace == "user_watchlists"
        return [
            {"symbol": "btcusd", "note": "normalized"},
            {"symbol": ""},
            "invalid",
        ]


def _fake_db(sections):
    return {name: {} for name in sections}


def test_live_market_snapshot_success_and_authoritative_watchlist(monkeypatch) -> None:
    monkeypatch.setattr(service, "read_db_sections", _fake_db)
    monkeypatch.setattr(
        service,
        "watchlist_for_user",
        lambda db, user_id: [{"symbol": "xauusd", "source": "legacy"}, {"symbol": None}],
    )
    monkeypatch.setattr(service, "classify_market_symbol", lambda symbol: "forex" if "USD" in symbol else "crypto")
    monkeypatch.setattr(service, "market_regime_dashboard", lambda db: {"regime": "balanced"})

    async def quote(symbol: str, *, force: bool = False):
        assert force is True
        return _Quote(symbol)

    iran_item = SimpleNamespace(
        symbol="IRR_USD",
        title="دلار",
        price=90000,
        unit="تومان",
        change_percent=1.2,
        source="iran-unit",
        estimated=False,
        updated_at="2026-07-31T00:00:00+00:00",
    )

    async def iran(*, force: bool = False):
        assert force is True
        return SimpleNamespace(all_quotes=[iran_item], stale=False)

    monkeypatch.setattr(service, "fetch_market_quote", quote)
    monkeypatch.setattr(service, "fetch_iran_market_snapshot", iran)

    result = service.live_market_snapshot("42", force=True)
    assert result["live"] is True
    assert result["failed_quotes"] == []
    assert result["iran_error"] == ""
    assert result["iran_quotes"][0]["symbol"] == "IRR_USD"
    assert result["regime"] == {"regime": "balanced"}
    assert {row["symbol"] for row in result["watchlist"]} == {"XAUUSD"}
    assert all(row["quote_available"] for row in result["watchlist"])


def test_live_market_snapshot_contains_provider_failures_without_crashing(monkeypatch) -> None:
    monkeypatch.setattr(service, "read_db_sections", _fake_db)
    monkeypatch.setattr(service, "watchlist_for_user", lambda db, user_id: [])
    monkeypatch.setattr(service, "classify_market_symbol", lambda symbol: "market")
    monkeypatch.setattr(service, "market_regime_dashboard", lambda db: {})

    async def quote(symbol: str, *, force: bool = False):
        if symbol == "XAUUSD":
            raise RuntimeError("provider down")
        if symbol == "EURUSD":
            return _Quote(symbol, price=0)
        return _Quote(symbol)

    async def iran(*, force: bool = False):
        raise RuntimeError("iran provider down")

    monkeypatch.setattr(service, "fetch_market_quote", quote)
    monkeypatch.setattr(service, "fetch_iran_market_snapshot", iran)

    result = service.live_market_snapshot("7")
    assert len(result["failed_quotes"]) == 2
    assert {row["symbol"] for row in result["failed_quotes"]} == {"XAUUSD", "EURUSD"}
    assert result["iran_quotes"] == []
    assert result["iran_error"] == "iran provider down"


def test_symbol_quote_helpers_cover_success_failure_and_validation(monkeypatch) -> None:
    monkeypatch.setattr(service, "classify_market_symbol", lambda symbol: "crypto")

    async def quote(symbol: str, *, force: bool = False):
        if symbol == "FAILUSD":
            raise RuntimeError("no quote")
        return _Quote(symbol)

    monkeypatch.setattr(service, "fetch_market_quote", quote)
    rows = service.live_quotes_for_symbols(["btcusd", "BTCUSD", "FAILUSD", ""], force=True)
    assert list(rows) == ["BTCUSD", "FAILUSD"]
    assert rows["BTCUSD"]["ok"] is True
    assert rows["FAILUSD"]["ok"] is False
    assert service.live_quote_snapshot("btcusd")["symbol"] == "BTCUSD"
    with pytest.raises(ValueError, match="SYMBOL_REQUIRED"):
        service.live_quote_snapshot("")
    with pytest.raises(ValueError, match="no quote"):
        service.live_quote_snapshot("FAILUSD")
