from pathlib import Path
import json
import subprocess

import pytest
from bot_runtime import navigation
from ui.button_factory import InlineKeyboardButton, state_button
from services import miniapp_read_service_v2 as read
from core.webapp_auth import TelegramWebAppIdentity

ROOT = Path(__file__).resolve().parents[1]

@pytest.mark.parametrize('language', ['fa','en'])
def test_menu_preserves_complete_access_and_full_width_app(monkeypatch, language):
    db={'users':{'1':{}},'user_rewards':[{'id':1,'user_id':'1','title':'VIP','created_at':'2026-10-05'}]}
    monkeypatch.setattr(navigation,'load_db',lambda:db)
    monkeypatch.setattr(navigation,'_language_for_user',lambda _:language)
    monkeypatch.setattr(navigation,'is_vip',lambda *_:False)
    monkeypatch.setattr(navigation,'_is_any_admin',lambda _:True)
    monkeypatch.setattr(navigation,'_has_any_admin_permission',lambda *_:True)
    monkeypatch.setattr(navigation,'with_webapp',lambda rows:rows+[[InlineKeyboardButton('Mini App',callback_data='test_app')]])
    rows=navigation.main_menu(1)
    assert [[b.callback_data for b in row] for row in rows[:4]]==[['u_vip'],['u_edu','u_calc'],['u_price','u_account'],['u_contests','u_missions']]
    assert len(rows[-1])==1 and rows[-1][0].callback_data=='test_app'
    callbacks=[b.callback_data for row in rows for b in row]
    assert len(callbacks)==len(set(callbacks))
    assert {'u_my_rewards','u_rewards','u_referral','nav_user:club','kpi_trader_home','admin_home','home','learning_rules'}<=set(callbacks)
    by={b.callback_data:b for row in rows for b in row}
    assert by['u_vip'].style=='success'
    assert by['u_signal_portal'].style==by['nav_user:trade'].style=='primary'
    assert by['u_rewards'].style is None and '🔴 1' in by['u_my_rewards'].text
    assert by['u_signal_portal'].text.startswith('📡')
    assert by['u_contests'].text.startswith('🏆')
    assert by['u_referral'].text.startswith('🔗')

@pytest.mark.parametrize('label,callback,expected',[
    ('🎁 جایزه‌های من · 🔴 2','u_my_rewards',None),
    ('🎓 آموزش','u_edu',None),
    ('⬅️ Back','admin_home',None),
    ('🏠 منوی اصلی','home',None),
    ('🗑 حذف سیگنال','a_signal_delete:1','danger'),
    ('✅ تأیید جایزه','reward_approve:1','success'),
    ('❌ رد جایزه','reward_reject:1','danger'),
    ('✖️ Cancel','cancel_current','danger'),
    ('➕ ساخت آسان','a_create','primary'),
])
def test_colors_represent_actions_not_incidental_badges(label,callback,expected):
    assert InlineKeyboardButton(label,callback_data=callback).style==expected

@pytest.mark.parametrize('enabled',[True,False])
def test_state_controls_still_have_semantic_color(enabled):
    assert state_button('اتوماسیون',enabled,callback_data='automation_toggle:1').style==('success' if enabled else 'danger')


def test_unread_overview_is_signed_user_scoped(monkeypatch,sqlite_engine):
    # Exercise the actual overview assembly while substituting unrelated expensive reads.
    class Page:
        def list(self,**kwargs):return {'items':[]}
        def list_for_user(self,*args,**kwargs):return {'items':[]}
    shell={'user':{},'points':0,'vip_active':False,'vip_expires_at':None,'onboarding':{'completed':True},'notifications':{},'features':{},'commerce':{},'rules':{},'admin_available':False,'admin':{}}
    monkeypatch.setattr(read,'_safe_shell',lambda _:shell)
    monkeypatch.setattr(read,'_repos',lambda:(sqlite_engine,None,None,Page(),None,None,Page(),None))
    monkeypatch.setattr(read,'_signal_choices',lambda _: {})
    monkeypatch.setattr(read,'_account_risk',lambda _: {'prop':{}})
    monkeypatch.setattr(read,'_journal_stats',lambda *_: {})
    from services import live_market_service
    monkeypatch.setattr(live_market_service,'live_quotes_for_symbols',lambda _: {})
    from modules.reward_wallet import mark_wallet_seen,wallet_items,reward_seen_key
    db={'users':{'77':{},'88':{}},'user_rewards':[{'id':1,'user_id':'77','created_at':'2026-10-05','type':'vip_days'},{'id':2,'user_id':'88','created_at':'2026-10-05'}],'discount_codes':{'OWN':{'assigned_to':'77','percent':15,'created_at':'2026-10-05'}}}
    monkeypatch.setattr(read,'read_db_sections',lambda _:db)
    identity=TelegramWebAppIdentity(77,'user','First','Last',1,'q')
    assert read.overview(identity)['account']['unread_rewards']==2
    mark_wallet_seen(db,77,[reward_seen_key(x) for x in wallet_items(db,77)])
    assert read.overview(identity)['account']['unread_rewards']==0
    db['user_rewards'].append({'id':3,'user_id':'77','created_at':'2026-10-06'})
    assert read.overview(identity)['account']['unread_rewards']==1


def test_actual_miniapp_catalog_and_badge_lifecycle():
    result=subprocess.run(['node',str(ROOT/'tests/miniapp_menu838.mjs')],cwd=ROOT,capture_output=True,text=True,timeout=25)
    assert result.returncode==0,result.stdout+result.stderr
    data=json.loads(result.stdout)
    assert data['passed']==8 and not data['failed']


def test_native_miniapp_launcher_is_primary():
    from telegram import WebAppInfo
    button=InlineKeyboardButton("📱 SENTINEL Mini App",web_app=WebAppInfo("https://example.com/app"))
    assert button.style == "primary" and button.web_app.url == "https://example.com/app"
