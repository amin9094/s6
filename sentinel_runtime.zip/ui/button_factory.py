from __future__ import annotations

import logging
import os
from typing import Any

from telegram import InlineKeyboardButton as TelegramInlineKeyboardButton
from telegram import InlineKeyboardMarkup
from telegram.error import BadRequest

logger = logging.getLogger(__name__)

# Telegram buttons are intentionally rendered through one safe factory. Newer
# Telegram clients can show a custom-emoji icon and a native button style;
# older clients simply keep the text/Unicode fallback without breaking.
_UI_CUSTOM_EMOJI_ENV = {
    "vip": "UI_EMOJI_VIP_ID",
    "education": "UI_EMOJI_EDUCATION_ID",
    "market": "UI_EMOJI_MARKET_ID",
    "risk": "UI_EMOJI_RISK_ID",
    "contest": "UI_EMOJI_CONTEST_ID",
    "signal": "UI_EMOJI_SIGNAL_ID",
    "account": "UI_EMOJI_ACCOUNT_ID",
    "news": "UI_EMOJI_NEWS_ID",
    "support": "UI_EMOJI_SUPPORT_ID",
    "rewards": "UI_EMOJI_REWARDS_ID",
}
_UI_FALLBACK_EMOJI = {
    "vip": "💎",
    "education": "🎓",
    "market": "📈",
    "risk": "🧮",
    "contest": "🏆",
    "signal": "📡",
    "account": "👤",
    "news": "📰",
    "support": "🎧",
    "rewards": "🎁",
    "referral": "🔗",
    "points": "⭐",
    "ranking": "🏅",
    "tools": "🧰",
    "mission": "🎯",
    "trading": "🛰",
}
_UI_EXACT_CALLBACK_ICONS = {
    "u_vip": "vip",
    "u_edu": "education",
    "u_price": "market",
    "u_calc": "risk",
    "u_contests": "contest",
    "u_missions": "mission",
    "u_referral": "referral",
    "u_signal_portal": "signal",
    "u_account": "account",
    "u_calendar": "news",
    "u_support": "support",
    "nav_user:trade": "trading",
    "nav_user:account": "account",
    "nav_user:growth": "support",
    "nav_user:club": "points",
    "nav_user:tools": "tools",
    "nav_user:more": "support",
    "u_score": "points",
    "u_leaderboard": "ranking",
    "u_rewards": "rewards",
    "u_my_rewards": "rewards",
    "account_vip": "vip",
    "account_education": "education",
    "account_rewards": "rewards",
    "account_activity": "account",
}
_UI_PREFIX_CALLBACK_ICONS = (
    ("user_signal", "signal"),
    ("a_signal", "signal"),
    ("calc:", "risk"),
    ("risk:", "risk"),
    ("price_alert", "market"),
    ("pa_", "market"),
    ("mi_", "news"),
    ("a_market_intel", "news"),
    ("a_contest", "contest"),
    ("a_edu", "education"),
    ("a_ticket", "support"),
    ("ticket_", "support"),
    ("reward_", "rewards"),
    ("redeem:", "rewards"),
    ("mission_", "rewards"),
    ("a_reward", "rewards"),
    ("a_disc", "rewards"),
    ("a_leaderboard", "rewards"),
    ("account_", "account"),
    ("admin_user", "account"),
    ("a_users", "account"),
    ("a_crm", "account"),
    ("crypto_", "market"),
    ("stock_", "market"),
    ("iran_prices", "market"),
    ("price:", "market"),
    ("edu_", "education"),
    ("lesson", "education"),
    ("faq", "support"),
)
_UI_PRIMARY_CALLBACK_PREFIXES = (
    "u_",
    "nav_user:",
    "home",
    "admin_home",
    "admin_cat:",
    "account_",
    "web_",
)


def _button_icon_key(callback_data: Any, text: str) -> str | None:
    callback = str(callback_data or "")
    if callback in _UI_EXACT_CALLBACK_ICONS:
        return _UI_EXACT_CALLBACK_ICONS[callback]
    for prefix, key in _UI_PREFIX_CALLBACK_ICONS:
        if callback.startswith(prefix):
            return key
    lowered = str(text or "").lower()
    keyword_groups = (
        ("vip", ("vip", "اشتراک", "تمدید")),
        ("education", ("آموزش", "درس", "کتابخانه")),
        ("market", ("بازار", "قیمت", "دلار", "تتر", "طلا", "نفت", "سهام", "ارز", "هشدار قیمت")),
        ("risk", ("ریسک", "ماشین‌حساب", "ماشین حساب")),
        ("contest", ("مسابقه", "چارت", "کندل")),
        ("signal", ("سیگنال", "تحلیل‌گر", "ردیابی")),
        ("account", ("حساب", "کاربر", "crm", "فعالیت")),
        ("news", ("اخبار", "خبر", "اقتصاد", "تقویم")),
        ("support", ("پشتیبانی", "تیکت", "سوالات", "سؤالات")),
        ("rewards", ("جایزه", "جوایز", "امتیاز", "مأموریت", "ماموریت", "لیدربورد", "معرف", "تخفیف")),
    )
    for key, words in keyword_groups:
        if any(word in lowered for word in words):
            return key
    return None


def _configured_custom_emoji_id(key: str | None) -> str | None:
    if not key:
        return None
    env_name = _UI_CUSTOM_EMOJI_ENV.get(key)
    value = str(os.getenv(env_name or "", "")).strip()
    # Telegram custom-emoji identifiers are numeric strings. Silently ignoring
    # malformed optional values keeps the bot deployable with fallback icons.
    if not (value.isdigit() and 5 <= len(value) <= 32):
        return None
    return None if value in _REJECTED_CUSTOM_EMOJI_IDS else value


def _strip_leading_symbol_token(text: str) -> str:
    parts = str(text).split(" ", 1)
    if len(parts) != 2 or not parts[0]:
        return str(text)
    token = parts[0]
    if any(ch.isalnum() or "؀" <= ch <= "ۿ" for ch in token):
        return str(text)
    return parts[1]


def _button_native_style(callback_data: Any, text: str) -> str | None:
    """One semantic palette, independent of incidental unread/status emojis."""
    callback = str(callback_data or "")
    label = str(text or "").strip()
    lowered = label.casefold()
    # Canonical Back envelopes must never look like destructive operations.
    if callback.startswith(("nb:", "nav_back", "back", "return_")):
        return None
    if callback == "cancel_current" or callback.startswith("cancel"):
        return "danger"
    if label.startswith(("⬅", "↩", "🔙", "◀", "←")):
        return None
    if callback == "u_vip":
        return "success"
    if callback in {"u_signal_portal", "nav_user:trade", "a_create", "work_queue", "a_signal", "palette_start"}:
        return "primary"
    # Meaning comes from the action title, not any trailing badge (e.g. 🔴 2).
    if label.startswith(("🗑", "❌", "✖", "⛔", "⏸")) or lowered.startswith(("delete ", "remove ", "reject ", "disable ")) or any(
        word in lowered for word in ("حذف", "رد درخواست", "رد پرداخت", "غیرفعال کردن", "غیرفعال‌کردن")
    ):
        return "danger"
    if label.startswith(("✅", "🟢")) or lowered.startswith(("publish", "approve", "confirm", "enable ")) or any(
        word in lowered for word in ("تأیید و", "تایید و", "انتشار", "روشن‌کردن", "فعال‌کردن")
    ):
        return "success"
    # State controls retain their current-state colors.
    if any(marker in lowered for marker in (": خاموش", ": غیرفعال", ": off", ": disabled")):
        return "danger"
    if any(marker in lowered for marker in (": روشن", ": فعال", ": on", ": enabled")):
        return "success"
    return None


def state_button(
    text: str,
    enabled: bool,
    *,
    callback_data: str,
    enabled_label: str = "روشن",
    disabled_label: str = "خاموش",
    show_state: bool = True,
    **kwargs: Any,
) -> TelegramInlineKeyboardButton:
    """Create a current-state toggle: green when enabled, red when disabled."""
    clean = str(text or "").strip()
    if show_state:
        state_text = enabled_label if enabled else disabled_label
        rendered = f"{clean}: {state_text}"
    else:
        rendered = clean
    kwargs.setdefault("style", "success" if enabled else "danger")
    return InlineKeyboardButton(rendered, callback_data=callback_data, **kwargs)



def _navigation_exit_kind(text: str, callback_data: Any = None) -> str | None:
    """Classify a genuine navigation exit and reject menu-title leakage.

    Older screens used labels such as ``↩️ میز بازار زنده`` for a Back
    callback.  Telegram then rendered a red Back control with the section name.
    The callback and the visible text are now normalized together.
    """
    import re

    clean = re.sub(r"\s+", " ", str(text or "")).strip().casefold()
    callback = str(callback_data or "").strip().casefold()
    stripped = clean.lstrip("↩️🔙⬅️◀️←❌✖️ ").strip()
    if callback == "cancel_current" or stripped in {"انصراف", "لغو", "cancel", "cancel action"}:
        return "cancel"
    if callback == "nav_back" or callback.startswith(("back", "return_", "go_back")):
        return "back"
    # Pagination arrows, template-position arrows and action buttons are not
    # navigation exits even though legacy copy sometimes reused a Back glyph.
    if stripped in {"", "قبلی", "previous", "prev"}:
        return None
    if callback.startswith(("discount_refund_confirm:", "sig_tpl_move:")):
        return None
    if clean.startswith(("↩", "🔙", "⬅", "◀", "←")):
        return "back"
    if stripped in {"بازگشت", "برگشت", "back"}:
        return "back"
    if stripped.startswith(("بازگشت به ", "برگشت به ", "back to ")):
        return "back"
    return None


def _is_navigation_exit_label(text: str) -> bool:
    """Backward-compatible predicate used by navigation contract tests."""
    return _navigation_exit_kind(text) is not None


_BACK_TARGET_PREFIX = "nb:"
_MAX_CALLBACK_DATA_BYTES = 64


def _encoded_back_callback(callback_data: Any = None) -> str:
    """Encode a deterministic parent callback for Back without losing its route.

    Telegram limits callback data to 64 bytes.  Normal parent callbacks are
    compact ASCII identifiers; exceptionally long legacy values fall back to
    the snapshot-based ``nav_back`` route instead of producing an invalid
    button.
    """
    callback = str(callback_data or "").strip()
    if callback.startswith((_BACK_TARGET_PREFIX, "sig_back:", "cw:")):
        return callback
    if callback and callback not in {"nav_back", "cancel_current"}:
        candidate = f"{_BACK_TARGET_PREFIX}{callback}"
        if len(candidate.encode("utf-8")) <= _MAX_CALLBACK_DATA_BYTES:
            return candidate
    return "nav_back"


def canonical_navigation_text(text: str, callback_data: Any = None) -> tuple[str, str] | None:
    """Return canonical visible text and deterministic callback for exits.

    Back and Cancel are deliberately different operations. Back routes to the
    parent menu encoded in the original callback; Cancel terminates the current
    unfinished flow.  This prevents committed actions (for example delegated
    admin permission toggles) from appearing to roll back one screen at a time.
    """
    kind = _navigation_exit_kind(text, callback_data)
    if not kind:
        return None
    lowered = str(text or "").casefold()
    english = "back" in lowered or "cancel" in lowered
    if kind == "cancel":
        return ("✖️ Cancel" if english else "✖️ لغو", "cancel_current")
    return (
        "⬅️ Back" if english else "⬅️ برگشت",
        _encoded_back_callback(callback_data),
    )

def InlineKeyboardButton(text: str, *args: Any, **kwargs: Any) -> TelegramInlineKeyboardButton:
    """Build a Telegram-native themed button with graceful compatibility fallbacks."""
    callback_data = kwargs.get("callback_data")
    rendered_text = str(text)
    # Canonicalize callback *and visible label* at creation time.  This covers
    # direct Telegram sends that do not pass through edit()/reply() and prevents
    # labels such as “میز بازار زنده” from leaking onto the red Back button.
    canonical = canonical_navigation_text(rendered_text, callback_data) if callback_data else None
    if canonical:
        rendered_text, callback_data = canonical
        kwargs["callback_data"] = callback_data
    callback = str(callback_data or "")

    palette_text = rendered_text
    icon_key = _button_icon_key(callback_data, rendered_text)
    custom_emoji_id = _configured_custom_emoji_id(icon_key)
    if custom_emoji_id and not kwargs.get("icon_custom_emoji_id"):
        kwargs["icon_custom_emoji_id"] = custom_emoji_id
        rendered_text = _strip_leading_symbol_token(rendered_text)
    elif icon_key:
        fallback = _UI_FALLBACK_EMOJI[icon_key]
        if not rendered_text.startswith(fallback):
            label = _strip_leading_symbol_token(rendered_text)
            rendered_text = f"{fallback} {label}"

    # The central palette is authoritative. It removes old per-call colors so
    # only the requested blue/green/red states remain.
    style = "primary" if kwargs.get("web_app") is not None else _button_native_style(callback_data, palette_text)
    if style:
        kwargs["style"] = style
    else:
        kwargs.pop("style", None)

    return TelegramInlineKeyboardButton(rendered_text, *args, **kwargs)


_REJECTED_CUSTOM_EMOJI_IDS: set[str] = set()


def _markup_has_custom_emoji(markup: InlineKeyboardMarkup | None) -> bool:
    return bool(
        markup
        and any(
            button.icon_custom_emoji_id
            for row in markup.inline_keyboard
            for button in row
        )
    )


def _markup_has_native_style(markup: InlineKeyboardMarkup | None) -> bool:
    return bool(markup and any(button.style for row in markup.inline_keyboard for button in row))


def _compatible_button(
    button: TelegramInlineKeyboardButton,
    *,
    remove_custom_emoji: bool,
    remove_style: bool,
) -> TelegramInlineKeyboardButton:
    text = button.text
    icon_id = button.icon_custom_emoji_id
    if remove_custom_emoji and icon_id:
        icon_key = _button_icon_key(button.callback_data, text)
        fallback = _UI_FALLBACK_EMOJI.get(icon_key or "")
        if fallback and not text.startswith(fallback):
            text = f"{fallback} {text}"
        icon_id = None

    return TelegramInlineKeyboardButton(
        text=text,
        url=button.url,
        callback_data=button.callback_data,
        switch_inline_query=button.switch_inline_query,
        switch_inline_query_current_chat=button.switch_inline_query_current_chat,
        callback_game=button.callback_game,
        pay=button.pay,
        login_url=button.login_url,
        web_app=button.web_app,
        switch_inline_query_chosen_chat=button.switch_inline_query_chosen_chat,
        copy_text=button.copy_text,
        style=None if remove_style else button.style,
        icon_custom_emoji_id=icon_id,
        api_kwargs=button.api_kwargs or None,
    )


def clone_button_with_text_and_callback(
    button: TelegramInlineKeyboardButton, text: str, callback_data: str
) -> TelegramInlineKeyboardButton:
    """Clone a callback button while replacing its canonical navigation label."""
    return TelegramInlineKeyboardButton(
        text=text,
        url=button.url,
        callback_data=callback_data,
        switch_inline_query=button.switch_inline_query,
        switch_inline_query_current_chat=button.switch_inline_query_current_chat,
        callback_game=button.callback_game,
        pay=button.pay,
        login_url=button.login_url,
        web_app=button.web_app,
        switch_inline_query_chosen_chat=button.switch_inline_query_chosen_chat,
        copy_text=button.copy_text,
        style="danger" if callback_data == "cancel_current" else None,
        icon_custom_emoji_id=None,
        api_kwargs=button.api_kwargs or None,
    )


def clone_button_with_callback(
    button: TelegramInlineKeyboardButton, callback_data: str
) -> TelegramInlineKeyboardButton:
    """Clone an inline button while changing only its callback target.

    Navigation normalization uses this helper so native Telegram style, custom
    emoji, Web App metadata and forward-compatible API fields are preserved.
    """
    return TelegramInlineKeyboardButton(
        text=button.text,
        url=button.url,
        callback_data=callback_data,
        switch_inline_query=button.switch_inline_query,
        switch_inline_query_current_chat=button.switch_inline_query_current_chat,
        callback_game=button.callback_game,
        pay=button.pay,
        login_url=button.login_url,
        web_app=button.web_app,
        switch_inline_query_chosen_chat=button.switch_inline_query_chosen_chat,
        copy_text=button.copy_text,
        style=button.style,
        icon_custom_emoji_id=button.icon_custom_emoji_id,
        api_kwargs=button.api_kwargs or None,
    )


def _compatible_markup(
    markup: InlineKeyboardMarkup | None,
    *,
    remove_custom_emoji: bool = True,
    remove_style: bool = False,
) -> InlineKeyboardMarkup | None:
    if markup is None:
        return None
    return InlineKeyboardMarkup(
        [
            [
                _compatible_button(
                    button,
                    remove_custom_emoji=remove_custom_emoji,
                    remove_style=remove_style,
                )
                for button in row
            ]
            for row in markup.inline_keyboard
        ],
        api_kwargs=markup.api_kwargs or None,
    )


def _disable_rejected_custom_emoji(markup: InlineKeyboardMarkup | None) -> None:
    if markup is None:
        return
    for row in markup.inline_keyboard:
        for button in row:
            if button.icon_custom_emoji_id:
                _REJECTED_CUSTOM_EMOJI_IDS.add(button.icon_custom_emoji_id)


async def _telegram_request_with_button_fallback(method: Any, /, *args: Any, **kwargs: Any) -> Any:
    """Retry a rejected Telegram keyboard without optional enhanced fields.

    Telegram rejects the whole request when a custom emoji ID is invalid or the
    bot/account is not allowed to use it. A 400/BadRequest is safe to retry, as
    Telegram did not apply the original request. Network errors are deliberately
    not retried here to avoid duplicate messages.
    """
    markup = kwargs.get("reply_markup")
    has_custom_emoji = _markup_has_custom_emoji(markup)
    has_style = _markup_has_native_style(markup)
    try:
        return await method(*args, **kwargs)
    except BadRequest as exc:
        if not has_custom_emoji and not has_style:
            raise

        if has_custom_emoji:
            _disable_rejected_custom_emoji(markup)
            kwargs["reply_markup"] = _compatible_markup(
                markup,
                remove_custom_emoji=True,
                remove_style=False,
            )
            logger.warning(
                "Telegram rejected custom button emoji; retrying with Unicode fallback: %s",
                exc,
            )
            try:
                return await method(*args, **kwargs)
            except BadRequest as fallback_exc:
                if not has_style:
                    raise
                exc = fallback_exc
                markup = kwargs.get("reply_markup")

        kwargs["reply_markup"] = _compatible_markup(
            markup,
            remove_custom_emoji=True,
            remove_style=True,
        )
        logger.warning(
            "Telegram rejected native button styling; retrying with plain compatible buttons: %s",
            exc,
        )
        return await method(*args, **kwargs)

__all__ = ["InlineKeyboardButton", "state_button", "clone_button_with_callback", "clone_button_with_text_and_callback", "canonical_navigation_text", "telegram_request_with_button_fallback"]

# Public alias with a stable non-private name for new modules.
telegram_request_with_button_fallback = _telegram_request_with_button_fallback
