#property copyright "SENTINEL"
#property version   "1.01"
#property strict
#property description "Read-only MetaTrader 5 connector for SENTINEL Prop Guardian and Risk Coach"

input string InpSentinelApiUrl       = "https://worker-production-ee71.up.railway.app";
input string InpPairingCode          = "";
input int    InpSyncIntervalSeconds  = 5;
input int    InpHistoryDays          = 30;
input int    InpHistorySyncMinutes   = 1;
input bool   InpReadOnlyMode         = true;

#define CONNECTOR_VERSION "1.01"
#define HTTP_TIMEOUT_MS 10000

string g_connector_id = "";
string g_device_token = "";
string g_connector_secret = "";
string g_api_url = "";
string g_credentials_file = "Sentinel\\mt5_connector_credentials.txt";
bool   g_pairing_attempted = false;
string g_pending_events[];
int    g_timer_cycles = 0;

string TrimRightSlash(string value)
{
   while(StringLen(value) > 0 && StringSubstr(value, StringLen(value)-1, 1) == "/")
      value = StringSubstr(value, 0, StringLen(value)-1);
   return value;
}

string JsonEscape(string value)
{
   StringReplace(value, "\\", "\\\\");
   StringReplace(value, "\"", "\\\"");
   StringReplace(value, "\r", "\\r");
   StringReplace(value, "\n", "\\n");
   StringReplace(value, "\t", "\\t");
   return value;
}

string JsonString(string value) { return "\"" + JsonEscape(value) + "\""; }
string JsonBool(bool value) { return value ? "true" : "false"; }

string IsoTime(datetime value)
{
   MqlDateTime parts;
   TimeToStruct(value, parts);
   return StringFormat("%04d-%02d-%02dT%02d:%02d:%02dZ", parts.year, parts.mon, parts.day, parts.hour, parts.min, parts.sec);
}

string JsonGetString(const string json, const string key)
{
   string marker = "\"" + key + "\"";
   int key_pos = StringFind(json, marker);
   if(key_pos < 0) return "";
   int colon = StringFind(json, ":", key_pos + StringLen(marker));
   if(colon < 0) return "";
   int start = StringFind(json, "\"", colon + 1);
   if(start < 0) return "";
   start++;
   string output = "";
   bool escaped = false;
   for(int i=start; i<StringLen(json); i++)
   {
      string ch = StringSubstr(json, i, 1);
      if(escaped)
      {
         if(ch == "n") output += "\n";
         else if(ch == "r") output += "\r";
         else if(ch == "t") output += "\t";
         else output += ch;
         escaped = false;
      }
      else if(ch == "\\") escaped = true;
      else if(ch == "\"") return output;
      else output += ch;
   }
   return "";
}

void StringToUChar(const string text, uchar &output[])
{
   ArrayResize(output, 0);
   int copied = StringToCharArray(text, output, 0, WHOLE_ARRAY, CP_UTF8);
   if(copied > 0 && ArraySize(output) > 0 && output[ArraySize(output)-1] == 0)
      ArrayResize(output, ArraySize(output)-1);
}

string BytesToHex(const uchar &data[])
{
   string output = "";
   for(int i=0; i<ArraySize(data); i++)
      output += StringFormat("%02x", (int)data[i]);
   return output;
}

bool Sha256Bytes(const uchar &data[], uchar &digest[])
{
   uchar empty_key[];
   ArrayResize(empty_key, 0);
   ArrayResize(digest, 0);
   return CryptEncode(CRYPT_HASH_SHA256, data, empty_key, digest) > 0;
}

string Sha256Hex(const string text)
{
   uchar data[], digest[];
   StringToUChar(text, data);
   if(!Sha256Bytes(data, digest)) return "";
   return BytesToHex(digest);
}

string HmacSha256Hex(const string secret, const string message)
{
   uchar key[], msg[];
   StringToUChar(secret, key);
   StringToUChar(message, msg);
   const int block_size = 64;
   if(ArraySize(key) > block_size)
   {
      uchar key_hash[];
      if(!Sha256Bytes(key, key_hash)) return "";
      ArrayResize(key, ArraySize(key_hash));
      ArrayCopy(key, key_hash);
   }
   uchar padded[];
   ArrayResize(padded, block_size);
   ArrayInitialize(padded, 0);
   for(int i=0; i<ArraySize(key) && i<block_size; i++) padded[i] = key[i];
   uchar inner[], outer[];
   ArrayResize(inner, block_size + ArraySize(msg));
   ArrayResize(outer, block_size + 32);
   for(int i=0; i<block_size; i++)
   {
      inner[i] = (uchar)(padded[i] ^ 0x36);
      outer[i] = (uchar)(padded[i] ^ 0x5c);
   }
   for(int j=0; j<ArraySize(msg); j++) inner[block_size+j] = msg[j];
   uchar inner_hash[];
   if(!Sha256Bytes(inner, inner_hash)) return "";
   ArrayResize(outer, block_size + ArraySize(inner_hash));
   for(int k=0; k<ArraySize(inner_hash); k++) outer[block_size+k] = inner_hash[k];
   uchar final_hash[];
   if(!Sha256Bytes(outer, final_hash)) return "";
   return BytesToHex(final_hash);
}

string MakeNonce()
{
   return StringFormat("%I64d-%u-%u", (long)TimeLocal(), GetTickCount(), (uint)MathRand());
}

bool SaveCredentials()
{
   FolderCreate("Sentinel");
   int handle = FileOpen(g_credentials_file, FILE_WRITE|FILE_TXT|FILE_ANSI);
   if(handle == INVALID_HANDLE) return false;
   FileWrite(handle, g_connector_id);
   FileWrite(handle, g_device_token);
   FileWrite(handle, g_connector_secret);
   FileClose(handle);
   return true;
}

bool LoadCredentials()
{
   int handle = FileOpen(g_credentials_file, FILE_READ|FILE_TXT|FILE_ANSI);
   if(handle == INVALID_HANDLE) return false;
   g_connector_id = FileReadString(handle);
   g_device_token = FileReadString(handle);
   g_connector_secret = FileReadString(handle);
   FileClose(handle);
   return StringLen(g_connector_id) > 0 && StringLen(g_device_token) > 0 && StringLen(g_connector_secret) > 0;
}

int HttpPost(const string endpoint, const string body, const string headers, string &response)
{
   char data[], result[];
   StringToCharArray(body, data, 0, WHOLE_ARRAY, CP_UTF8);
   if(ArraySize(data) > 0 && data[ArraySize(data)-1] == 0) ArrayResize(data, ArraySize(data)-1);
   string response_headers = "";
   ResetLastError();
   int code = WebRequest("POST", g_api_url + endpoint, headers, HTTP_TIMEOUT_MS, data, result, response_headers);
   if(code == -1)
   {
      Print("SENTINEL WebRequest failed. Error=", GetLastError(), ". Add ", g_api_url, " to allowed WebRequest URLs.");
      return -1;
   }
   response = CharArrayToString(result, 0, WHOLE_ARRAY, CP_UTF8);
   return code;
}

bool PairConnector()
{
   if(StringLen(InpPairingCode) < 8) return false;
   string payload = "{";
   payload += "\"pairing_code\":" + JsonString(InpPairingCode) + ",";
   payload += "\"platform\":\"MT5\",";
   payload += "\"account_login\":" + JsonString((string)AccountInfoInteger(ACCOUNT_LOGIN)) + ",";
   payload += "\"broker\":" + JsonString(AccountInfoString(ACCOUNT_COMPANY)) + ",";
   payload += "\"server_name\":" + JsonString(AccountInfoString(ACCOUNT_SERVER)) + ",";
   payload += "\"account_name\":" + JsonString(AccountInfoString(ACCOUNT_NAME)) + ",";
   payload += "\"terminal_build\":" + JsonString((string)TerminalInfoInteger(TERMINAL_BUILD)) + ",";
   payload += "\"connector_version\":" + JsonString(CONNECTOR_VERSION) + ",";
   payload += "\"readonly_mode\":" + JsonBool(InpReadOnlyMode);
   payload += "}";
   string response = "";
   int code = HttpPost("/api/v1/mt5/pair", payload, "Content-Type: application/json\r\n", response);
   if(code < 200 || code >= 300)
   {
      Print("SENTINEL pairing failed HTTP=", code, " response=", response);
      return false;
   }
   g_connector_id = JsonGetString(response, "connector_id");
   g_device_token = JsonGetString(response, "device_token");
   g_connector_secret = JsonGetString(response, "connector_secret");
   if(!SaveCredentials())
   {
      Print("SENTINEL could not save connector credentials. Error=", GetLastError());
      return false;
   }
   Print("SENTINEL MT5 connector paired successfully. Connector=", g_connector_id);
   return true;
}

string BuildSignedHeaders(const string body)
{
   string timestamp = (string)(long)TimeGMT();
   string nonce = MakeNonce();
   string material = timestamp + "\n" + nonce + "\n" + Sha256Hex(body);
   string signature = HmacSha256Hex(g_connector_secret, material);
   string headers = "Content-Type: application/json\r\n";
   headers += "X-Sentinel-Connector: " + g_connector_id + "\r\n";
   headers += "X-Sentinel-Token: " + g_device_token + "\r\n";
   headers += "X-Sentinel-Timestamp: " + timestamp + "\r\n";
   headers += "X-Sentinel-Nonce: " + nonce + "\r\n";
   headers += "X-Sentinel-Signature: " + signature + "\r\n";
   return headers;
}

string PositionSide(ENUM_POSITION_TYPE type)
{
   return type == POSITION_TYPE_SELL ? "SELL" : "BUY";
}

string BuildPositionsJson()
{
   string output = "[";
   bool first = true;
   int total = PositionsTotal();
   for(int i=0; i<total; i++)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0 || !PositionSelectByTicket(ticket)) continue;
      string symbol = PositionGetString(POSITION_SYMBOL);
      ENUM_POSITION_TYPE type = (ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE);
      double volume = PositionGetDouble(POSITION_VOLUME);
      double entry = PositionGetDouble(POSITION_PRICE_OPEN);
      double current = PositionGetDouble(POSITION_PRICE_CURRENT);
      double sl = PositionGetDouble(POSITION_SL);
      double tp = PositionGetDouble(POSITION_TP);
      double profit = PositionGetDouble(POSITION_PROFIT);
      double swap = PositionGetDouble(POSITION_SWAP);
      double risk_money = 0.0;
      if(sl > 0.0 && entry > 0.0)
      {
         double estimated = 0.0;
         ENUM_ORDER_TYPE order_type = type == POSITION_TYPE_SELL ? ORDER_TYPE_SELL : ORDER_TYPE_BUY;
         if(OrderCalcProfit(order_type, symbol, volume, entry, sl, estimated)) risk_money = MathAbs(estimated);
      }
      if(!first) output += ",";
      first = false;
      output += "{";
      output += "\"ticket\":" + JsonString((string)ticket) + ",";
      output += "\"identifier\":" + JsonString((string)PositionGetInteger(POSITION_IDENTIFIER)) + ",";
      output += "\"symbol\":" + JsonString(symbol) + ",";
      output += "\"side\":" + JsonString(PositionSide(type)) + ",";
      output += "\"volume\":" + DoubleToString(volume, 8) + ",";
      output += "\"price_open\":" + DoubleToString(entry, (int)SymbolInfoInteger(symbol, SYMBOL_DIGITS)) + ",";
      output += "\"price_current\":" + DoubleToString(current, (int)SymbolInfoInteger(symbol, SYMBOL_DIGITS)) + ",";
      output += "\"sl\":" + DoubleToString(sl, (int)SymbolInfoInteger(symbol, SYMBOL_DIGITS)) + ",";
      output += "\"tp\":" + DoubleToString(tp, (int)SymbolInfoInteger(symbol, SYMBOL_DIGITS)) + ",";
      output += "\"profit\":" + DoubleToString(profit, 2) + ",";
      output += "\"swap\":" + DoubleToString(swap, 2) + ",";
      output += "\"commission\":0,";
      output += "\"risk_money\":" + DoubleToString(risk_money, 2) + ",";
      output += "\"opened_at\":" + JsonString(IsoTime((datetime)PositionGetInteger(POSITION_TIME)));
      output += "}";
   }
   output += "]";
   return output;
}

string DealSide(long type)
{
   return type == DEAL_TYPE_SELL ? "SELL" : "BUY";
}

string BuildDealsJson()
{
   string output = "[";
   bool first = true;
   datetime to = TimeCurrent();
   datetime from = to - (datetime)(MathMax(1, MathMin(InpHistoryDays, 365)) * 86400);
   if(!HistorySelect(from, to)) return "[]";
   int total = HistoryDealsTotal();
   int start = MathMax(0, total - 500);
   for(int i=start; i<total; i++)
   {
      ulong ticket = HistoryDealGetTicket(i);
      if(ticket == 0) continue;
      long entry_kind = HistoryDealGetInteger(ticket, DEAL_ENTRY);
      if(entry_kind != DEAL_ENTRY_OUT && entry_kind != DEAL_ENTRY_OUT_BY) continue;
      string symbol = HistoryDealGetString(ticket, DEAL_SYMBOL);
      if(!first) output += ",";
      first = false;
      output += "{";
      output += "\"ticket\":" + JsonString((string)ticket) + ",";
      output += "\"position_id\":" + JsonString((string)HistoryDealGetInteger(ticket, DEAL_POSITION_ID)) + ",";
      output += "\"symbol\":" + JsonString(symbol) + ",";
      output += "\"side\":" + JsonString(DealSide(HistoryDealGetInteger(ticket, DEAL_TYPE))) + ",";
      output += "\"entry_kind\":\"out\",";
      output += "\"volume\":" + DoubleToString(HistoryDealGetDouble(ticket, DEAL_VOLUME), 8) + ",";
      output += "\"price\":" + DoubleToString(HistoryDealGetDouble(ticket, DEAL_PRICE), (int)SymbolInfoInteger(symbol, SYMBOL_DIGITS)) + ",";
      output += "\"profit\":" + DoubleToString(HistoryDealGetDouble(ticket, DEAL_PROFIT), 2) + ",";
      output += "\"commission\":" + DoubleToString(HistoryDealGetDouble(ticket, DEAL_COMMISSION), 2) + ",";
      output += "\"swap\":" + DoubleToString(HistoryDealGetDouble(ticket, DEAL_SWAP), 2) + ",";
      output += "\"fee\":" + DoubleToString(HistoryDealGetDouble(ticket, DEAL_FEE), 2) + ",";
      output += "\"comment\":" + JsonString(HistoryDealGetString(ticket, DEAL_COMMENT)) + ",";
      output += "\"time\":" + JsonString(IsoTime((datetime)HistoryDealGetInteger(ticket, DEAL_TIME)));
      output += "}";
   }
   output += "]";
   return output;
}

string BuildSnapshotJson(const string reason)
{
   string output = "{";
   output += "\"observed_at\":" + JsonString(IsoTime(TimeGMT())) + ",";
   output += "\"reason\":" + JsonString(reason) + ",";
   output += "\"account\":{";
   output += "\"login\":" + JsonString((string)AccountInfoInteger(ACCOUNT_LOGIN)) + ",";
   output += "\"server\":" + JsonString(AccountInfoString(ACCOUNT_SERVER)) + ",";
   output += "\"company\":" + JsonString(AccountInfoString(ACCOUNT_COMPANY)) + ",";
   output += "\"name\":" + JsonString(AccountInfoString(ACCOUNT_NAME)) + ",";
   output += "\"currency\":" + JsonString(AccountInfoString(ACCOUNT_CURRENCY)) + ",";
   output += "\"balance\":" + DoubleToString(AccountInfoDouble(ACCOUNT_BALANCE), 2) + ",";
   output += "\"equity\":" + DoubleToString(AccountInfoDouble(ACCOUNT_EQUITY), 2) + ",";
   output += "\"profit\":" + DoubleToString(AccountInfoDouble(ACCOUNT_PROFIT), 2) + ",";
   output += "\"margin\":" + DoubleToString(AccountInfoDouble(ACCOUNT_MARGIN), 2) + ",";
   output += "\"free_margin\":" + DoubleToString(AccountInfoDouble(ACCOUNT_MARGIN_FREE), 2) + ",";
   output += "\"margin_level\":" + DoubleToString(AccountInfoDouble(ACCOUNT_MARGIN_LEVEL), 2) + ",";
   output += "\"leverage\":" + (string)AccountInfoInteger(ACCOUNT_LEVERAGE);
   output += "},";
   output += "\"terminal\":{";
   output += "\"connector_version\":" + JsonString(CONNECTOR_VERSION) + ",";
   output += "\"build\":" + JsonString((string)TerminalInfoInteger(TERMINAL_BUILD)) + ",";
   output += "\"connected\":" + JsonBool(TerminalInfoInteger(TERMINAL_CONNECTED) != 0) + ",";
   output += "\"trade_allowed\":" + JsonBool(TerminalInfoInteger(TERMINAL_TRADE_ALLOWED) != 0) + ",";
   output += "\"readonly_mode\":" + JsonBool(InpReadOnlyMode);
   output += "},";
   output += "\"positions\":" + BuildPositionsJson() + ",";
   int history_cycle_seconds = MathMax(60, MathMin(InpHistorySyncMinutes, 60) * 60);
   int timer_seconds = MathMax(3, MathMin(InpSyncIntervalSeconds, 60));
   int history_every_cycles = MathMax(1, history_cycle_seconds / timer_seconds);
   bool include_history = reason != "timer" || (g_timer_cycles % history_every_cycles) == 0;
   output += "\"deals\":" + (include_history ? BuildDealsJson() : "[]");
   output += "}";
   return output;
}

bool SendSnapshot(const string reason)
{
   if(StringLen(g_connector_id) == 0 && !LoadCredentials()) return false;
   string body = BuildSnapshotJson(reason);
   string response = "";
   int code = HttpPost("/api/v1/mt5/snapshot", body, BuildSignedHeaders(body), response);
   if(code >= 200 && code < 300) return true;
   Print("SENTINEL snapshot failed HTTP=", code, " response=", response);
   return false;
}

string BuildTradeEventJson(const MqlTradeTransaction &trans)
{
   string body = "{";
   body += "\"external_id\":" + JsonString((string)trans.deal + "-" + (string)trans.order + "-" + (string)trans.position + "-" + (string)trans.type) + ",";
   body += "\"event_type\":\"trade_transaction\",";
   body += "\"occurred_at\":" + JsonString(IsoTime(TimeGMT())) + ",";
   body += "\"transaction_type\":" + JsonString((string)trans.type) + ",";
   body += "\"deal\":" + JsonString((string)trans.deal) + ",";
   body += "\"order\":" + JsonString((string)trans.order) + ",";
   body += "\"position\":" + JsonString((string)trans.position) + ",";
   body += "\"symbol\":" + JsonString(trans.symbol) + ",";
   body += "\"volume\":" + DoubleToString(trans.volume, 8) + ",";
   body += "\"price\":" + DoubleToString(trans.price, 8) + ",";
   body += "\"price_sl\":" + DoubleToString(trans.price_sl, 8) + ",";
   body += "\"price_tp\":" + DoubleToString(trans.price_tp, 8);
   body += "}";
   return body;
}

void QueueTradeEvent(const MqlTradeTransaction &trans)
{
   const int maximum = 100;
   int size = ArraySize(g_pending_events);
   if(size >= maximum)
   {
      for(int i=1; i<size; i++) g_pending_events[i-1] = g_pending_events[i];
      ArrayResize(g_pending_events, size-1);
      size--;
      Print("SENTINEL pending event queue was full; the oldest event was replaced.");
   }
   ArrayResize(g_pending_events, size+1);
   g_pending_events[size] = BuildTradeEventJson(trans);
}

bool FlushTradeEvents()
{
   if(StringLen(g_connector_id) == 0 && !LoadCredentials()) return false;
   int sent = 0;
   while(ArraySize(g_pending_events) > 0 && sent < 20)
   {
      string body = g_pending_events[0];
      string response = "";
      int code = HttpPost("/api/v1/mt5/event", body, BuildSignedHeaders(body), response);
      if(code < 200 || code >= 300)
      {
         Print("SENTINEL trade event upload failed HTTP=", code, " response=", response);
         return false;
      }
      int size = ArraySize(g_pending_events);
      for(int i=1; i<size; i++) g_pending_events[i-1] = g_pending_events[i];
      ArrayResize(g_pending_events, size-1);
      sent++;
   }
   return true;
}

int OnInit()
{
   MathSrand((uint)GetTickCount());
   g_api_url = TrimRightSlash(InpSentinelApiUrl);
   if(StringFind(g_api_url, "https://") != 0)
   {
      Print("SENTINEL requires an HTTPS API URL.");
      return INIT_PARAMETERS_INCORRECT;
   }
   if(!InpReadOnlyMode)
   {
      Print("SENTINEL connector v1 is read-only. Set ReadOnlyMode=true.");
      return INIT_PARAMETERS_INCORRECT;
   }
   if(!LoadCredentials())
   {
      g_pairing_attempted = true;
      if(!PairConnector())
         Print("SENTINEL is waiting for a valid one-time pairing code.");
   }
   EventSetTimer(MathMax(3, MathMin(InpSyncIntervalSeconds, 60)));
   if(StringLen(g_connector_id) > 0) SendSnapshot("init");
   return INIT_SUCCEEDED;
}

void OnDeinit(const int reason)
{
   EventKillTimer();
}

void OnTimer()
{
   g_timer_cycles++;
   if(StringLen(g_connector_id) == 0)
   {
      if(!g_pairing_attempted && StringLen(InpPairingCode) >= 8)
      {
         g_pairing_attempted = true;
         PairConnector();
      }
      return;
   }
   FlushTradeEvents();
   SendSnapshot("timer");
}

void OnTradeTransaction(
   const MqlTradeTransaction &trans,
   const MqlTradeRequest &request,
   const MqlTradeResult &result
)
{
   // Never perform synchronous networking inside the trade-transaction
   // handler. MetaTrader continues receiving trade events while this handler
   // runs, so the event is queued and uploaded by OnTimer instead.
   QueueTradeEvent(trans);
}
