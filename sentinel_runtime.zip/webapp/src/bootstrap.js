async function handleClick(e) { const el = e.target.closest('button,[data-page-target],[data-open]'); if (!el)
    return; if (el.dataset.authRetry !== undefined) {
    await retryTelegramAuthentication();
    return;
} if (el.dataset.closeApp !== undefined) {
    releaseTelegramNavigation(true);
    tg?.close?.();
    return;
} if (el.dataset.loadMore) {
    await loadMore(el.dataset.loadMore);
    return;
} if (el.dataset.pageTarget) {
    await navigate(el.dataset.pageTarget);
    return;
} if (el.dataset.open) {
    await openMore(el.dataset.open);
    return;
} if (el.dataset.featureDisabled !== undefined) {
    featureDisabledModal();
    return;
} if (el.dataset.closeModal !== undefined) {
    closeModal();
    return;
} if (el.dataset.modalAction !== undefined) {
    const a = state.modalActions?.[Number(el.dataset.modalAction)];
    await a?.action?.();
    return;
} if (el.dataset.signalReplay) {
    await signalReplayModal(el.dataset.signalReplay);
    return;
} if (el.dataset.signalShare) {
    await shareSignalCard(el.dataset.signalShare);
    return;
} if (el.dataset.signalDetail) {
    await openSignal(el.dataset.signalDetail);
    return;
} if (el.dataset.copySignal) {
    copySignal(el.dataset.copySignal);
    return;
} if (el.dataset.signalFilter) {
    state.signalFilter = el.dataset.signalFilter;
    invalidate('signals');
    await renderSignals(true);
    return;
} if (el.dataset.retry) {
    invalidate(el.dataset.retry);
    if(el.dataset.retry==='rewards')invalidate('hub');
    await navigate(state.page, false);
    return;
} if (el.dataset.reload !== undefined) {
    location.reload();
    return;
} if (el.dataset.journalFilter) {
    state.journalFilter = el.dataset.journalFilter;
    invalidate('journal');
    await renderJournal(true);
    return;
} if (el.dataset.orderFilter) {
    state.orderFilter = el.dataset.orderFilter;
    invalidate('orders');
    await loadResource('orders', true);
    ordersModal();
    return;
} if (el.dataset.ticketFilter) {
    state.ticketFilter = el.dataset.ticketFilter;
    invalidate('tickets');
    await loadResource('tickets', true);
    supportModal();
    return;
} if (el.dataset.accountSelect) {
    state.selectedAccount = el.dataset.accountSelect;
    invalidate('risk');
    await renderRisk(true);
    return;
} if (el.dataset.accountEdit) {
    accountModal(el.dataset.accountEdit);
    return;
} if (el.dataset.brokerSync) {
    setBusy(true);
    try {
        await action('broker_snapshot_sync', { account_id: el.dataset.brokerSync }, false);
        invalidate('risk', 'overview');
        await Promise.all([loadResource('risk', true), loadOverview(true)]);
        renderChrome();
        await renderRisk();
        toast(state.lang === 'fa' ? 'اطلاعات فقط‌خواندنی بروکر همگام شد' : 'Read-only broker data synchronized');
    }
    catch (err) {
        toast(err.message, 'error');
    }
    finally {
        setBusy(false);
    }
    return;
 } if (el.dataset.mt5Pair) {
    mt5PairModal(el.dataset.mt5Pair);
    return;
} if (el.dataset.mt5Revoke) {
    if (!confirm(state.lang === 'fa' ? 'اتصال این متاتریدر قطع شود؟' : 'Revoke this MetaTrader connection?')) return;
    setBusy(true);
    try { await action('mt5_connector_revoke', {connector_id: el.dataset.mt5Revoke}, false); invalidate('risk','expansion'); await renderRisk(true); toast(t('success')); }
    catch(err) { toast(err.message,'error'); }
    finally { setBusy(false); }
    return;
} if (el.dataset.riskPlan) {
    riskPlanModal(el.dataset.riskPlan);
    return;
} if (el.dataset.riskPlanAccept) {
    setBusy(true);
    try { await action('risk_daily_plan_accept', {account_id: el.dataset.riskPlanAccept}, false); invalidate('risk','expansion'); await renderRisk(true); toast(t('success')); }
    catch(err) { toast(err.message,'error'); }
    finally { setBusy(false); }
    return;
} if (el.dataset.riskCheckin) {
    riskCheckinModal(el.dataset.riskCheckin);
    return;
} if (el.dataset.positionClose) {
    closePositionModal(el.dataset.positionClose);
    return;
} if (el.dataset.journalNew !== undefined) {
    journalNewModal();
    return;
} if (el.dataset.journalClose) {
    journalCloseModal(el.dataset.journalClose, false);
    return;
} if (el.dataset.journalPartial) {
    journalCloseModal(el.dataset.journalPartial, true);
    return;
} if (el.dataset.journalArchive) {
    setBusy(true);
    try {
        await action('journal_delete', { id: el.dataset.journalArchive }, false);
        invalidate('journal');
        await loadResource('journal', true);
        renderJournal();
        toast(t('archived'));
    }
    catch (err) {
        toast(err.message, 'error');
    }
    finally {
        setBusy(false);
    }
    return;
} if (el.dataset.journalExport !== undefined) {
    exportJournal();
    return;
} if (el.dataset.journalPdf !== undefined) {
    await downloadJournalPdf();
    return;
} if (el.dataset.journalImport !== undefined) {
    importJournal();
    return;
} if (el.dataset.brokerImport !== undefined) {
    importBroker();
    return;
} if (el.dataset.watchAdd !== undefined) {
    const symbol = $('#watchSymbol').value.trim();
    if (!symbol)
        return;
    setBusy(true);
    try {
        await action('watchlist_toggle', { symbol }, false);
        invalidate('market');
        await loadResource('market', true);
        marketModal();
        toast(t('success'));
    }
    catch (err) {
        toast(err.message, 'error');
    }
    finally {
        setBusy(false);
    }
    return;
} if (el.dataset.marketRefresh !== undefined) {
    setBusy(true);
    try {
        invalidate('market');
        await loadResource('market', true);
        marketModal();
        toast(t('refreshDone'));
    }
    catch (err) {
        toast(err.message, 'error');
    }
    finally {
        setBusy(false);
    }
    return;
} if (el.dataset.watchRemove || el.dataset.watchQuick) {
    const symbol = el.dataset.watchRemove || el.dataset.watchQuick;
    if (!symbol)
        return;
    setBusy(true);
    try {
        await action('watchlist_toggle', { symbol }, false);
        invalidate('market');
        await loadResource('market', true);
        marketModal();
        toast(t('success'));
    }
    catch (err) {
        toast(err.message, 'error');
    }
    finally {
        setBusy(false);
    }
    return;
} if (el.dataset.calendarSettings !== undefined) {
    calendarPreferencesModal();
    return;
} if (el.dataset.revisionAck) {
    setBusy(true);
    try {
        await action('revision_ack', { signal_id: el.dataset.revisionAck, revision: Number(el.dataset.revision) }, false);
        invalidate('revisions', 'overview');
        await Promise.all([loadResource('revisions', true), loadOverview(true)]);
        renderChrome();
        revisionsModal();
        toast(t('success'));
    }
    catch (err) {
        toast(err.message, 'error');
    }
    finally {
        setBusy(false);
    }
    return;
} if (el.dataset.planCheckout) {
    checkoutModal(el.dataset.planCheckout);
    return;
} if (el.dataset.orderSubmit !== undefined) {
    await submitOrder();
    return;
} if (el.dataset.orderDetail) {
    await orderDetailModal(el.dataset.orderDetail);
    return;
} if (el.dataset.orderResubmit) {
    orderResubmitModal(el.dataset.orderResubmit);
    return;
} if (el.dataset.orderCancel) {
    setBusy(true);
    try {
        await action('vip_order_cancel', { order_id: el.dataset.orderCancel, reason: 'user_cancelled' }, false);
        invalidate('orders');
        await loadResource('orders', true);
        ordersModal();
        toast(t('success'));
    }
    catch (err) {
        toast(err.message, 'error');
    }
    finally {
        setBusy(false);
    }
    return;
} if (el.dataset.searchTarget) {
    const target = el.dataset.searchTarget;
    closeModal();
    if (target.startsWith('signal:'))
        await openSignal(target.split(':')[1]);
    else if (target.startsWith('ticket:'))
        await ticketDetail(target.split(':')[1]);
    else if (['orders', 'support', 'market', 'calendar', 'track', 'revisions'].includes(target))
        await openMore(target);
    else if (['home', 'signals', 'risk', 'journal', 'more'].includes(target))
        await navigate(target);
    return;
} if (el.dataset.ticketNew !== undefined) {
    ticketNewModal();
    return;
} if (el.dataset.ticketDetail) {
    await ticketDetail(el.dataset.ticketDetail);
    return;
} if (el.dataset.ticketReply) {
    const id = el.dataset.ticketReply, text = $('#ticketReply').value.trim();
    if (!text)
        return;
    setBusy(true);
    try {
        await action('ticket_reply', { ticket_id: id, text }, false);
        invalidate('tickets', 'overview');
        await Promise.all([loadResource('tickets', true), loadOverview(true)]);
        await ticketDetail(id);
        toast(t('success'));
    }
    catch (err) {
        toast(err.message, 'error');
    }
    finally {
        setBusy(false);
    }
    return;
} if (el.dataset.ticketStatus) {
    const id = el.dataset.ticketStatus, status = el.dataset.status;
    setBusy(true);
    try {
        await action('ticket_status_update', { ticket_id: id, status }, false);
        invalidate('tickets', 'overview');
        await Promise.all([loadResource('tickets', true), loadOverview(true)]);
        await ticketDetail(id);
        toast(t('success'));
    }
    catch (err) {
        toast(err.message, 'error');
    }
    finally {
        setBusy(false);
    }
    return;
} if (el.dataset.miniappToggle) {
    const enabled = el.dataset.miniappToggle === 'on';
    setBusy(true);
    try {
        await action('miniapp_runtime_toggle', { enabled, reason: 'admin_miniapp_workspace' }, false);
        closeModal();
        invalidate('overview', 'adminOps');
        await loadOverview(true);
        await adminWorkspace();
        toast(t('success'));
    }
    catch (err) {
        toast(err.message, 'error');
    }
    finally {
        setBusy(false);
    }
    return;
} if (el.dataset.integrationReconcile !== undefined) {
    setBusy(true);
    try {
        await action('integration_reconcile', { reason: 'admin_miniapp_workspace' }, false);
        invalidate('adminIntegration', 'signals', 'orders', 'market', 'overview');
        closeModal();
        await Promise.all([loadOverview(true), loadResource('adminIntegration', true)]);
        await adminWorkspace();
        toast(state.lang === 'fa' ? 'اطلاعات مشترک ربات و مینی‌اپ دوباره تطبیق داده شد.' : 'Bot and Mini App shared data reconciled.');
    }
    catch (err) {
        toast(err.message, 'error');
    }
    finally {
        setBusy(false);
    }
    return;
} if (el.dataset.adminPayments !== undefined) {
    state.adminPaymentFilter = state.adminPaymentFilter || 'pending';
    await adminPaymentsModal(true);
    return;
} if (el.dataset.adminPaymentFilter) {
    state.adminPaymentFilter = el.dataset.adminPaymentFilter;
    await adminPaymentsModal(false);
    return;
} if (el.dataset.adminOrder) {
    await adminOrderDetail(el.dataset.adminOrder);
    return;
} if (el.dataset.adminOrderApprove) {
    setBusy(true);
    try {
        await action('payment_approve', { order_id: el.dataset.adminOrderApprove }, false);
        closeModal();
        invalidate('adminOrders', 'orders', 'overview');
        await Promise.all([loadOverview(true), loadResource('adminOrders', true)]);
        await adminPaymentsModal(false);
        toast(t('success'));
    }
    catch (err) {
        toast(err.message, 'error');
    }
    finally {
        setBusy(false);
    }
    return;
} if (el.dataset.adminOrderReject) {
    adminOrderRejectModal(el.dataset.adminOrderReject);
    return;
} if (el.dataset.adminTicket) {
    await adminTicketDetail(el.dataset.adminTicket);
    return;
} if (el.dataset.adminTicketReply) {
    const id = el.dataset.adminTicketReply, text = $('#adminTicketReply').value.trim();
    if (!text)
        return;
    setBusy(true);
    try {
        await action('ticket_admin_reply', { ticket_id: id, text }, false);
        invalidate('adminTickets', 'tickets', 'overview');
        await Promise.all([loadResource('adminTickets', true), loadOverview(true)]);
        await adminTicketDetail(id);
        toast(t('success'));
    }
    catch (err) {
        toast(err.message, 'error');
    }
    finally {
        setBusy(false);
    }
    return;
} if (el.dataset.adminTicketStatus) {
    const id = el.dataset.adminTicketStatus, status = el.dataset.status;
    setBusy(true);
    try {
        await action('ticket_admin_status_update', { ticket_id: id, status }, false);
        invalidate('adminTickets', 'tickets', 'overview');
        await Promise.all([loadResource('adminTickets', true), loadOverview(true)]);
        await adminTicketDetail(id);
        toast(t('success'));
    }
    catch (err) {
        toast(err.message, 'error');
    }
    finally {
        setBusy(false);
    }
    return;
} if (el.dataset.templateUpload) {
    await uploadSignalTemplate(el.dataset.templateUpload);
    return;
} if (el.dataset.templateReset) {
    await resetSignalTemplate(el.dataset.templateReset);
    return;
} if (el.dataset.adminAudit !== undefined) {
    await adminAuditModal();
    return;
} if (el.dataset.propTemplateNew !== undefined) {
    propTemplateCreateModal();
    return;
} if (el.dataset.adminHandoffNew !== undefined) {
    handoffCreateModal();
    return;
} if (el.dataset.handoffStatus) {
    setBusy(true);
    try {
        await action('shift_handoff_status_update', { handoff_id: el.dataset.handoffId, status: el.dataset.handoffStatus }, false);
        closeModal();
        invalidate('adminOps');
        await adminWorkspace();
        toast(t('success'));
    }
    catch (err) {
        toast(err.message, 'error');
    }
    finally {
        setBusy(false);
    }
    return;
} if (el.dataset.experimentNew !== undefined) {
    experimentCreateModal();
    return;
} if (el.dataset.experimentStatus) {
    setBusy(true);
    try {
        await action('experiment_status_update', { experiment_id: el.dataset.experimentId, status: el.dataset.experimentStatus }, false);
        closeModal();
        invalidate('adminExperiments');
        await adminWorkspace();
        toast(t('success'));
    }
    catch (err) {
        toast(err.message, 'error');
    }
    finally {
        setBusy(false);
    }
    return;
} if (el.dataset.languageToggle !== undefined) {
    toggleLanguage();
    closeModal();
    return;
} if (el.dataset.rulesAccept !== undefined) {
    setBusy(true);
    try {
        await action('rules_accept', { language: state.lang }, false);
        await loadOverview(true);
        closeModal();
        toast(t('success'));
    }
    catch (err) {
        toast(err.message, 'error');
    }
    finally {
        setBusy(false);
    }
    return;
} if (el.dataset.appReload !== undefined) {
    try {
        const reg = await navigator.serviceWorker?.getRegistration?.();
        await reg?.update?.();
    }
    catch { }
    location.reload();
    return;
} if (el.dataset.logout !== undefined) {
    await request('./api/v1/auth/logout', { method: 'POST' });
    try { for (const key of Object.keys(sessionStorage)) if (key.startsWith('sentinelDraft:') || key.startsWith('sentinelPending:')) sessionStorage.removeItem(key); } catch {}
    location.reload();
    return;
} }
function handleInput(e) { if (e.target.id === 'signalSearch') {
    state.signalQuery = e.target.value;
    clearTimeout(handleInput.timer);
    handleInput.timer = setTimeout(() => { invalidate('signals'); renderSignals(true); }, 320);
} if (e.target.id === 'journalSearch') {
    state.journalQuery = e.target.value;
    clearTimeout(handleInput.journalTimer);
    handleInput.journalTimer = setTimeout(() => { invalidate('journal'); renderJournal(true); }, 320);
} if (e.target.id === 'globalSearchInput') {
    clearTimeout(handleInput.searchTimer);
    handleInput.searchTimer = setTimeout(() => runGlobalSearch(e.target.value), 260);
} if (['asSymbol', 'asEntries', 'asTargets', 'asStop', 'asSide'].includes(e.target.id)) {
    clearTimeout(handleInput.adminQuoteTimer);
    handleInput.adminQuoteTimer = setTimeout(() => refreshAdminSignalQuote(true), 700);
} }
function bind() { document.addEventListener('click', handleClick); document.addEventListener('input', handleInput); window.addEventListener('pagehide', () => releaseTelegramNavigation(true), { capture: true }); window.addEventListener('beforeunload', () => releaseTelegramNavigation(true), { capture: true }); window.addEventListener('pageshow', () => { installTelegramNavigation(); syncTelegramNavigation(); }, { capture: true }); $('#refreshButton').addEventListener('click', async () => { setBusy(true); try {
    invalidate('overview', state.page, 'feed');
    await Promise.all([loadOverview(true), refreshFeed(false)]);
    if (state.page !== 'home')
        await loadResource(state.page, true);
    renderChrome();
    await navigate(state.page, false);
    toast(t('refreshDone'));
}
catch (err) {
    toast(err.message, 'error');
}
finally {
    setBusy(false);
} }); $('#languageButton').addEventListener('click', toggleLanguage); $('#profileButton').addEventListener('click', settingsModal); $('#revisionButton').addEventListener('click', () => openMore('revisions')); window.addEventListener('online', () => { recoverConnection().catch(() => {}); }); window.addEventListener('offline', () => setConnection('offline')); document.addEventListener('visibilitychange', () => { if (document.hidden) releaseTelegramNavigation(true); else { installTelegramNavigation(); syncTelegramNavigation(); resumeBackgroundVideo(); } if (!document.hidden && state.online && !state.preview)
    syncActiveView().catch(() => { }); }); }
function registerSW() { if (!('serviceWorker' in navigator))
    return; window.addEventListener('load', async () => { try {
    const reg = await navigator.serviceWorker.register(`./sw.js?v=${encodeURIComponent(APP_VERSION)}`, { updateViaCache: 'none' });
    reg.update();
    if (reg.waiting)
        toast(state.lang === 'fa' ? 'نسخه جدید آماده است؛ برنامه را باز کنید.' : 'A new version is ready. Reopen the app.');
}
catch { } }); }
prepareMotionExperience();
bind();
registerSW();
bootstrap();
