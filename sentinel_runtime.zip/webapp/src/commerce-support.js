async function renderMoreLegacy(force = false) { const page = $('#page-more'), o = state.resources.overview || {}; page.innerHTML = pageHead('EXPLORE', t('more'), state.lang === 'fa' ? 'بازار، شفافیت، اعلان، اشتراک و پشتیبانی در یک مرکز.' : 'Market, transparency, notifications, subscription and support in one center.') + `<div class="feature-grid">${feature('search', t('globalSearch'), state.lang === 'fa' ? 'جست‌وجو در تمام داده‌های شخصی' : 'Search all personal data', 'search')}${feature('market', t('market'), state.lang === 'fa' ? 'قیمت‌ها و واچ‌لیست' : 'Quotes and watchlist', 'market')}${feature('calendar', t('calendar'), state.lang === 'fa' ? 'خبرهای مهم هفته' : 'Important events', 'calendar')}${feature('chart', t('trackRecord'), state.lang === 'fa' ? 'آمار واقعی و هش شواهد' : 'Verified performance', 'track')}${feature('bell', t('revisions'), state.lang === 'fa' ? 'تغییرات پوزیشن‌های Taken' : 'Changes to taken signals', 'revisions', o.revision_count || 0)}${feature('bell', t('notifications'), state.lang === 'fa' ? 'فیلتر بازار، ساعات سکوت و خلاصه‌ها' : 'Market filters, quiet hours and digests', 'notifications')}${feature('crown', t('vip'), state.lang === 'fa' ? 'پلن‌ها و پرداخت امن' : 'Plans and secure checkout', 'vip')}${feature('wallet', t('orders'), state.lang === 'fa' ? 'پیگیری، لغو و ارسال مجدد' : 'Track, cancel, resubmit', 'orders')}${feature('support', t('support'), state.lang === 'fa' ? 'تیکت و پاسخ‌ها' : 'Tickets and replies', 'support')}${feature('user', t('settings'), state.lang === 'fa' ? 'زبان، قوانین و نشست' : 'Language, rules, session', 'settings')}${o.admin_available ? feature('shield', t('adminConsole'), state.lang === 'fa' ? 'تحویل شیفت، گزارش روزانه و آزمایش‌های رشد' : 'Handoffs, daily brief and growth experiments', 'admin') : ''}</div>`; }
function searchModal() { openModal('SEARCH', t('globalSearch'), `<div class="search-box">${icon('search')}<label class="sr-only" for="globalSearchInput">${esc(t('globalSearch'))}</label><input id="globalSearchInput" autocomplete="off" placeholder="${esc(t('searchPlaceholder'))}"></div><div id="globalSearchResults" class="search-results">${empty()}</div>`, []); setTimeout(() => $('#globalSearchInput')?.focus(), 50); }
async function runGlobalSearch(query) { const box = $('#globalSearchResults'); if (!box)
    return; if (query.trim().length < 2) {
    box.innerHTML = empty();
    return;
} box.innerHTML = skeleton(2); try {
    const data = await request(`./api/v1/search?q=${encodeURIComponent(query.trim())}&limit=50`);
    box.innerHTML = (data.items || []).map(x => `<button class="search-result" data-search-target="${esc(x.target)}"><span class="status-badge info">${esc(x.type)}</span><span><strong>${esc(x.title)}</strong><small>${esc(x.subtitle || '')}</small></span>${icon('chevron')}</button>`).join('') || empty();
}
catch (err) {
    box.innerHTML = errorPanel(err, 'search');
} }
function notificationModal() { const n = state.resources.overview?.notifications || {}; const keys = [['signals', state.lang === 'fa' ? 'سیگنال‌ها' : 'Signals'], ['results', state.lang === 'fa' ? 'نتایج سیگنال' : 'Signal results'], ['news', state.lang === 'fa' ? 'اخبار مهم' : 'Important news'], ['calendar', t('calendar')], ['support', t('support')], ['alerts', state.lang === 'fa' ? 'هشدار قیمت' : 'Price alerts'], ['daily_digest', state.lang === 'fa' ? 'خلاصه روزانه' : 'Daily digest'], ['weekly_digest', state.lang === 'fa' ? 'خلاصه هفتگی' : 'Weekly digest']]; openModal('NOTIFICATIONS', t('notifications'), `<form id="notificationForm"><div class="toggle-list">${keys.map(([k, label]) => `<label class="toggle-row" for="notify_${k}"><span>${esc(label)}</span><input id="notify_${k}" type="checkbox" ${n[k] !== false ? 'checked' : ''}></label>`).join('')}</div><div class="form-grid"><div class="field"><label for="notifyMarkets">${state.lang === 'fa' ? 'بازارها (forex, crypto)' : 'Markets (forex, crypto)'}</label><input id="notifyMarkets" value="${esc((n.markets || []).join(', '))}"></div><div class="field"><label for="notifySymbols">${state.lang === 'fa' ? 'نمادهای خاص' : 'Specific symbols'}</label><input id="notifySymbols" value="${esc((n.symbols || []).join(', '))}"></div><div class="field"><label for="notifyTimezone">${esc(t('timezone'))}</label><input id="notifyTimezone" value="${esc(n.timezone || 'Asia/Tehran')}"></div><div class="field"><label for="notifyQuietStart">${state.lang === 'fa' ? 'شروع سکوت' : 'Quiet start'}</label><input id="notifyQuietStart" type="time" value="${esc(n.quiet_start || '23:00')}"></div><div class="field"><label for="notifyQuietEnd">${state.lang === 'fa' ? 'پایان سکوت' : 'Quiet end'}</label><input id="notifyQuietEnd" type="time" value="${esc(n.quiet_end || '07:00')}"></div><div class="field"><label for="notifyPause">${state.lang === 'fa' ? 'توقف موقت (ساعت)' : 'Pause for hours'}</label><input id="notifyPause" type="number" min="0" max="8760" value="0"></div></div><label class="check-row" for="notifyQuiet"><input id="notifyQuiet" type="checkbox" ${n.quiet_enabled !== false ? 'checked' : ''}><span>${state.lang === 'fa' ? 'ساعات سکوت فعال' : 'Quiet hours enabled'}</span></label></form>`, [{ label: t('save'), kind: 'primary', action: saveNotifications }]); }
async function saveNotifications() { const form = $('#notificationForm'); if (!form?.reportValidity())
    return; const payload = { markets: $('#notifyMarkets').value.split(',').map(x => x.trim()).filter(Boolean), symbols: $('#notifySymbols').value.split(',').map(x => x.trim()).filter(Boolean), timezone: $('#notifyTimezone').value, quiet_start: $('#notifyQuietStart').value, quiet_end: $('#notifyQuietEnd').value, quiet_enabled: $('#notifyQuiet').checked, pause_hours: Number($('#notifyPause').value || 0) }; ['signals', 'results', 'news', 'calendar', 'support', 'alerts', 'daily_digest', 'weekly_digest'].forEach(k => payload[k] = $(`#notify_${k}`).checked); setBusy(true); try {
    const result = await action('notification_preferences_update', payload, false);
    state.resources.overview.notifications = result;
    toast(t('success'));
    closeModal();
}
catch (err) {
    toast(err.message, 'error');
}
finally {
    setBusy(false);
} }
function feature(ic, title, desc, target, badge = 0) { const enabled = !FEATURE_KEY[target] || featureEnabled(target); return `<button class="feature-tile touch ${enabled ? '' : 'disabled'}" ${enabled ? `data-open="${target}"` : 'data-feature-disabled'} aria-disabled="${enabled ? 'false' : 'true'}">${icon(enabled ? ic : 'lock')}<strong>${esc(title)}</strong><small>${esc(enabled ? desc : t('maintenance'))}</small>${badge ? `<em>${num(badge, 0)}</em>` : ''}</button>`; }
async function openMoreLegacy(target) { if (target === 'settings')
    return settingsModal(); if (target === 'search')
    return searchModal(); if (target === 'notifications')
    return notificationModal(); if (target === 'onboarding')
    return onboardingModal(); if (target === 'admin')
    return adminWorkspace(); if (FEATURE_KEY[target] && !featureEnabled(target))
    return featureDisabledModal(); setBusy(true); try {
    const key = target === 'vip' ? 'overview' : target === 'support' ? 'tickets' : target;
    await loadResource(key);
    ({ market: marketModal, calendar: calendarModal, track: trackModal, revisions: revisionsModal, vip: vipModal, orders: ordersModal, support: supportModal }[target] || (() => { }))();
}
catch (err) {
    toast(err.message, 'error');
}
finally {
    setBusy(false);
} }
function marketQuoteCard(q, watchSymbols = new Set(), allowWatch = true) { const symbol = String(q.symbol || '').toUpperCase(), watched = watchSymbols.has(symbol), change = Number(q.change_percent || 0), stale = Boolean(q.stale || q.delayed), providers = Number(q.provider_count || 1), confidence = Number(q.confidence || 0); return `<div class="account-card" data-market-row="${esc(symbol)}"><div class="row-between"><div><strong>${esc(q.title || q.symbol)}</strong><small class="mono">${esc(q.symbol || '')}</small></div><div><b data-market-price>${num(q.price, 7)} ${esc(q.unit || '')}</b>${stale ? `<span class="status-badge warn">${state.lang === 'fa' ? 'آخرین قیمت معتبر' : 'Last known'}</span>` : ''}</div></div><p data-market-meta>${esc(q.provider || q.source || '')} · ${date(q.updated_at)}${providers > 1 ? ` · ${providers} API · ${pct(confidence * 100, 0)} confidence` : ''}${Number.isFinite(change) && change !== 0 ? ` · <span class="${change >= 0 ? 'text-good' : 'text-bad'}">${change >= 0 ? '+' : ''}${pct(change, 2)}</span>` : ''}</p><div class="card-actions">${watched ? `<span class="status-badge good">Watchlist</span><button class="button danger small" data-watch-remove="${esc(q.symbol)}">${state.lang === 'fa' ? 'حذف' : 'Remove'}</button>` : allowWatch ? `<button class="button secondary small" data-watch-quick="${esc(q.symbol)}">${icon('plus')} Watchlist</button>` : ''}</div></div>`; }
function marketModal() { const d = state.resources.market || {}, quotes = d.quotes || [], iran = d.iran_quotes || d.iran || [], watch = d.watchlist || [], reg = d.regime || {}, current = reg.current || {}, watchSymbols = new Set(watch.map(w => String(w.symbol || '').toUpperCase())), failed = d.failed_quotes || []; openModal('MARKET', t('market'), `<div class="row-between"><span id="marketLiveBadge" class="status-badge ${d.live ? 'good' : 'warn'}">${d.live ? 'LIVE · MULTI API' : 'CACHE'}</span><button class="button secondary small" data-market-refresh>${icon('refresh')}${esc(t('updated'))}</button></div><section class="panel regime-card"><div class="panel-head"><div><small class="eyebrow">MARKET INTELLIGENCE</small><h3>${esc(t('marketRegime'))}</h3></div><span class="status-badge info">${esc(String(current.regime || 'balanced').replaceAll('_', ' '))}</span></div><div class="panel-body"><div class="metric-grid">${metric(state.lang === 'fa' ? 'اطمینان' : 'Confidence', pct(Number(current.confidence || 0) * 100, 0), '', 'info')}${metric(state.lang === 'fa' ? 'نوسان' : 'Volatility', esc(current.volatility || 'unknown'), '', '')}${metric(state.lang === 'fa' ? 'سشن' : 'Session', esc(current.session || '—'), '', '')}</div><p class="field-help">${esc((current.reasons || []).join(' · '))}</p></div></section><div class="field"><label for="watchSymbol">${state.lang === 'fa' ? 'افزودن نماد به واچ‌لیست' : 'Add symbol to watchlist'}</label><div style="display:flex;gap:8px"><input id="watchSymbol" maxlength="20" class="ltr" placeholder="XAUUSD / BTCUSD"><button class="button" data-watch-add>${icon('plus')}</button></div></div>${watch.length ? `<section class="panel"><div class="panel-head"><h3>Watchlist</h3><span class="status-badge info">${num(watch.length, 0)}</span></div><div class="panel-body signal-list">${watch.map(w => { const row = w.quote || [...quotes, ...iran].find(q => String(q.symbol).toUpperCase() === String(w.symbol).toUpperCase()) || w; return marketQuoteCard(row, watchSymbols, false); }).join('')}</div></section>` : ''}<section class="panel"><div class="panel-head"><h3>${state.lang === 'fa' ? 'بازار جهانی' : 'Global markets'}</h3><span class="status-badge ${failed.length ? 'warn' : 'good'}">${num(quotes.length, 0)} / ${num(quotes.length + failed.length, 0)}</span></div><div class="panel-body signal-list">${quotes.length ? quotes.map(q => marketQuoteCard(q, watchSymbols)).join('') : empty()}</div></section><section class="panel"><div class="panel-head"><h3>${state.lang === 'fa' ? 'بازار ایران' : 'Iran market'}</h3><span class="status-badge ${d.iran_error ? 'warn' : 'good'}">${num(iran.length, 0)}</span></div><div class="panel-body">${d.iran_error ? `<div class="notice warning">${esc(d.iran_error)}</div>` : ''}<div class="signal-list">${iran.length ? iran.map(q => marketQuoteCard(q, watchSymbols)).join('') : empty()}</div></div></section>${failed.length ? `<details class="notice warning"><summary>${state.lang === 'fa' ? 'نمادهای موقتاً ناموفق' : 'Temporarily unavailable symbols'}</summary><p>${failed.map(x => esc(x.symbol)).join(' · ')}</p></details>` : ''}`, []); }
function refreshMarketDom(data) { if (!data)
    return; const rows = [...(data.quotes || []), ...(data.iran_quotes || data.iran || [])]; for (const q of rows) {
    const row = document.querySelector(`[data-market-row="${CSS.escape(String(q.symbol || '').toUpperCase())}"]`);
    if (!row)
        continue;
    const price = $('[data-market-price]', row), meta = $('[data-market-meta]', row);
    if (price)
        price.textContent = `${num(q.price, 7)} ${q.unit || ''}`.trim();
    if (meta)
        meta.textContent = `${q.provider || q.source || ''} · ${date(q.updated_at)}${Number(q.provider_count || 1) > 1 ? ` · ${Number(q.provider_count)} API` : ''}`;
} const badge = $('#marketLiveBadge'); if (badge) {
    badge.textContent = data.live ? 'LIVE · MULTI API' : 'CACHE';
    badge.className = `status-badge ${data.live ? 'good' : 'warn'}`;
} }
function calendarModal() { const d = state.resources.calendar || {}, p = d.preferences || {}; openModal('CALENDAR', t('calendar'), `<div class="row-between modal-toolbar"><div><strong>${esc((p.currencies || []).join(' · ') || '—')}</strong><p>${esc(t('minImpact'))}: ${esc(p.min_impact || 'high')} · ${esc(t('reminderMinutes'))}: ${num(p.reminder_minutes || 30, 0)} min</p></div><button class="button secondary small" data-calendar-settings>${icon('settings')}<span>${esc(t('calendarSettings'))}</span></button></div><div class="signal-list">${(d.items || []).map(e => `<div class="account-card"><div class="row-between"><strong>${esc(e.currency || e.country || '')} · ${esc(e.title || e.event || '')}</strong><span class="status-badge ${String(e.importance || e.impact).toLowerCase().includes('high') ? 'bad' : 'warn'}">${esc(e.importance || e.impact || '')}</span></div><p>${date(e.datetime || e.date || e.time)} · Actual ${esc(e.actual ?? '—')} / Forecast ${esc(e.forecast ?? '—')}</p></div>`).join('') || empty()}</div>${moreButton('calendar', d)}`, []); }
function calendarPreferencesModal() { const p = state.resources.calendar?.preferences || {}, currencies = ['USD', 'EUR', 'GBP', 'JPY', 'CAD', 'AUD', 'NZD', 'CHF', 'CNY'], selected = new Set(p.currencies || []); openModal('CALENDAR SETTINGS', t('calendarSettings'), `<form id="calendarPreferencesForm"><div class="toggle-row"><label for="calendarEnabled"><span>${esc(t('calendarAlerts'))}</span><input id="calendarEnabled" type="checkbox" ${p.enabled !== false ? 'checked' : ''}></label></div><div class="toggle-row"><label for="calendarActualAlerts"><span>${esc(t('actualAlerts'))}</span><input id="calendarActualAlerts" type="checkbox" ${p.actual_alerts !== false ? 'checked' : ''}></label></div><fieldset class="field"><legend>${esc(t('currencies'))}</legend><div class="choice-grid">${currencies.map(c => `<label class="choice-chip"><input type="checkbox" name="calendarCurrency" value="${c}" ${selected.has(c) ? 'checked' : ''}><span>${c}</span></label>`).join('')}</div></fieldset><div class="form-grid"><div class="field"><label for="calendarImpact">${esc(t('minImpact'))}</label><select id="calendarImpact"><option value="high" ${p.min_impact === 'high' ? 'selected' : ''}>High</option><option value="medium" ${p.min_impact === 'medium' ? 'selected' : ''}>Medium</option><option value="low" ${p.min_impact === 'low' ? 'selected' : ''}>Low</option></select></div><div class="field"><label for="calendarReminder">${esc(t('reminderMinutes'))}</label><select id="calendarReminder">${[5, 15, 30, 60, 120].map(v => `<option value="${v}" ${Number(p.reminder_minutes || 30) === v ? 'selected' : ''}>${v} min</option>`).join('')}</select></div><div class="field"><label for="calendarTimezone">${esc(t('timezone'))}</label><select id="calendarTimezone">${['Asia/Tehran', 'Asia/Baku', 'UTC'].map(v => `<option value="${v}" ${String(p.timezone || 'UTC') === v ? 'selected' : ''}>${v}</option>`).join('')}</select></div></div><div id="calendarFormError" class="form-error" role="alert" hidden></div></form>`, [{ label: t('save'), kind: 'primary', action: async () => { const currencies = $$('input[name="calendarCurrency"]:checked').map(el => el.value), error = $('#calendarFormError'); if (!currencies.length) {
            error.hidden = false;
            error.textContent = state.lang === 'fa' ? 'حداقل یک ارز را انتخاب کنید.' : 'Select at least one currency.';
            return;
        } setBusy(true); try {
            await action('calendar_preferences_update', { enabled: $('#calendarEnabled').checked, actual_alerts: $('#calendarActualAlerts').checked, currencies, min_impact: $('#calendarImpact').value, reminder_minutes: Number($('#calendarReminder').value), timezone: $('#calendarTimezone').value }, false);
            invalidate('calendar');
            await loadResource('calendar', true);
            calendarModal();
            toast(t('success'));
        }
        catch (err) {
            error.hidden = false;
            error.textContent = err.message;
        }
        finally {
            setBusy(false);
        } } }]); }
function trackModal() { const d = state.resources.track || {}, s = d.summary || {}; openModal('TRUST', t('trackRecord'), `<div class="metric-grid">${metric('Sample', num(s.sample_size || 0, 0), '', 'info')}${metric('Win rate', pct(s.win_rate || 0), '', 'good')}${metric('Average R', num(s.average_r || 0, 3), '', '')}${metric('Max DD (R)', num(s.maximum_drawdown_r || 0, 3), '', 'bad')}</div><div class="signal-list">${(d.items || []).map(x => `<div class="account-card"><div class="row-between"><strong>${esc(x.symbol)} · #${num(x.display_number, 0)}</strong><span class="status-badge ${Number(x.outcome?.net_r) >= 0 ? 'good' : 'bad'}">${num(x.outcome?.net_r, 2)}R</span></div><p>${date(x.created_at)} · rev ${num(x.revision, 0)} · chain ${x.revision_chain_valid ? '✓' : '✕'}</p><small class="mono">${esc(x.evidence_hash || '')}</small></div>`).join('') || empty()}</div>${moreButton('track', d)}`, []); }
function revisionsModal() { const d = state.resources.revisions || {}; openModal('REVISION INBOX', t('revisions'), `<div class="revision-list">${(d.items || []).map(x => `<div class="revision-card"><div class="row-between"><strong>${esc(x.symbol)} · #${num(x.display_number, 0)}</strong><span class="status-badge warn">R${num(x.revision, 0)}</span></div><p>${esc((x.changed_fields || []).join(', '))} · ${date(x.created_at)}</p><button class="button small" data-revision-ack="${x.signal_id}" data-revision="${x.revision}">${esc(t('ack'))}</button></div>`).join('') || empty()}</div>`, []); }
function vipModal() { const d = state.resources.overview?.commerce || {}, plans = d.plans || []; openModal('VIP', t('vip'), `<div class="signal-list">${plans.map(p => `<article class="account-card"><div class="row-between"><h3>${esc(state.lang === 'en' && p.name_en ? p.name_en : p.name)}</h3><strong class="quote-price">${num(p.price, 0)} T</strong></div><p>${esc(state.lang === 'en' && p.description_en ? p.description_en : p.description)}</p><div class="card-actions"><button class="button" data-plan-checkout="${p.id}">${esc(t('selectPlan'))}</button></div></article>`).join('') || empty()}</div>`, []); }
function checkoutRequestId(prefix = 'quote') { return `${prefix}:${Date.now()}:${crypto.randomUUID?.() || Math.random().toString(36).slice(2)}`; }
function checkoutActionData(value) { if (!value || typeof value !== 'object') return value; if (value.action && value.data && typeof value.data === 'object') { const data = value.data; return data.result && typeof data.result === 'object' ? data.result : data; } return value; }
function checkoutModal(planId) { const d = state.resources.overview?.commerce || {}, p = (d.plans || []).find(x => Number(x.id) === Number(planId)); if (!p)
    return; openModal('SECURE CHECKOUT', p.name, `<div class="quote-box"><small>${state.lang === 'fa' ? 'قیمت پلن قبل از تخفیف' : 'Plan price before discount'}</small><div class="quote-price">${num(p.price, 0)} Toman</div></div><form id="quoteForm"><div class="field"><label for="payMethod">${esc(t('paymentMethod'))}</label><select id="payMethod">${d.payment?.card?.enabled ? '<option value="card">Card to card</option>' : ''}${d.payment?.usdt?.enabled ? '<option value="usdt">USDT</option>' : ''}</select></div><label class="checkbox-row"><input id="hasCoupon" type="checkbox"><span>${state.lang === 'fa' ? 'کد تخفیف دارم' : 'I have a coupon'}</span></label><div class="field" id="couponField" hidden><label for="couponCode">${esc(t('coupon'))}</label><input id="couponCode" maxlength="40" autocomplete="off"></div></form><div id="quoteResult"></div>`, [{ label: state.lang === 'fa' ? 'نمایش مبلغ و اطلاعات پرداخت' : t('getQuote'), kind: 'primary', action: () => getCheckoutQuote(planId) }]); const toggle = $('#hasCoupon'), field = $('#couponField'); if (toggle && field) toggle.addEventListener('change', () => { field.hidden = !toggle.checked; if (!toggle.checked && $('#couponCode')) $('#couponCode').value = ''; }); }
async function getCheckoutQuote(planId) { setBusy(true); try {
    const requestId = checkoutRequestId('checkout-quote'), coupon = $('#hasCoupon')?.checked ? ($('#couponCode')?.value || '').trim() : '';
    const rawQuote = await request('./api/v1/checkout/quote', { method: 'POST', csrf: true, headers: { 'Content-Type': 'application/json', 'Idempotency-Key': requestId }, body: JSON.stringify({ plan_id: planId, payment_method: $('#payMethod').value, coupon, request_id: requestId }) });
    const q = checkoutActionData(rawQuote);
    if (!q || !q.quote_id || !Number.isFinite(Number(q.payable_toman))) throw new Error(state.lang === 'fa' ? 'اطلاعات مبلغ پرداخت ناقص است؛ دوباره تلاش کنید.' : 'Checkout quote is incomplete; try again.');
    state.resources.checkoutQuote = q;
    const free = Number(q.payable_toman) <= 0, payment = free ? `<div class="notice good"><strong>${state.lang === 'fa' ? 'فعال‌سازی رایگان' : 'Free activation'}</strong><p>${state.lang === 'fa' ? 'این سفارش بدون رسید ثبت می‌شود، اما فعال‌سازی فقط پس از تأیید دستی ادمین انجام می‌شود.' : 'This order needs no receipt, but still requires manual admin approval.'}</p></div>` : (q.payment_method === 'usdt' ? `<p class="ltr">${esc(q.payment_amount_usdt)} USDT · ${esc(q.payment_network)}</p><p class="mono ltr">${esc(q.payment_wallet)}</p>` : `<p class="ltr mono">${esc(q.payment_card_number)}</p><p>${esc(q.payment_card_owner)}</p>`);
    const receipt = free ? '' : `<div class="field"><label for="receiptFile">${state.lang === 'fa' ? 'عکس فیش پرداخت' : esc(t('uploadReceipt'))}</label><input id="receiptFile" type="file" accept="image/jpeg,image/png,image/webp" required><small class="field-help">${state.lang === 'fa' ? 'پس از انتخاب، پیش‌نمایش فیش نمایش داده می‌شود و برای ادمین ارسال خواهد شد.' : 'The receipt preview will be shown and sent to an admin.'}</small><img id="receiptLocalPreview" class="receipt-preview" hidden alt="receipt preview"></div>`;
    const txid = !free && q.payment_method === 'usdt' ? `<div class="field"><label for="orderTxid">${esc(t('transactionHash'))} (${state.lang === 'fa' ? 'اختیاری' : 'optional'})</label><input id="orderTxid" class="ltr" maxlength="128"><small class="field-help">${state.lang === 'fa' ? 'تأیید پرداخت فقط بر اساس رسید و بررسی دستی ادمین است.' : 'Approval is based on the receipt and manual admin review.'}</small></div>` : '';
    $('#quoteResult').innerHTML = `<div class="quote-box"><small>${esc(t('payable'))}</small><div class="quote-price">${num(q.payable_toman, 0)} Toman</div>${payment}<p>${esc(t('expires'))}: ${date(q.expires_at)}</p></div><form id="orderForm" style="margin-top:14px">${receipt}${txid}<button class="button primary wide" type="button" data-order-submit>${state.lang === 'fa' ? 'ثبت سفارش و ارسال فیش' : esc(t('submit'))}</button></form>`;
    const receiptInput = $('#receiptFile'), receiptPreview = $('#receiptLocalPreview'); if (receiptInput && receiptPreview) receiptInput.addEventListener('change', () => { const file = receiptInput.files?.[0]; if (!file) { receiptPreview.hidden = true; receiptPreview.removeAttribute('src'); return; } receiptPreview.src = URL.createObjectURL(file); receiptPreview.hidden = false; });
    setModalFooter([]);
}
catch (err) {
    toast(err.message, 'error');
}
finally {
    setBusy(false);
} }
async function submitOrder() { const q = state.resources.checkoutQuote; if (!q)
    return; const free = Number(q.payable_toman || 0) <= 0, file = $('#receiptFile')?.files?.[0]; if (!free && !file) {
    toast(state.lang === 'fa' ? 'رسید را انتخاب کنید.' : 'Select a receipt.', 'error');
    return;
} setBusy(true); try {
    let receiptId = '';
    if (!free) {
        const fd = new FormData();
        fd.append('file', file);
        const receipt = await request('./api/v1/checkout/receipt', { method: 'POST', csrf: true, body: fd }, 40000);
        receiptId = receipt.receipt_id;
    }
    await action('vip_order_submit', { quote_id: q.quote_id, receipt_id: receiptId, transaction_hash: $('#orderTxid')?.value || '' }, false);
    toast(t('success'));
    closeModal();
    invalidate('orders', 'overview');
    await loadOverview(true);
    renderChrome();
}
catch (err) {
    toast(err.message, 'error');
}
finally {
    setBusy(false);
} }
function ordersModal() { const d = state.resources.orders || {}; openModal('ORDERS', t('orders'), `<div class="filters">${['all', 'pending', 'approved', 'rejected', 'cancelled'].map(x => `<button class="filter-chip ${state.orderFilter === x ? 'active' : ''}" data-order-filter="${x}">${esc(x === 'all' ? t('all') : x)}</button>`).join('')}</div><div class="order-list" style="margin-top:12px">${(d.items || []).map(o => `<article class="order-card"><div class="row-between"><h3>${esc(o.plan_name)}</h3><span class="status-badge ${o.status === 'approved' ? 'good' : o.status === 'rejected' ? 'bad' : 'warn'}">${esc(o.status)}</span></div><p>${esc(o.order_id)} · ${num(o.price, 0)} T · ${date(o.created_at)}</p>${o.rejection_reason ? `<div class="notice danger">${esc(o.rejection_reason)}</div>` : ''}<div class="card-actions"><button class="button secondary small" data-order-detail="${o.order_id}">${esc(t('orderDetails'))}</button>${['pending', 'approving'].includes(o.status) ? `<button class="button danger small" data-order-cancel="${o.order_id}">${esc(t('cancel'))}</button>` : ''}${['rejected', 'cancelled', 'expired'].includes(o.status) ? `<button class="button small" data-order-resubmit="${o.order_id}">${esc(t('resubmit'))}</button>` : ''}</div></article>`).join('') || empty()}</div>${moreButton('orders', d)}`, []); }
async function orderDetailModal(orderId) { setBusy(true); try {
    const o = await request(`./api/v1/orders/${encodeURIComponent(orderId)}`);
    const receiptPreview = o.receipt_attached || o.receipt_id || o.receipt_key ? `<div class="account-card"><strong>${state.lang === 'fa' ? 'رسید ثبت‌شده' : 'Submitted receipt'}</strong><img class="receipt-preview" src="./api/v1/orders/${encodeURIComponent(orderId)}/receipt" alt="receipt" loading="lazy"></div>` : '';
    openModal('ORDER', `${t('orderDetails')} · ${o.order_id}`, `<div class="metric-grid">${metric(t('status'), esc(o.status), '', 'info')}${metric(t('payable'), `${num(o.price, 0)} T`, '', '')}${metric(t('paymentMethod'), esc(o.payment_method || '—'), '', '')}${metric(t('updated'), date(o.updated_at || o.created_at), '', '')}</div>${receiptPreview}${o.rejection_reason ? `<div class="notice danger"><strong>${esc(t('reason'))}</strong><p>${esc(o.rejection_reason)}</p></div>` : ''}<div class="timeline">${(o.timeline || o.history || []).map(x => `<div class="timeline-item"><strong>${esc(x.status || x.event || 'update')}</strong><p>${esc(x.note || x.reason || '')}</p><small>${date(x.created_at)}</small></div>`).join('') || `<div class="timeline-item"><strong>${esc(o.status)}</strong><small>${date(o.updated_at || o.created_at)}</small></div>`}</div>`, []);
}
catch (err) {
    toast(err.message, 'error');
}
finally {
    setBusy(false);
} }
async function orderResubmitModal(orderId) { setBusy(true); try {
    const o = await request(`./api/v1/orders/${encodeURIComponent(orderId)}`), requestId = checkoutRequestId('checkout-resubmit'), rawQuote = await request('./api/v1/checkout/quote', { method: 'POST', csrf: true, headers: { 'Content-Type': 'application/json', 'Idempotency-Key': requestId }, body: JSON.stringify({ plan_id: o.plan_id, payment_method: o.payment_method, coupon: o.coupon || '', request_id: requestId }) });
    const q = checkoutActionData(rawQuote); if (!q || !q.quote_id || !Number.isFinite(Number(q.payable_toman))) throw new Error('CHECKOUT_QUOTE_INVALID');
    state.resources.resubmitQuote = q;
    const free = Number(q.payable_toman || 0) <= 0, payment = free ? `<div class="notice good">${state.lang === 'fa' ? 'ارسال مجدد رایگان؛ رسید لازم نیست ولی تأیید ادمین الزامی است.' : 'Free resubmission; no receipt is required, but admin approval is.'}</div>` : (q.payment_method === 'usdt' ? `<p class="ltr">${esc(q.payment_amount_usdt)} USDT · ${esc(q.payment_network)}</p><p class="mono ltr">${esc(q.payment_wallet)}</p>` : `<p class="ltr mono">${esc(q.payment_card_number)}</p><p>${esc(q.payment_card_owner)}</p>`);
    openModal('ORDER', t('resubmit'), `<div class="quote-box"><small>${esc(t('payable'))}</small><div class="quote-price">${num(q.payable_toman, 0)} Toman</div>${payment}<p>${esc(t('expires'))}: ${date(q.expires_at)}</p></div><form id="orderResubmitForm" style="margin-top:14px">${free ? '' : `<div class="field"><label for="resubmitReceipt">${esc(t('uploadReceipt'))}</label><input id="resubmitReceipt" type="file" accept="image/jpeg,image/png,image/webp" required></div>`}${!free && q.payment_method === 'usdt' ? `<div class="field"><label for="resubmitTxid">${esc(t('transactionHash'))}</label><input id="resubmitTxid" class="ltr" maxlength="128"></div>` : ''}</form>`, [{ label: t('resubmit'), kind: 'primary', action: async () => { const f = $('#orderResubmitForm'), file = $('#resubmitReceipt')?.files?.[0]; if (!f.reportValidity() || (!free && !file))
                return; setBusy(true); try {
                let receiptId = '';
                if (!free) {
                    const fd = new FormData();
                    fd.append('file', file);
                    const receipt = await request('./api/v1/checkout/receipt', { method: 'POST', csrf: true, body: fd }, 40000);
                    receiptId = receipt.receipt_id;
                }
                await action('vip_order_resubmit', { order_id: orderId, quote_id: q.quote_id, receipt_id: receiptId, transaction_hash: $('#resubmitTxid')?.value.trim() || '' }, false);
                closeModal();
                invalidate('orders', 'overview');
                await loadResource('orders', true);
                ordersModal();
                toast(t('success'));
            }
            catch (err) {
                toast(err.message, 'error');
            }
            finally {
                setBusy(false);
            } } }]);
}
catch (err) {
    toast(err.message, 'error');
}
finally {
    setBusy(false);
} }
function ticketStatusClass(status) { return status === 'closed' ? 'bad' : status === 'answered' ? 'good' : status === 'pending' ? 'warn' : 'info'; }
function ticketStatusLabel(status) { const labelsFa = { open: 'باز', pending: 'در انتظار ادمین', answered: 'پاسخ داده شد', closed: 'بسته' }, labelsEn = { open: 'Open', pending: 'Waiting for admin', answered: 'Answered', closed: 'Closed' }; return (state.lang === 'fa' ? labelsFa : labelsEn)[status] || status; }
function supportModal() { const d = state.resources.tickets || {}, items = d.items || [], counts = items.reduce((a, x) => (a[x.status] = (a[x.status] || 0) + 1, a), {}); openModal('SUPPORT', t('support'), `<div class="notice info"><strong>${state.lang === 'fa' ? 'پشتیبانی یکپارچه ربات و مینی‌اپ' : 'Unified Bot & Mini App support'}</strong><p>${state.lang === 'fa' ? 'تمام پاسخ‌ها در هر دو محیط هم‌زمان ثبت و اطلاع‌رسانی می‌شوند.' : 'Every message is synchronized and notified in both environments.'}</p></div><div class="row-between"><button class="button" data-ticket-new>${icon('plus')}${esc(t('createTicket'))}</button><span class="status-badge info">${num(d.total || items.length, 0)} ${state.lang === 'fa' ? 'تیکت' : 'tickets'}</span></div><div class="filters" style="margin-top:13px">${['all', 'open', 'pending', 'answered', 'closed'].map(x => `<button class="filter-chip ${state.ticketFilter === x ? 'active' : ''}" data-ticket-filter="${x}">${esc(x === 'all' ? t('all') : ticketStatusLabel(x))}${x !== 'all' && counts[x] ? ` · ${num(counts[x], 0)}` : ''}</button>`).join('')}</div><div class="ticket-list" style="margin-top:13px">${items.map(x => { const messages = x.messages || [], last = messages[messages.length - 1] || {}; return `<article class="ticket-card"><div class="row-between"><h3>#${num(x.id, 0)} · ${esc(x.subject)}</h3><span class="status-badge ${ticketStatusClass(x.status)}">${esc(ticketStatusLabel(x.status))}</span></div><p>${esc(x.category || 'general')} · ${esc(x.priority || 'normal')} · ${date(x.updated_at || x.created_at)}</p><div class="notice ${x.waiting_for === 'user' ? 'good' : 'info'}"><strong>${x.waiting_for === 'user' ? (state.lang === 'fa' ? 'پاسخ ادمین آماده است' : 'Admin reply available') : (state.lang === 'fa' ? 'در انتظار بررسی پشتیبانی' : 'Waiting for support')}</strong>${last.text ? `<small>${esc(String(last.text).slice(0, 160))}</small>` : ''}</div><div class="card-actions"><button class="button secondary small" data-ticket-detail="${x.id}">${esc(t('details'))} · ${num(messages.length, 0)}</button></div></article>`; }).join('') || empty()}</div>${moreButton('tickets', d)}`, []); }
function ticketNewModal() { openModal('SUPPORT', t('createTicket'), `<form id="ticketForm"><div class="form-grid"><div class="field"><label for="ticketSubject">${esc(t('ticketSubject'))}</label><input id="ticketSubject" required maxlength="200"></div><div class="field"><label for="ticketCategory">${state.lang === 'fa' ? 'دسته' : 'Category'}</label><select id="ticketCategory"><option value="general">General</option><option value="account">Account</option><option value="payment">Payment</option><option value="signal">Signal</option><option value="education">Education</option><option value="technical">Technical</option></select></div><div class="field"><label for="ticketPriority">${esc(t('priority'))}</label><select id="ticketPriority"><option value="low">Low</option><option value="normal" selected>Normal</option><option value="high">High</option><option value="urgent">Urgent</option></select></div></div><div class="field"><label for="ticketMessage">${esc(t('message'))}</label><textarea id="ticketMessage" required minlength="4" maxlength="4000"></textarea></div></form>`, [{ label: t('submit'), kind: 'primary', action: async () => { const f = $('#ticketForm'); if (!f.reportValidity())
            return; setBusy(true); try {
            const row = await action('ticket_create', { subject: $('#ticketSubject').value, priority: $('#ticketPriority').value, text: $('#ticketMessage').value, category: $('#ticketCategory').value }, false);
            invalidate('tickets', 'overview');
            await Promise.all([loadResource('tickets', true), loadOverview(true)]);
            closeModal();
            await ticketDetail(row.id);
            toast(t('success'));
        }
        catch (err) {
            toast(err.message, 'error');
        }
        finally {
            setBusy(false);
        } } }]); }
async function ticketDetail(id) { setBusy(true); try {
    const x = await request(`./api/v1/tickets/${id}`), closed = x.status === 'closed';
    openModal('TICKET', `#${x.id} · ${x.subject}`, `<div class="metric-grid">${metric(t('status'), esc(ticketStatusLabel(x.status)), '', ticketStatusClass(x.status))}${metric(t('priority'), esc(x.priority || 'normal'), '', '')}${metric(state.lang === 'fa' ? 'منتظر پاسخ' : 'Waiting for', esc(x.waiting_for || 'admin'), '', 'info')}${metric(state.lang === 'fa' ? 'پیام‌ها' : 'Messages', num((x.messages || []).length, 0), '', '')}</div><div class="timeline">${(x.messages || []).map(m => `<div class="timeline-item ${m.sender === 'admin' ? 'admin-message' : 'user-message'}"><strong>${m.sender === 'admin' ? (state.lang === 'fa' ? 'پشتیبانی SENTINEL' : 'SENTINEL Support') : (state.lang === 'fa' ? 'شما' : 'You')}</strong><p>${esc(m.text)}</p><small>${date(m.created_at)}</small></div>`).join('') || empty()}</div>${!closed ? `<form id="ticketReplyForm"><div class="field"><label for="ticketReply">${esc(t('message'))}</label><textarea id="ticketReply" required maxlength="4000"></textarea></div><div class="card-actions"><button type="button" class="button" data-ticket-reply="${x.id}">${esc(t('submit'))}</button><button type="button" class="button danger" data-ticket-status="${x.id}" data-status="closed">${state.lang === 'fa' ? 'بستن تیکت' : 'Close ticket'}</button></div></form>` : `<div class="notice warning"><strong>${state.lang === 'fa' ? 'تیکت بسته است' : 'Ticket is closed'}</strong><button class="button secondary small" data-ticket-status="${x.id}" data-status="open">${state.lang === 'fa' ? 'بازگشایی' : 'Reopen'}</button></div>`}`, []);
}
catch (err) {
    toast(err.message, 'error');
}
finally {
    setBusy(false);
} }
function settingsModal() { const o = state.resources.overview || {}; openModal('SETTINGS', t('settings'), `<div class="account-card"><div class="row-between"><strong>${esc(t('onboarding'))}</strong><span class="status-badge ${o.onboarding?.completed ? 'good' : 'warn'}">${esc(o.onboarding?.completed ? t('accepted') : t('pending'))}</span></div><p>${state.lang === 'fa' ? 'سطح تجربه، بازار، اندازه حساب، تحمل ریسک و هدف خود را ویرایش کنید.' : 'Edit experience, market, account size, risk tolerance and primary goal.'}</p><button class="button secondary small" data-open="onboarding">${esc(t('onboarding'))}</button></div><div class="account-card"><div class="row-between"><strong>${esc(t('language'))}</strong><button class="button secondary small" data-language-toggle>${state.lang === 'fa' ? 'English' : 'Persian'}</button></div></div><div class="account-card"><div class="row-between"><strong>${esc(t('rules'))}</strong><span class="status-badge ${o.rules?.accepted ? 'good' : 'warn'}">${esc(o.rules?.accepted ? t('accepted') : t('pending'))}</span></div><p>${esc(o.rules?.summary || o.rules?.title || '')}</p>${o.rules?.accepted ? '' : `<button class="button small" data-rules-accept>${esc(t('acceptRules'))}</button>`}</div><div class="account-card"><div class="row-between"><strong>${esc(t('appVersion'))}</strong><span class="mono">${esc(APP_VERSION)}</span></div><p>${state.lang === 'fa' ? 'کش برنامه نسخه‌دار است و Hotfixها بدون انتظار ۲۴ ساعته دریافت می‌شوند.' : 'Versioned assets receive hotfixes without a 24-hour stale cache.'}</p><button class="button secondary small" data-app-reload>${esc(t('reloadApp'))}</button></div><button class="button danger" data-logout>${esc(t('logout'))}</button>`, []); }
/* v8.3.9 role-separated navigation. Server permissions remain authoritative. */
async function renderMore(force = false) {
    const page = $('#page-more'), o = state.resources.overview || {}, admin = o.admin || { available: Boolean(o.admin_available), role: 'user' };
    const userTools = `<section class="panel"><div class="panel-head"><div><small class="eyebrow">USER CENTER</small><h2>مرکز کاربر</h2></div><span class="status-badge info">${esc(o.user?.role || 'user')}</span></div><div class="panel-body"><div class="feature-grid">
 ${feature('bell', 'فید کانال', 'سیگنال، خبر و اعلان زنده', 'feed')}
 ${feature('shield', 'مرکز تمرین و ریسک', 'Paper Trading، Prop و مربی رفتار', 'tradeCenter')}
 ${feature('chart', 'بررسی هوشمند حساب', 'تحلیل ژورنال، ریسک و حساب‌های خودت با یک دکمه', 'ai')}
 ${feature('search', t('globalSearch'), 'جست‌وجو در تمام داده‌های شخصی', 'search')}
 ${feature('market', t('market'), 'قیمت‌ها و واچ‌لیست', 'market')}
 ${feature('calendar', t('calendar'), 'خبرهای مهم هفته', 'calendar')}
 ${feature('chart', t('trackRecord'), 'عملکرد قابل راستی‌آزمایی', 'track')}
 ${feature('bell', t('revisions'), 'تغییرات سیگنال‌های گرفته‌شده', 'revisions', o.revision_count || 0)}
 ${feature('user', t('settings'), 'زبان، قوانین و نشست', 'settings')}
 ${feature('support', t('support'), 'تیکت و پاسخ‌ها', 'support')}
 </div></div></section>`;
    const adminPerms = new Set(admin.permissions || []), canAI = admin.role === 'owner' || adminPerms.has('ai_command_center'); const adminTools = admin.available ? `<section class="panel admin-zone"><div class="panel-head"><div><small class="eyebrow">ADMIN ONLY</small><h2>مرکز اختصاصی ادمین</h2></div><span class="status-badge warn">${esc(admin.role || 'admin')}</span></div><div class="panel-body"><p class="field-help">این بخش فقط با نقش و مجوز ادمین از سمت سرور باز می‌شود.</p><div class="feature-grid">${feature('shield', t('adminConsole'), 'عملیات، Audit، شیفت و کنترل سامانه', 'admin')}${canAI ? feature('chart', 'مرکز فرماندهی Gemini', 'CRM، کانال، کاربران و سلامت سیستم', 'adminAI') : ''}</div></div></section>` : '';
    page.innerHTML = pageHead('EXPLORE', t('more'), 'دسترسی‌های کاربر و ادمین کاملاً از هم جدا شده‌اند.') + userTools + adminTools;
}
async function openMore(target) {
    if (target === 'settings')
        return settingsModal();
    if (target === 'search')
        return searchModal();
    if (target === 'notifications')
        return notificationModal();
    if (target === 'onboarding')
        return onboardingModal();
    if (target === 'admin')
        return adminWorkspace();
    if (target === 'feed')
        return feedModal();
    if (target === 'tradeCenter')
        return tradeCenterModal();
    if (target === 'ai')
        return userAiCenter();
    if (target === 'adminAI')
        return adminAiCenter();
    if (FEATURE_KEY[target] && !featureEnabled(target))
        return featureDisabledModal();
    setBusy(true);
    try {
        const key = target === 'vip' ? 'overview' : target === 'support' ? 'tickets' : target;
        await loadResource(key);
        ({ market: marketModal, calendar: calendarModal, track: trackModal, revisions: revisionsModal, vip: vipModal, orders: ordersModal, support: supportModal }[target] || (() => { }))();
    }
    catch (err) {
        toast(err.message, 'error');
    }
    finally {
        setBusy(false);
    }
}

