/* Extend existing pages and domain services; no parallel economy or account system. */
Object.assign(I18N.fa,{trading:'معامله‌گری',rewards:'جوایز',allServices:'خدمات'});
Object.assign(I18N.en,{trading:'Trading',rewards:'Rewards',allServices:'Services'});
const HUB_COPY={
 fa:{rewards:'پاداش‌ها',available:'جوایز موجود',mine:'جوایز من',history:'تاریخچه امتیاز',points:'امتیاز',earned:'دریافتی ثبت‌شده',spent:'مصرف ثبت‌شده',source:'منبع',valid:'اعتبار',conditions:'شرایط استفاده',claim:'مشاهده و دریافت در ربات',referral:'دعوت دوستان',copy:'کپی لینک',share:'اشتراک‌گذاری',invited:'دعوت‌ها',buyers:'خریداران',noCode:'برای دریافت لینک اختصاصی وارد بخش دعوت ربات شوید.',bot:'باز کردن ربات',missions:'مأموریت‌ها',education:'آموزش',rank:'رتبه‌بندی و باشگاه',account:'حساب و تمام خدمات',services:'همه قابلیت‌ها با حفظ دسترسی‌های قبلی',trading:'میز معامله‌گری',risk:'برنامه ریسک',journal:'ژورنال معاملاتی',tools:'تمرین و ابزارها',next:'صفحه بعد',before:'صفحه قبل',used:'استفاده‌شده',expired:'منقضی',active:'قابل استفاده',scheduled:'هنوز شروع نشده',reserved:'رزرو برای سفارش',disabled:'غیرفعال',cost:'هزینه دریافت',confirm:'تأیید دریافت جایزه',delivering:'در حال دریافت…',claimHere:'دریافت جایزه',notEnough:'امتیاز کافی ندارید',pending:'در انتظار تحویل',delivered:'تحویل‌شده',cancelled:'لغوشده',date:'تاریخ',balance:'مانده',noExpiry:'بدون انقضای ثبت‌شده',perUser:'سقف استفاده هر نفر',renewal:'فقط تمدید VIP',plans:'پلن‌های مجاز',allPlans:'همه پلن‌ها',minimum:'حداقل خرید',copied:'کپی شد',support:'پشتیبانی',faq:'سؤالات متداول',myToday:'امروز من',ai:'بررسی هوشمند حساب'},
 en:{rewards:'Rewards',available:'Available rewards',mine:'My rewards',history:'Point history',points:'Points',earned:'Recorded earnings',spent:'Recorded spending',source:'Source',valid:'Validity',conditions:'Conditions',claim:'View and claim in bot',referral:'Invite friends',copy:'Copy link',share:'Share',invited:'Invitations',buyers:'Buyers',noCode:'Open referrals in the bot to get your personal link.',bot:'Open bot',missions:'Missions',education:'Education',rank:'Rankings & club',account:'Account & all services',services:'All features with existing access preserved',trading:'Trading workspace',risk:'Risk plan',journal:'Trading journal',tools:'Practice & tools',next:'Next page',before:'Previous page',used:'Used',expired:'Expired',active:'Available',scheduled:'Not started yet',reserved:'Reserved for order',disabled:'Disabled',cost:'Redemption cost',confirm:'Confirm reward claim',delivering:'Claiming…',claimHere:'Claim reward',notEnough:'Not enough points',pending:'Awaiting delivery',delivered:'Delivered',cancelled:'Cancelled',date:'Date',balance:'Balance',noExpiry:'No recorded expiry',perUser:'Uses per user',renewal:'VIP renewal only',plans:'Applicable plans',allPlans:'All plans',minimum:'Minimum purchase',copied:'Copied',support:'Support',faq:'FAQ',myToday:'My today',ai:'Smart account review'}
};
function hubCopy(){return HUB_COPY[state.lang]||HUB_COPY.en;}
const BOT_DESTINATIONS=new Set(['web_account', 'web_account_hub', 'web_calc', 'web_club', 'web_contests', 'web_edu', 'web_faq', 'web_journal', 'web_journal_crypto', 'web_journal_forex', 'web_kpi', 'web_missions', 'web_my_rewards', 'web_news', 'web_prices', 'web_referral', 'web_reward_catalog', 'web_rewards', 'web_services', 'web_rules', 'web_signals', 'web_signals_crypto', 'web_signals_forex', 'web_support', 'web_today', 'web_tools', 'web_trade', 'web_vip', 'web_watchlist', 'web_watchlist_crypto', 'web_watchlist_forex']);
function botBridge(destination){
    if(!BOT_DESTINATIONS.has(destination))return toast(t('notAvailable'),'error');
    const username=String(state.resources.overview?.bot_username||'').replace(/^@/,'');
    if(!/^[A-Za-z0-9_]{5,32}$/.test(username))return toast(t('notAvailable'),'error');
    const url=`https://t.me/${username}?start=${encodeURIComponent(destination)}`;
    if(tg?.openTelegramLink)tg.openTelegramLink(url);else window.open(url,'_blank','noopener');
}
function referralLink(data){
    const username=String(state.resources.overview?.bot_username||'').replace(/^@/,'');
    const code=String(data?.referral?.code||'');
    return /^[A-Za-z0-9_]{5,32}$/.test(username)&&/^[A-Za-z0-9_-]{4,64}$/.test(code)?`https://t.me/${username}?start=${encodeURIComponent(code)}`:'';
}
function hubBridgeCard(ic,label,destination){return `<button class="service-card" data-bot-bridge="${esc(destination)}">${icon(ic)}<span><strong>${esc(label)}</strong><small>${esc(hubCopy().bot)}</small></span>${icon('chevron')}</button>`;}
let rewardTab='available',pointCursor=0;
function rewardCard(item){
    const h=hubCopy(),status=String(item.status||'delivered'),c=item.conditions||{};
    return `<article class="reward-card"><div class="row-between"><h3>${esc(item.title||h.rewards)}${item.unread?' <span class="status-badge warn">●</span>':''}</h3><span class="status-badge ${['expired','cancelled','disabled'].includes(status)?'muted':['pending','scheduled','reserved'].includes(status)?'warn':'good'}">${esc(h[status]||status)}</span></div><p class="mono" dir="auto">${esc(item.detail||'')}</p>${item.code?`<button class="button secondary" data-copy-reward="${esc(item.code)}">${esc(state.lang==='fa'?'کپی کد':'Copy code')}</button>`:''}<dl class="reward-details"><dt>${esc(h.source)}</dt><dd>${esc(item.source_label||h.rewards)}</dd><dt>${esc(h.date)}</dt><dd>${date(item.created_at)}</dd><dt>${esc(h.valid)}</dt><dd>${item.expires_at?date(item.expires_at):esc(h.noExpiry)}</dd></dl>${item.conditions?`<div class="notice info"><strong>${esc(h.conditions)}</strong><p>${esc(h.perUser)}: ${esc(c.per_user_limit||'∞')} · ${esc(c.renewal_only?h.renewal:h.plans)}: ${c.plans?.length?esc(c.plans.join(', ')):esc(h.allPlans)}</p>${c.minimum_purchase?`<p>${esc(h.minimum)}: ${num(c.minimum_purchase,0)} IRT</p>`:''}${c.starts_at?`<small>${date(c.starts_at)}</small>`:''}</div>`:''}</article>`;
}
async function renderRewardsWorkspace(force=false){
    const page=$('#page-rewards'),h=hubCopy();
    page.innerHTML=pageHead('REWARDS',h.rewards,'')+skeleton(2);
    try{
        const d=await loadResource('hub',force)||{},p=d.points||{};
        let body='';
        if(rewardTab==='available')body=(d.available||[]).map(item=>{
            const affordable=Number(p.balance||0)>=Number(item.points||0);
            const prize=item.prize||{points:item.type==='points'?item.value:0,vip_days:item.type==='vip_days'?item.value:0,coupon_percent:item.discountPct};
            return `<article class="reward-card"><div class="row-between"><h3>${esc(item.name||h.rewards)}</h3><span class="status-badge info">${num(item.points,0)} ${esc(h.points)}</span></div><p>${esc(clientPrizeLabel(prize)||item.description||'')}</p><p>${esc(h.valid)}: ${item.expires_at?date(item.expires_at):esc(h.noExpiry)}</p><button class="button ${affordable?'primary':'secondary'}" data-reward-claim="${esc(item.id)}" ${affordable?'':'disabled'}>${esc(affordable?h.claimHere:h.notEnough)}</button></article>`;
        }).join('')||empty();
        if(rewardTab==='mine')body=(d.wallet||[]).map(rewardCard).join('')||empty();
        if(rewardTab==='history')body=pointHistoryHtml(p);
        if(p.recovery_due>0)body=`<div class="notice warn">${state.lang==='fa'?'امتیاز برگشتی باقیمانده از خرید بازپرداخت‌شده، از امتیازهای بعدی تسویه می‌شود:':'Outstanding points from a refunded purchase will be recovered from future earnings:'} ${num(p.recovery_due,0)}</div>`+body;
        page.innerHTML=pageHead('REWARDS',h.rewards,'')+`<div class="metric-grid">${metric(h.points,num(p.balance??0,0),'','info')}${metric(h.earned,num(p.earned??0,0),'','good')}${metric(h.spent,num(p.spent??0,0),'','')}</div><div class="segmented reward-tabs" role="tablist">${['available','mine','history'].map(key=>`<button role="tab" aria-selected="${rewardTab===key}" class="${rewardTab===key?'active':''}" data-reward-tab="${key}">${esc(h[key])}${key==='mine'?`<span data-reward-count ${d.unread_rewards?'':'hidden'}> · ${num(d.unread_rewards||0,0)} ${state.lang==='fa'?'جدید':'new'}</span>`:''}</button>`).join('')}</div><div class="reward-list">${body}</div><div class="card-actions"><button class="button secondary" data-open="referral">${icon('user')}${esc(h.referral)}</button><button class="button ghost" data-page-target="home">${esc(t('home'))}</button></div>`;
        if(rewardTab==='mine'){
            const keys=(d.wallet||[]).filter(item=>item.unread).map(item=>item.seen_key);
            if(keys.length){
                try{const result=await action('reward_seen',{keys:keys.slice(0,5000)},false);syncRewardBadges(result.unread_rewards);invalidate('hub','overview');}
                catch(error){console.warn('Reward acknowledgement pending');}
            }
        }
    }catch(err){page.innerHTML=errorPanel(err,'rewards');}
}
function clientPrizeLabel(p){return [['points',state.lang==='fa'?'امتیاز':'points'],['vip_days',state.lang==='fa'?'روز VIP':'VIP days'],['coupon_percent',state.lang==='fa'?'٪ تخفیف':'% coupon']].filter(([key])=>p[key]).map(([key,label])=>`${num(p[key],0)} ${label}`).join(' + ');}
function pointHistoryHtml(p){
    const h=hubCopy();
    return `<div class="point-history">${(p.history||[]).map(row=>`<article class="point-event"><strong class="${row.amount>=0?'text-good':'text-bad'}" dir="ltr">${row.amount>=0?'+':''}${num(row.amount,0)}</strong><div><p>${esc(row.reason_label||row.reason||h.rewards)}</p><small>${date(row.created_at)} · ${esc(h.balance)}: ${num(row.balance_after??0,0)}</small><details><summary>${esc(h.source)}</summary><code dir="ltr">${esc(row.source_event||'—')}</code></details></div></article>`).join('')||empty()}</div><div class="card-actions">${pointCursor?`<button class="button secondary" data-point-cursor="${Math.max(0,pointCursor-20)}">${esc(h.before)}</button>`:''}${p.next_cursor!=null?`<button class="button secondary" data-point-cursor="${p.next_cursor}">${esc(h.next)}</button>`:''}</div>`;
}
async function referralModal(force=true,guard=null){
    const h=hubCopy(),d=await loadResource('hub',force)||{},link=referralLink(d);
    if(guard&&!guard())return;
    openModal('REFERRAL',h.referral,`<div class="metric-grid">${metric(h.invited,num(d.referral?.invited??0,0),'','')}${metric(h.buyers,num(d.referral?.buyers??0,0),'','')}</div>${link?`<div class="referral-link" dir="ltr"><code>${esc(link)}</code></div><div class="card-actions"><button class="button primary" data-copy-referral>${esc(h.copy)}</button><button class="button secondary" data-share-referral>${esc(h.share)}</button></div>`:`<p>${esc(h.noCode)}</p>`}<button class="button ghost" data-bot-bridge="web_referral">${esc(h.bot)}</button>`,[]);
}
async function missionsModal(force=true,guard=null){
    const h=hubCopy(),d=await loadResource('hub',force)||{};
    if(guard&&!guard())return;
    openModal('MISSIONS',h.missions,`<div class="reward-list">${(d.missions||[]).map(m=>`<article class="reward-card"><h3>${esc(m.title)}</h3><p>${esc(m.description||'')}</p><span class="status-badge ${m.progress.completed?'good':'info'}">${m.progress.completed?'✓ ':''}${num(m.progress.progress,0)}/${num(m.progress.target,0)}</span><p>${esc(m.prize_label)}</p>${m.ends_at?`<small>${date(m.ends_at)}</small>`:''}</article>`).join('')||empty()}</div><button class="button secondary" data-bot-bridge="web_missions">${esc(h.bot)}</button>`,[]);
}
function renderTradingWorkspace(){
    const h=hubCopy();
    $('#page-trading').innerHTML=pageHead('TRADING',h.trading,'')+`<div class="service-list"><button class="service-card" data-page-target="risk">${icon('shield')}<span><strong>${esc(h.risk)}</strong><small>${esc(t('whatIf'))}</small></span>${icon('chevron')}</button><button class="service-card" data-page-target="journal">${icon('journal')}<span><strong>${esc(h.journal)}</strong><small>${esc(t('tradeJournal'))}</small></span>${icon('chevron')}</button>${sentinelService('shield',h.tools,'Paper / Prop / Risk Coach','tradeCenter')}${sentinelService('chart',t('market'),t('marketRegime'),'market')}${sentinelService('chart',h.ai,'AI','ai')}${hubBridgeCard('shield',h.tools,'web_tools')}</div>`;
}
/* The same task order as the Telegram menu; existing destinations are reused. */
function userMenuItems() {
    const fa = state.lang === 'fa', o = state.resources.overview || {};
    const item = (id, ic, faTitle, enTitle, kind, target, tone = '') => ({id, ic, title: fa ? faTitle : enTitle, kind, target, tone});
    return [
        {...item('vip','crown',o.account?.vip_active ? 'مدیریت اشتراک' : 'خرید اشتراک',o.account?.vip_active ? 'Manage subscription' : 'Buy subscription','open','vip','success'),wide:true},
        item('education','education','آموزش','Education','open','education'),
        item('calculator','calculator','ماشین‌حساب','Calculator','open','calculator'),
        item('market','market','قیمت بازار','Market prices','open','market'),
        item('account','account','حساب من','My account','open','settings'),
        item('contests','trophy','مسابقه','Contests','open','contests'),
        item('missions','mission','مأموریت','Missions','open','missions'),
        item('signals','signal','سیگنال‌ها','Signals','page','signals','primary'),
        item('trading','shield','مرکز معاملات','Trading center','page','trading','primary'),
        item('rewards','gift','پاداش‌ها','Rewards','reward','available'),
        item('referral','link','لینک دعوت من','My referral link','open','referral'),
        item('my-rewards','gift','جایزه‌های من','My rewards','reward','mine'),
        item('points','star','باشگاه و امتیاز','Club & points','reward','history'),
        item('today','calendar','امروز من','My today','bridge','web_today'),
        item('calendar','calendar','اخبار و تقویم','News & calendar','open','calendar'),
        item('tools','shield','ابزارهای معامله','Trading tools','open','tradeCenter'),
        item('rankings','trophy','رتبه‌بندی','Rankings','open','rankings'),
        item('settings','settings','تنظیمات','Settings','open','settings'),
        item('support','support','پشتیبانی','Support','open','support'),
        item('search','search','جست‌وجو و خدمات','Search & services','open','search'),
        item('rules','journal','قوانین','Rules','bridge','web_rules'),
        item('orders','wallet','سفارش‌ها و پرداخت','Orders & payments','open','orders'),
        item('notifications','bell','اعلان‌ها','Notifications','open','notifications'),
        item('journal','journal','ژورنال معاملاتی','Trading journal','page','journal'),
        item('risk','shield','برنامه ریسک','Risk plan','page','risk'),
        item('ai','chart','بررسی هوشمند','Smart review','open','ai'),
        item('language','language','زبان','Language','language','toggle'),
        item('faq','support','سؤالات متداول','FAQ','bridge','web_faq'),
        item('bot-tools','shield','ابزارهای ربات','Bot tools','bridge','web_tools'),
        item('bot-account','account','حساب در ربات','Bot account','bridge','web_account'),
    ];
}
function unreadRewardCount() {
    const value = state.resources.overview?.account?.unread_rewards ?? state.resources.hub?.unread_rewards;
    return Math.max(0, Math.floor(Number(value) || 0));
}
function userMenuHtml(compact = false) {
    const unread = unreadRewardCount(), fa = state.lang === 'fa';
    const items = userMenuItems().slice(0, compact ? 13 : undefined);
    return `<nav class="user-menu-grid" aria-label="${fa ? 'خدمات SENTINEL' : 'SENTINEL services'}">${items.map(item => {
        const attribute = item.kind === 'page' ? 'data-page-target' : item.kind === 'bridge' ? 'data-bot-bridge' : item.kind === 'reward' ? 'data-reward-open' : item.kind === 'language' ? 'data-menu-language' : 'data-open';
        const badge = ['rewards','my-rewards'].includes(item.id) && unread > 0 ? `<em class="menu-unread" aria-label="${num(unread,0)} ${fa ? 'جایزه جدید' : 'new rewards'}">${num(unread,0)} <span>${fa ? 'جدید' : 'new'}</span></em>` : '';
        return `<button type="button" class="user-menu-tile ${item.tone} ${item.wide ? 'menu-wide' : ''}" data-menu-id="${item.id}" ${attribute}="${esc(item.target)}">${icon(item.ic)}<strong>${esc(item.title)}</strong>${badge}${item.wide ? icon('chevron') : ''}</button>`;
    }).join('')}</nav>`;
}
function syncRewardBadges(count) {
    const safe = Math.max(0, Math.floor(Number(count) || 0));
    const o = state.resources.overview;
    if(o?.account) o.account.unread_rewards = safe;
    if(state.resources.hub) state.resources.hub.unread_rewards = safe;
    const badge = $('#rewardNavBadge');
    if(badge){badge.hidden = !safe;badge.textContent = num(safe,0);badge.setAttribute('aria-label',`${num(safe,0)} ${state.lang === 'fa' ? 'جایزه جدید' : 'new rewards'}`);}
    $$('[data-reward-count]').forEach(badge=>{badge.hidden=!safe;badge.textContent=` · ${num(safe,0)} ${state.lang==='fa'?'جدید':'new'}`;});
    // Update only badges: preserve keyboard focus and the user's current layout.
    $$('[data-menu-id="rewards"], [data-menu-id="my-rewards"]').forEach(tile => {
        let marker = tile.querySelector('.menu-unread');
        if(!safe){marker?.remove();return;}
        if(!marker){marker=document.createElement('em');marker.className='menu-unread';tile.append(marker);}
        marker.setAttribute('aria-label',`${num(safe,0)} ${state.lang==='fa'?'جایزه جدید':'new rewards'}`);
        marker.innerHTML=`${num(safe,0)} <span>${state.lang==='fa'?'جدید':'new'}</span>`;
    });
}
const menuChromeRender = renderChrome;
renderChrome = function(){menuChromeRender();syncRewardBadges(unreadRewardCount());};
const fullUserMenuRender = renderMore;
renderMore = async function(force=false){
    await fullUserMenuRender(force);
    const page=$('#page-more');
    // Reuse additional current services, without duplicating catalog entries.
    const covered = new Set(['tradeCenter','calculator','journal-route','market','vip','orders','contests','notifications','calendar','support','search','settings']);
    const supplement=[];
    page.querySelectorAll('.service-groups > section:not(.admin-service-group)').forEach(section=>{
        section.querySelectorAll('.service-card').forEach(button=>{if(!covered.has(button.dataset.open))supplement.push(button);});section.remove();
    });
    page.querySelector('.page-header')?.remove();
    const catalog=document.createElement('section');catalog.className='panel user-access-catalog';
    catalog.innerHTML=`<div class="panel-head"><div><span class="eyebrow">SENTINEL SERVICES</span><h2>${esc(state.lang==='fa'?'تمام خدمات':'All services')}</h2><p>${esc(state.lang==='fa'?'دسترسی مستقیم به تمام بخش‌ها':'Direct access to every workspace')}</p></div></div><div class="panel-body">${userMenuHtml()}</div>`;
    page.prepend(catalog);
    if(supplement.length){const extra=document.createElement('section');extra.className='panel supplementary-services';extra.innerHTML=`<div class="panel-head"><h2>${esc(state.lang==='fa'?'پیگیری و شفافیت':'Activity & transparency')}</h2></div><div class="panel-body service-list"></div>`;extra.querySelector('.service-list').append(...supplement);catalog.after(extra);}
    if(state.lang==='en')localizeUiTree(page);
    syncRewardBadges(unreadRewardCount());
};
const hubLegacyOpenMore=openMore;
openMore=async function(target){
    if(target==='education')return botBridge('web_edu');
    if(target==='rankings')return rankingModal();
    if(target==='referral')return referralModal();
    if(target==='missions')return missionsModal();
    if(target==='rewards'){rewardTab='available';closeModal();return navigate('rewards');}
    if(target==='trading'){closeModal();return navigate('trading');}
    return hubLegacyOpenMore(target);
};
document.addEventListener('click',async event=>{
    const el=event.target.closest('[data-menu-language],[data-reward-open],[data-page-back],[data-reward-claim],[data-reward-tab],[data-point-cursor],[data-copy-reward],[data-bot-bridge],[data-copy-referral],[data-share-referral]');
    if(!el)return;event.preventDefault();event.stopImmediatePropagation();
    try{
        if(el.dataset.menuLanguage)return await toggleLanguage();
        if(el.dataset.rewardOpen){rewardTab=el.dataset.rewardOpen;closeModal();return await navigate('rewards');}
        if(el.dataset.pageBack!==undefined)return await navigateWorkspaceBack();
        if(el.dataset.botBridge)return botBridge(el.dataset.botBridge);
        if(el.dataset.rewardClaim)return confirmRewardClaim(el.dataset.rewardClaim);
        if(el.dataset.rewardTab){rewardTab=el.dataset.rewardTab;return await renderRewardsWorkspace();}
        if(el.dataset.pointCursor!==undefined){pointCursor=Math.max(0,Number(el.dataset.pointCursor)||0);invalidate('hub');await loadResource('hub',true);return await renderRewardsWorkspace();}
        const link=referralLink(state.resources.hub);
        if(el.dataset.shareReferral!==undefined&&link&&navigator.share){try{await navigator.share({title:'SENTINEL',url:link});}catch(err){if(err.name!=='AbortError')throw err;}return;}
        const value=el.dataset.copyReward||link;if(!value)return;
        await copyHubText(value);
    }catch(err){toast(err.message||t('error'),'error');}
},true);

async function rankingModal(force=true,guard=null){
 const h=hubCopy(),d=await loadResource('hub',force)||{};
 if(guard&&!guard())return;
 openModal('CLUB',h.rank,`<div class="notice info">${state.lang==='fa'?'رتبه من':'My rank'}: ${d.my_rank?num(d.my_rank,0):'—'}</div><div class="ranking-list">${(d.leaderboard||[]).map(row=>`<article class="ranking-row ${row.rank<=3?'podium':''} ${row.is_me?'is-me':''}"><strong class="rank-number">${['🥇','🥈','🥉'][row.rank-1]||'#'+num(row.rank,0)}</strong><span>${esc(row.name)}${row.is_me?' · '+(state.lang==='fa'?'شما':'You'):''}</span><b>${num(row.points,0)} <small>${esc(h.points)}</small></b></article>`).join('')||empty()}</div><button class="button ghost" data-bot-bridge="web_club">${esc(h.bot)}</button>`,[]);
}

async function copyHubText(value){
    if(navigator.clipboard?.writeText){try{await navigator.clipboard.writeText(value);toast(hubCopy().copied);return;}catch{}}
    openModal('COPY',state.lang==='fa'?'کپی لینک یا کد':'Copy link or code',`<div class="field"><input id="hubCopyValue" readonly dir="ltr" value="${esc(value)}" aria-label="${esc(hubCopy().copy)}"><small>${state.lang==='fa'?'متن را انتخاب و کپی کنید.':'Select and copy the text.'}</small></div>`,[]);
    $('#hubCopyValue')?.select();
}
function confirmRewardClaim(id){
    const item=state.resources.hub?.available?.find(row=>String(row.id)===String(id));if(!item)return;
    const h=hubCopy();
    openModal('REWARD CLAIM',h.confirm,`<h3>${esc(item.name)}</h3><p>${esc(h.cost)}: ${num(item.points,0)} ${esc(h.points)}</p>`,[{label:h.claimHere,kind:'primary',action:async()=>{
        setBusy(true);try{
            await action('reward_claim',{reward_id:Number(item.id)},false);
            closeModal();rewardTab='mine';pointCursor=0;invalidate('hub','overview');
            await Promise.all([loadResource('hub',true),loadOverview(true)]);renderChrome();await renderRewardsWorkspace();toast(t('success'));
        }catch(err){toast(err.message||t('error'),'error');}finally{setBusy(false);}
    }}]);
}

const navigateWithBotBridge=navigate;
navigate=async function(page,scroll=true){
    await navigateWithBotBridge(page,scroll);
    const target={signals:'web_signals',trading:'web_trade',risk:'web_calc',journal:'web_journal',rewards:'web_rewards',more:'web_account_hub'}[state.page];
    const container=$(`#page-${state.page}`);if(!container||!target||container.querySelector('.telegram-continue'))return;
    const footer=document.createElement('div');footer.className='card-actions telegram-continue';
    footer.innerHTML=`<button class="button ghost" data-bot-bridge="${target}">${esc(state.lang==='fa'?'ادامه این بخش در ربات تلگرام':'Continue this section in Telegram')}</button>`;container.append(footer);
};

function hubFingerprint(data){if(!data)return '';const {generated_at,...content}=data;return JSON.stringify(content);}
async function refreshVisibleHub(){
    if(state.busy)return false;
    const modalName=!$('#modalLayer')?.hidden?$('#modalEyebrow')?.textContent:'';
    const modalGeneration=state.modalGeneration||0,page=state.page,cursor=pointCursor;
    const sameModal=()=>!$('#modalLayer')?.hidden&&$('#modalEyebrow')?.textContent===modalName&&(state.modalGeneration||0)===modalGeneration;
    if(state.page!=='rewards' && !['REFERRAL','MISSIONS','CLUB'].includes(modalName))return false;
    const before=hubFingerprint(state.resources.hub),fresh=await loadResource('hub',true);
    if(hubFingerprint(fresh)===before)return false;
    await loadOverview(true);renderChrome();
    if(page==='rewards'&&state.page===page&&pointCursor===cursor)await renderRewardsWorkspace();
    if(sameModal()){
        if(modalName==='REFERRAL')await referralModal(false,sameModal);
        if(modalName==='MISSIONS')await missionsModal(false,sameModal);
        if(modalName==='CLUB')await rankingModal(false,sameModal);
    }
    return true;
}
